package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.AppStrings
import com.example.core.i18n.BiText
import com.example.core.model.ToolCategory
import com.example.core.model.ToolId
import com.example.ui.MainViewModel
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.FileManagerScreen
import com.example.ui.screens.PdfEditorScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.ToolWorkspaceScreen
import com.example.ui.theme.PdfConverterTheme
import com.example.ui.theme.ThemePreference
import kotlinx.serialization.Serializable

@Serializable data object DashboardRoute
@Serializable data class ToolRoute(val toolName: String)
@Serializable data object EditorRoute
@Serializable data object FilesRoute
@Serializable data object SettingsRoute

private data class NavTab(
    val route: Any,
    val label: BiText,
    val icon: ImageVector,
    val tag: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val vm: MainViewModel = viewModel()
            val settings by vm.settings.collectAsStateWithLifecycle()

            PdfConverterTheme(
                themePreference = settings.theme,
                isBengali = settings.language == AppLanguage.BN
            ) {
                PdfConverterApp(vm = vm)
            }
        }
    }
}

@Composable
private fun PdfConverterApp(vm: MainViewModel) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDest = backStackEntry?.destination

    val settings by vm.settings.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val searchQuery by vm.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by vm.selectedCategory.collectAsStateWithLifecycle()
    val selectedFiles by vm.selectedFiles.collectAsStateWithLifecycle()
    val options by vm.options.collectAsStateWithLifecycle()
    val detectedSheets by vm.detectedExcelSheets.collectAsStateWithLifecycle()
    val inspectedMeta by vm.inspectedMetadata.collectAsStateWithLifecycle()
    val processingState by vm.processingState.collectAsStateWithLifecycle()
    val useBackendServer by vm.useBackendServer.collectAsStateWithLifecycle()
    val workspaceLibrary by vm.workspaceLibrary.collectAsStateWithLifecycle()
    val editorPdfFile by vm.editorPdfFile.collectAsStateWithLifecycle()
    val editorAnnotations by vm.editorAnnotations.collectAsStateWithLifecycle()
    val backendTestStatus by vm.backendTestStatus.collectAsStateWithLifecycle()

    val tabs = listOf(
        NavTab(DashboardRoute, AppStrings.navDashboard, Icons.Filled.Build, "nav_tools"),
        NavTab(EditorRoute, AppStrings.navEditor, Icons.Filled.Edit, "nav_editor"),
        NavTab(FilesRoute, AppStrings.navFiles, Icons.Filled.FolderOpen, "nav_files"),
        NavTab(SettingsRoute, AppStrings.navSettings, Icons.Filled.Settings, "nav_settings")
    )

    val showChrome = currentDest?.hasRoute<ToolRoute>() != true

    fun navigateTopTab(route: Any) {
        navController.navigate(route) {
            popUpTo(DashboardRoute) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 720.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                if (showChrome && !useRail) {
                    NavigationBar {
                        tabs.forEach { tab ->
                            val selected = currentDest?.hasRoute(tab.route::class) == true
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTopTab(tab.route) },
                                icon = { Icon(tab.icon, contentDescription = tab.label.get(settings.language)) },
                                label = { Text(tab.label.get(settings.language)) },
                                modifier = Modifier.testTag(tab.tag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (showChrome && useRail) {
                    NavigationRail {
                        tabs.forEach { tab ->
                            val selected = currentDest?.hasRoute(tab.route::class) == true
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTopTab(tab.route) },
                                icon = { Icon(tab.icon, contentDescription = tab.label.get(settings.language)) },
                                label = { Text(tab.label.get(settings.language)) },
                                modifier = Modifier.testTag(tab.tag)
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    NavHost(
                        navController = navController,
                        startDestination = DashboardRoute
                    ) {
                        composable<DashboardRoute> {
                            DashboardScreen(
                                language = settings.language,
                                themePreference = settings.theme,
                                searchQuery = searchQuery,
                                selectedCategory = selectedCategory,
                                onSearchChange = vm::setSearchQuery,
                                onCategorySelect = vm::setSelectedCategory,
                                onToggleLanguage = {
                                    val next = if (settings.language == AppLanguage.EN) AppLanguage.BN else AppLanguage.EN
                                    vm.setLanguage(next)
                                },
                                onToggleTheme = {
                                    val next = if (settings.theme == ThemePreference.DARK) ThemePreference.LIGHT else ThemePreference.DARK
                                    vm.setTheme(next)
                                },
                                onToolClick = { tool ->
                                    if (tool.category == ToolCategory.PDF_EDITOR) {
                                        navigateTopTab(EditorRoute)
                                    } else {
                                        vm.openTool(tool)
                                        navController.navigate(ToolRoute(tool.name))
                                    }
                                }
                            )
                        }

                        composable<ToolRoute> { entry ->
                            val route = entry.toRoute<ToolRoute>()
                            val toolId = runCatching { ToolId.valueOf(route.toolName) }.getOrDefault(ToolId.IMAGES_TO_PDF)
                            ToolWorkspaceScreen(
                                toolId = toolId,
                                language = settings.language,
                                selectedFiles = selectedFiles,
                                options = options,
                                detectedExcelSheets = detectedSheets,
                                inspectedMetadata = inspectedMeta,
                                processingState = processingState,
                                optionalBackendUrl = settings.optionalBackendUrl,
                                useBackendServer = useBackendServer,
                                onAddUris = vm::addUrisToActiveTool,
                                onRemoveFile = vm::removeSelectedFile,
                                onMoveFile = vm::moveSelectedFile,
                                onUpdateOptions = vm::updateOptions,
                                onToggleBackendServer = vm::setUseBackendServer,
                                onRun = vm::runActiveTool,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable<EditorRoute> {
                            PdfEditorScreen(
                                language = settings.language,
                                pdfFile = editorPdfFile,
                                annotations = editorAnnotations,
                                onPickPdfUri = vm::loadPdfIntoEditor,
                                onAddAnnotation = vm::addEditorAnnotation,
                                onUndoPage = vm::undoLastEditorAnnotation,
                                onExportPdf = vm::exportEditedPdf
                            )
                        }

                        composable<FilesRoute> {
                            FileManagerScreen(
                                language = settings.language,
                                workspaceFiles = workspaceLibrary,
                                historyItems = history,
                                onUploadUris = vm::uploadToWorkspace,
                                onRenameFile = vm::renameWorkspaceFile,
                                onDeleteFile = vm::deleteWorkspaceFile,
                                onCreateZip = vm::createZipFromWorkspaceIds,
                                onBatchConvert = vm::batchConvertWorkspaceFiles,
                                onDeleteHistory = vm::deleteHistoryItem,
                                onClearHistory = vm::clearHistory
                            )
                        }

                        composable<SettingsRoute> {
                            SettingsScreen(
                                settings = settings,
                                backendTestStatus = backendTestStatus,
                                onLanguageChange = vm::setLanguage,
                                onThemeChange = vm::setTheme,
                                onAutoOcrChange = vm::setAutoOcr,
                                onDefaultDpiChange = vm::setDefaultDpi,
                                onSaveBackendUrl = vm::setBackendUrl,
                                onTestBackend = vm::testBackendConnection
                            )
                        }
                    }
                }
            }
        }
    }
}
