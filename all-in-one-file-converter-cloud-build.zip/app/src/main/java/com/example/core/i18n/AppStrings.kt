package com.example.core.i18n

enum class AppLanguage(val code: String, val displayName: String) {
    EN("en", "English"),
    BN("bn", "বাংলা")
}

data class BiText(val en: String, val bn: String) {
    fun get(lang: AppLanguage): String = if (lang == AppLanguage.BN) bn else en
}

object AppStrings {
    val appTitle = BiText("PDF & Office Converter Pro", "পিডিএফ ও অফিস কনভার্টার প্রো")
    val appSubtitle = BiText(
        "All-in-One Local Document Studio • Zero Paid APIs",
        "অল-ইন-ওয়ান লোকাল ডকুমেন্ট স্টুডিও • কোনো পেইড এপিআই নয়"
    )
    val searchPlaceholder = BiText(
        "Search 55+ tools (e.g. PDF to Word, Compress, OCR)...",
        "৫৫+ টুল খুঁজুন (যেমন: PDF to Word, Compress, OCR)..."
    )
    val navDashboard = BiText("Tools", "টুলস")
    val navEditor = BiText("PDF Editor", "পিডিএফ এডিটর")
    val navFiles = BiText("Files & History", "ফাইল ও হিস্ট্রি")
    val navSettings = BiText("Settings", "সেটিংস")

    val allCategories = BiText("All Tools", "সব টুলস")
    val quickUpload = BiText("Pick Files", "ফাইল বাছুন")
    val addMoreFiles = BiText("Add Files", "আরো ফাইল যোগ করুন")
    val startProcess = BiText("Convert / Process Now", "এখনই কনভার্ট / প্রসেস করুন")
    val processing = BiText("Processing...", "প্রসেসিং চলছে...")
    val originalPreservedNote = BiText(
        "Original files remain untouched. Recommended max file size: 50 MB on device.",
        "মূল ফাইল সম্পূর্ণ অক্ষত থাকে। ডিভাইসে নির্বিঘ্ন প্রসেসিংয়ের জন্য সর্বোচ্চ ৫০ মেগাবাইট প্রস্তাবিত।"
    )
    val noFilesSelected = BiText(
        "Select one or more files to start.",
        "শুরু করতে এক বা একাধিক ফাইল নির্বাচন করুন।"
    )
    val resultReady = BiText("Processing Complete", "প্রসেসিং সম্পন্ন হয়েছে")
    val saveToDevice = BiText("Save File", "সেভ করুন")
    val shareFile = BiText("Share", "শেয়ার করুন")
    val downloadZip = BiText("Download ZIP", "ZIP ডাউনলোড")
    val previewResult = BiText("Preview", "প্রিভিউ")
    val originalSize = BiText("Original", "মূল সাইজ")
    val outputSize = BiText("Output", "নতুন সাইজ")
    val savedPercent = BiText("Saved", "সেভ হয়েছে")
    val pagesLabel = BiText("Pages", "পৃষ্ঠা")

    // Options
    val pageSize = BiText("Page Size", "পৃষ্ঠার মাপ")
    val orientation = BiText("Orientation", "ওরিয়েন্টেশন")
    val portrait = BiText("Portrait", "পোর্ট্রেট")
    val landscape = BiText("Landscape", "ল্যান্ডস্কেপ")
    val margins = BiText("Margins", "মার্জিন")
    val imageFormat = BiText("Output Image Format", "ছবির ফরম্যাট")
    val quality = BiText("Quality", "মান (Quality)")
    val resolutionDpi = BiText("Resolution (DPI)", "রেজোলিউশন (DPI)")
    val useTargetSize = BiText("Enable Target File Size", "নির্দিষ্ট সাইজ (KB/MB) লক্ষ্য করুন")
    val targetSizeKb = BiText("Target Size (KB)", "টার্গেট সাইজ (KB)")
    val ocrToggle = BiText("Enable OCR for Scanned PDFs", "স্ক্যান করা PDF-এর জন্য OCR চালু করুন")
    val passwordLabel = BiText("Password", "পাসওয়ার্ড")
    val watermarkText = BiText("Watermark Text", "ওয়াটারমার্ক টেক্সট")
    val pageRangeHint = BiText("Pages (e.g. 1-3, 5) or blank for all", "পৃষ্ঠা নম্বর (যেমন: 1-3, 5) বা সবগুলোর জন্য খালি রাখুন")
    val rotationAngle = BiText("Rotation Angle", "ঘূর্ণন কোণ")
    val printAreaHint = BiText("Print Area (e.g. A1:F25, optional)", "প্রিন্ট এরিয়া (যেমন: A1:F25, ঐচ্ছিক)")
    val fitToPage = BiText("Fit Columns to Page", "পৃষ্ঠায় সব কলাম ফিট করুন")
    val selectSheets = BiText("Select Excel Sheets", "এক্সেল শিট নির্বাচন করুন")
    val authorizedConfirm = BiText(
        "I confirm I am authorized to unlock this PDF file.",
        "আমি নিশ্চিত করছি যে এই PDF ফাইলটি আনলক করার অনুমতি আমার রয়েছে।"
    )

    // File Manager & History
    val workspaceTab = BiText("Workspace", "ওয়ার্কস্পেস")
    val historyTab = BiText("History", "হিস্ট্রি")
    val batchConvert = BiText("Batch Convert", "ব্যাচ কনভার্ট")
    val rename = BiText("Rename", "নাম পরিবর্তন")
    val delete = BiText("Delete", "মুছুন")
    val clearHistory = BiText("Clear History", "হিস্ট্রি মুছুন")
    val emptyWorkspace = BiText(
        "No workspace files yet. Upload or convert files to manage, preview, rename, batch convert, or zip them.",
        "এখনো কোনো ফাইল নেই। প্রিভিউ, রিনেম, ব্যাচ কনভার্ট বা ZIP করতে ফাইল আপলোড বা কনভার্ট করুন।"
    )
    val emptyHistory = BiText(
        "Your conversion history will appear here.",
        "আপনার কনভার্সন হিস্ট্রি এখানে দেখা যাবে।"
    )

    // Settings
    val languageLabel = BiText("App Language", "অ্যাপের ভাষা")
    val themeLabel = BiText("Appearance Theme", "থিম মোড")
    val themeSystem = BiText("System", "সিস্টেম")
    val themeLight = BiText("Light", "লাইট")
    val themeDark = BiText("Dark", "ডার্ক")
    val serverSectionTitle = BiText(
        "Optional Self-Hosted Server Backend",
        "ঐচ্ছিক নিজস্ব সার্ভার ব্যাকএন্ড সাপোর্ট"
    )
    val serverSectionDesc = BiText(
        "All tools run locally on-device by default with zero paid APIs. For pixel-exact legacy binary (.doc/.xls/.ppt) rendering, you may optionally connect a self-hosted LibreOffice/Gotenberg endpoint.",
        "সব টুল ডিফল্টভাবে কোনো পেইড API ছাড়াই ডিভাইসে লোকালি কাজ করে। চাইলে পিক্সেল-নিখুঁত লিগ্যাসি (.doc/.xls/.ppt) রেন্ডারিংয়ের জন্য নিজস্ব LibreOffice/Gotenberg সার্ভার যুক্ত করতে পারেন।"
    )
    val serverUrlLabel = BiText("Server Endpoint URL (Optional)", "সার্ভার URL (ঐচ্ছিক)")
    val testConnection = BiText("Test Connection", "কানেকশন পরীক্ষা")
    val saveSettings = BiText("Save", "সংরক্ষণ")
}
