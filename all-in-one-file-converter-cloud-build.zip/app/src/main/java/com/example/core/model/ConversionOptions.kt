package com.example.core.model

import androidx.compose.ui.graphics.Color
import java.io.File

enum class PageSize(val label: String, val widthPt: Float, val heightPt: Float) {
    A4("A4 (210×297 mm)", 595f, 842f),
    A3("A3 (297×420 mm)", 842f, 1191f),
    LETTER("Letter (8.5×11 in)", 612f, 792f),
    LEGAL("Legal (8.5×14 in)", 612f, 1008f)
}

enum class PageOrientation {
    PORTRAIT, LANDSCAPE
}

enum class MarginPreset(val labelEn: String, val labelBn: String, val points: Float) {
    NONE("None (0 mm)", "মার্জিন নেই (0)", 0f),
    SMALL("Small (8 mm)", "ছোট (8 mm)", 22f),
    MEDIUM("Medium (15 mm)", "মাঝারি (15 mm)", 42f),
    LARGE("Large (25 mm)", "বড় (25 mm)", 70f)
}

enum class OutputImageFormat(val ext: String, val mimeType: String) {
    JPG("jpg", "image/jpeg"),
    JPEG("jpeg", "image/jpeg"),
    PNG("png", "image/png"),
    WEBP("webp", "image/webp")
}

data class WorkspaceFile(
    val id: String,
    val name: String,
    val localFile: File,
    val mimeType: String,
    val sizeBytes: Long,
    val addedAt: Long = System.currentTimeMillis()
)

data class ConversionOptions(
    val pageSize: PageSize = PageSize.A4,
    val orientation: PageOrientation = PageOrientation.PORTRAIT,
    val margin: MarginPreset = MarginPreset.SMALL,
    val outputImageFormat: OutputImageFormat = OutputImageFormat.JPG,
    val quality: Int = 85,
    val dpi: Int = 150,
    val useTargetSize: Boolean = false,
    val targetSizeKb: Int = 500,
    val enableOcr: Boolean = true,
    val pageRange: String = "",
    val rotationDegrees: Int = 90,
    val password: String = "",
    val authorizedToUnlock: Boolean = false,
    val watermarkText: String = "CONFIDENTIAL",
    val pageNumberPrefix: String = "Page ",
    val selectedExcelSheets: Set<String> = emptySet(),
    val fitToPage: Boolean = true,
    val printArea: String = "",
    val excelExtractFormat: String = "CSV", // CSV, JSON, PREVIEW
    val customMetadataTitle: String = "",
    val customMetadataAuthor: String = "",
    val customMetadataSubject: String = "",
    val customMetadataKeywords: String = ""
)

data class ConversionOutputFile(
    val name: String,
    val file: File,
    val mimeType: String,
    val sizeBytes: Long
)

data class ConversionResult(
    val toolId: ToolId,
    val outputFiles: List<ConversionOutputFile>,
    val zipFile: File? = null,
    val originalTotalBytes: Long,
    val outputTotalBytes: Long,
    val pageCount: Int = 0,
    val previewText: String? = null,
    val note: String? = null
)

data class PdfMetadataInfo(
    val title: String,
    val author: String,
    val subject: String,
    val keywords: String,
    val creator: String,
    val producer: String,
    val pageCount: Int,
    val isEncrypted: Boolean,
    val fileSizeBytes: Long
)

enum class EditorToolMode {
    VIEW,
    ADD_TEXT,
    TEXT_BOX,
    HIGHLIGHT,
    UNDERLINE,
    STRIKE_THROUGH,
    DRAW,
    SIGNATURE,
    ADD_IMAGE,
    CROP_PAGE,
    WATERMARK,
    PAGE_NUMBER,
    DIGITAL_SIGNATURE
}

sealed class PdfAnnotationItem(
    open val id: String,
    open val pageIndex: Int
) {
    data class TextAnnotation(
        override val id: String,
        override val pageIndex: Int,
        val normX: Float,
        val normY: Float,
        val text: String,
        val fontSizePt: Float,
        val colorArgb: Int,
        val isBoxed: Boolean = false
    ) : PdfAnnotationItem(id, pageIndex)

    data class MarkupAnnotation(
        override val id: String,
        override val pageIndex: Int,
        val kind: MarkupKind,
        val normLeft: Float,
        val normTop: Float,
        val normRight: Float,
        val normBottom: Float,
        val colorArgb: Int
    ) : PdfAnnotationItem(id, pageIndex)

    data class FreehandAnnotation(
        override val id: String,
        override val pageIndex: Int,
        val pointsNorm: List<Pair<Float, Float>>,
        val strokeWidthDp: Float,
        val colorArgb: Int,
        val isSignature: Boolean = false
    ) : PdfAnnotationItem(id, pageIndex)

    data class ImageAnnotation(
        override val id: String,
        override val pageIndex: Int,
        val imageFile: File,
        val normLeft: Float,
        val normTop: Float,
        val normWidth: Float,
        val normHeight: Float
    ) : PdfAnnotationItem(id, pageIndex)

    data class CropAnnotation(
        override val id: String,
        override val pageIndex: Int,
        val marginLeftFrac: Float,
        val marginTopFrac: Float,
        val marginRightFrac: Float,
        val marginBottomFrac: Float
    ) : PdfAnnotationItem(id, pageIndex)

    data class DigitalSealAnnotation(
        override val id: String,
        override val pageIndex: Int,
        val signerName: String,
        val reason: String,
        val timestampText: String,
        val normX: Float,
        val normY: Float
    ) : PdfAnnotationItem(id, pageIndex)
}

enum class MarkupKind {
    HIGHLIGHT, UNDERLINE, STRIKE_THROUGH
}
