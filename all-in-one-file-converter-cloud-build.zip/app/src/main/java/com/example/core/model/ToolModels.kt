package com.example.core.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallSplit
import androidx.compose.material.icons.automirrored.filled.MergeType
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileCopy
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Preview
import androidx.compose.material.icons.filled.Reorder
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Slideshow
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.core.i18n.BiText
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.CompressAmber
import com.example.ui.theme.EditorTeal
import com.example.ui.theme.ExcelGreen
import com.example.ui.theme.ImageViolet
import com.example.ui.theme.OtherSlate
import com.example.ui.theme.PdfRed
import com.example.ui.theme.PptOrange
import com.example.ui.theme.WordBlue

enum class ToolCategory(
    val title: BiText,
    val color: Color,
    val icon: ImageVector
) {
    IMAGE_TO_PDF(BiText("Image to PDF", "ছবি থেকে PDF"), ImageViolet, Icons.Filled.PhotoLibrary),
    PDF_TO_IMAGE(BiText("PDF to Image", "PDF থেকে ছবি"), BrandBlue, Icons.Filled.Image),
    PDF_TOOLS(BiText("PDF Tools", "PDF টুলস"), PdfRed, Icons.Filled.PictureAsPdf),
    WORD_CONVERTER(BiText("Word Converter", "Word কনভার্টার"), WordBlue, Icons.Filled.Description),
    EXCEL_CONVERTER(BiText("Excel Converter", "Excel কনভার্টার"), ExcelGreen, Icons.Filled.TableChart),
    POWERPOINT_CONVERTER(BiText("PowerPoint", "PowerPoint কনভার্টার"), PptOrange, Icons.Filled.Slideshow),
    OTHER_CONVERTER(BiText("Other Formats", "অন্যান্য ফরম্যাট"), OtherSlate, Icons.Filled.Code),
    PDF_EDITOR(BiText("PDF Editor", "PDF এডিটর"), EditorTeal, Icons.Filled.Edit),
    FILE_COMPRESSOR(BiText("File Compressor", "ফাইল কম্প্রেসর"), CompressAmber, Icons.Filled.Compress)
}

enum class InputPickerMode {
    SINGLE_IMAGE,
    MULTIPLE_IMAGES,
    SINGLE_PDF,
    MULTIPLE_PDFS,
    SINGLE_DOC,
    MULTIPLE_DOCS,
    ANY_DOCUMENT
}

enum class ToolId(
    val category: ToolCategory,
    val title: BiText,
    val subtitle: BiText,
    val icon: ImageVector,
    val pickerMode: InputPickerMode,
    val mimeTypes: List<String>,
    val acceptedExtensions: List<String>
) {
    // 1. Image to PDF
    JPG_TO_PDF(
        ToolCategory.IMAGE_TO_PDF,
        BiText("JPG to PDF", "JPG থেকে PDF"),
        BiText("Convert JPG photos into a crisp PDF", "JPG ছবিকে পরিষ্কার PDF-এ রূপান্তর"),
        Icons.Filled.PictureAsPdf, InputPickerMode.MULTIPLE_IMAGES,
        listOf("image/jpeg"), listOf("jpg", "jpeg")
    ),
    JPEG_TO_PDF(
        ToolCategory.IMAGE_TO_PDF,
        BiText("JPEG to PDF", "JPEG থেকে PDF"),
        BiText("Merge JPEG images with layout control", "লেআউট নিয়ন্ত্রণসহ JPEG থেকে PDF"),
        Icons.Filled.PictureAsPdf, InputPickerMode.MULTIPLE_IMAGES,
        listOf("image/jpeg"), listOf("jpeg", "jpg")
    ),
    PNG_TO_PDF(
        ToolCategory.IMAGE_TO_PDF,
        BiText("PNG to PDF", "PNG থেকে PDF"),
        BiText("Convert transparent or crisp PNGs to PDF", "PNG ছবি থেকে PDF তৈরি"),
        Icons.Filled.PhotoLibrary, InputPickerMode.MULTIPLE_IMAGES,
        listOf("image/png"), listOf("png")
    ),
    WEBP_TO_PDF(
        ToolCategory.IMAGE_TO_PDF,
        BiText("WEBP to PDF", "WEBP থেকে PDF"),
        BiText("Convert modern WEBP images to PDF", "WEBP ছবিকে PDF-এ রূপান্তর"),
        Icons.Filled.AddPhotoAlternate, InputPickerMode.MULTIPLE_IMAGES,
        listOf("image/webp"), listOf("webp")
    ),
    BMP_TO_PDF(
        ToolCategory.IMAGE_TO_PDF,
        BiText("BMP to PDF", "BMP থেকে PDF"),
        BiText("Convert bitmap BMP files to PDF", "BMP বিটম্যাপ ছবি থেকে PDF"),
        Icons.Filled.Image, InputPickerMode.MULTIPLE_IMAGES,
        listOf("image/bmp", "image/x-ms-bmp", "image/*"), listOf("bmp")
    ),
    TIFF_TO_PDF(
        ToolCategory.IMAGE_TO_PDF,
        BiText("TIFF to PDF", "TIFF থেকে PDF"),
        BiText("Decode multi-strip TIFF scans to PDF", "TIFF স্ক্যান ছবি থেকে PDF"),
        Icons.Filled.PhotoLibrary, InputPickerMode.MULTIPLE_IMAGES,
        listOf("image/tiff", "image/*", "application/octet-stream"), listOf("tif", "tiff")
    ),
    IMAGES_TO_PDF(
        ToolCategory.IMAGE_TO_PDF,
        BiText("Multi-Image to PDF", "একাধিক ছবি থেকে PDF"),
        BiText("Reorder mixed images, choose A4/A3/Letter/Legal & margins", "ছবির ক্রম সাজিয়ে A4/A3/Letter ও মার্জিনসহ PDF"),
        Icons.Filled.Reorder, InputPickerMode.MULTIPLE_IMAGES,
        listOf("image/*"), listOf("jpg", "jpeg", "png", "webp", "bmp", "tif", "tiff")
    ),

    // 2. PDF to Image
    PDF_TO_JPG(
        ToolCategory.PDF_TO_IMAGE,
        BiText("PDF to JPG", "PDF থেকে JPG"),
        BiText("Export every PDF page as JPG + ZIP", "প্রতিটি পেজ JPG এবং ZIP হিসেবে ডাউনলোড"),
        Icons.Filled.Image, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),
    PDF_TO_JPEG(
        ToolCategory.PDF_TO_IMAGE,
        BiText("PDF to JPEG", "PDF থেকে JPEG"),
        BiText("High-DPI PDF to JPEG image converter", "উচ্চ রেজোলিউশনে PDF থেকে JPEG"),
        Icons.Filled.Image, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),
    PDF_TO_PNG(
        ToolCategory.PDF_TO_IMAGE,
        BiText("PDF to PNG", "PDF থেকে PNG"),
        BiText("Lossless PNG page extraction + ZIP", "লসলেস PNG পেজ এক্সপোর্ট ও ZIP"),
        Icons.Filled.PhotoLibrary, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),
    PDF_TO_WEBP(
        ToolCategory.PDF_TO_IMAGE,
        BiText("PDF to WEBP", "PDF থেকে WEBP"),
        BiText("Compact WEBP page export with DPI control", "DPI নিয়ন্ত্রণসহ WEBP ইমেজ এক্সপোর্ট"),
        Icons.Filled.AddPhotoAlternate, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),

    // 3. PDF Tools
    MERGE_PDF(
        ToolCategory.PDF_TOOLS,
        BiText("Merge PDF", "PDF যুক্ত করুন"),
        BiText("Combine & reorder multiple PDFs into one", "একাধিক PDF সাজিয়ে একটিতে যুক্ত করুন"),
        Icons.AutoMirrored.Filled.MergeType, InputPickerMode.MULTIPLE_PDFS,
        listOf("application/pdf"), listOf("pdf")
    ),
    SPLIT_PDF(
        ToolCategory.PDF_TOOLS,
        BiText("Split PDF", "PDF ভাগ করুন"),
        BiText("Split by page ranges or into individual pages + ZIP", "পেজ রেঞ্জ বা আলাদা পেজে ভাগ করে ZIP"),
        Icons.AutoMirrored.Filled.CallSplit, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),
    COMPRESS_PDF(
        ToolCategory.PDF_TOOLS,
        BiText("Compress PDF", "PDF কম্প্রেস করুন"),
        BiText("Reduce PDF size with target KB/MB control", "টার্গেট KB/MB অনুযায়ী PDF সাইজ কমান"),
        Icons.Filled.Compress, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),
    ROTATE_PDF(
        ToolCategory.PDF_TOOLS,
        BiText("Rotate PDF", "PDF ঘোরান"),
        BiText("Rotate selected or all pages 90° / 180° / 270°", "নির্দিষ্ট বা সব পেজ ৯০°/১৮০°/২৭০° ঘোরান"),
        Icons.Filled.RotateRight, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),
    DELETE_PDF_PAGES(
        ToolCategory.PDF_TOOLS,
        BiText("Delete PDF Pages", "PDF পেজ মুছুন"),
        BiText("Remove unwanted pages from a PDF", "PDF থেকে অপ্রয়োজনীয় পৃষ্ঠা বাদ দিন"),
        Icons.Filled.DeleteSweep, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),
    EXTRACT_PDF_PAGES(
        ToolCategory.PDF_TOOLS,
        BiText("Extract PDF Pages", "PDF পেজ আলাদা করুন"),
        BiText("Save selected pages into a new PDF", "নির্বাচিত পৃষ্ঠাগুলো দিয়ে নতুন PDF তৈরি"),
        Icons.Filled.FileCopy, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),
    REARRANGE_PDF_PAGES(
        ToolCategory.PDF_TOOLS,
        BiText("Rearrange Pages", "পেজের ক্রম বদলান"),
        BiText("Reorder PDF pages in any custom sequence", "ইচ্ছেমতো PDF পৃষ্ঠার ক্রম সাজান"),
        Icons.Filled.Reorder, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),
    UNLOCK_PDF(
        ToolCategory.PDF_TOOLS,
        BiText("Unlock PDF", "PDF আনলক করুন"),
        BiText("Remove password from authorized PDFs", "অনুমোদিত PDF-এর পাসওয়ার্ড সরান"),
        Icons.Filled.LockOpen, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),
    PROTECT_PDF(
        ToolCategory.PDF_TOOLS,
        BiText("Protect PDF", "PDF লক করুন"),
        BiText("Encrypt PDF with AES/RC4 password protection", "পাসওয়ার্ড দিয়ে PDF সুরক্ষিত করুন"),
        Icons.Filled.Lock, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),
    ADD_WATERMARK(
        ToolCategory.PDF_TOOLS,
        BiText("Add Watermark", "ওয়াটারমার্ক যোগ"),
        BiText("Stamp diagonal watermark text across PDF pages", "সব পেজে কাস্টম ওয়াটারমার্ক যুক্ত করুন"),
        Icons.Filled.WaterDrop, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),
    ADD_PAGE_NUMBER(
        ToolCategory.PDF_TOOLS,
        BiText("Add Page Numbers", "পেজ নম্বর যোগ"),
        BiText("Insert formatted page numbers to PDF", "PDF পৃষ্ঠায় স্বয়ংক্রিয় নম্বর বসান"),
        Icons.Filled.FormatListNumbered, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),
    PDF_METADATA(
        ToolCategory.PDF_TOOLS,
        BiText("PDF Metadata Viewer", "PDF মেটাডেটা দেখুন"),
        BiText("Inspect & edit Title, Author, Keywords & info", "Title, Author, Keywords ও তথ্য দেখুন/বদলান"),
        Icons.Filled.Info, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),

    // 4. Word Converter
    DOC_TO_PDF(
        ToolCategory.WORD_CONVERTER,
        BiText("DOC to PDF", "DOC থেকে PDF"),
        BiText("Extract & convert legacy .doc to PDF (or server)", "লিগ্যাসি .doc ফাইল থেকে PDF তৈরি"),
        Icons.Filled.Description, InputPickerMode.SINGLE_DOC,
        listOf("application/msword", "*/*"), listOf("doc")
    ),
    DOCX_TO_PDF(
        ToolCategory.WORD_CONVERTER,
        BiText("DOCX to PDF", "DOCX থেকে PDF"),
        BiText("Convert Word .docx with headings, tables & images", "হেডিং, টেবিল ও ছবিসহ DOCX থেকে PDF"),
        Icons.Filled.Description, InputPickerMode.SINGLE_DOC,
        listOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "*/*"), listOf("docx")
    ),
    PDF_TO_DOC(
        ToolCategory.WORD_CONVERTER,
        BiText("PDF to DOC", "PDF থেকে DOC"),
        BiText("Convert PDF with OCR & tables into Word .doc", "OCR ও টেবিলসহ PDF থেকে Word .doc"),
        Icons.Filled.Description, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),
    PDF_TO_DOCX(
        ToolCategory.WORD_CONVERTER,
        BiText("PDF to DOCX", "PDF থেকে DOCX"),
        BiText("Preserve layout, tables & scanned OCR to .docx", "টেবিল, ফরম্যাটিং ও OCR-সহ PDF থেকে DOCX"),
        Icons.Filled.Description, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),
    WORD_PREVIEW(
        ToolCategory.WORD_CONVERTER,
        BiText("Word File Preview", "Word ফাইল প্রিভিউ"),
        BiText("Inspect Word headings, tables, paragraphs & images", "Word ফাইলের টেক্সট, টেবিল ও ছবি প্রিভিউ"),
        Icons.Filled.Preview, InputPickerMode.SINGLE_DOC,
        listOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/msword", "*/*"), listOf("docx", "doc")
    ),
    WORD_MERGE(
        ToolCategory.WORD_CONVERTER,
        BiText("Word File Merge", "Word ফাইল যুক্ত করুন"),
        BiText("Combine multiple .docx documents into one", "একাধিক .docx ডকুমেন্ট একটিতে যুক্ত করুন"),
        Icons.AutoMirrored.Filled.MergeType, InputPickerMode.MULTIPLE_DOCS,
        listOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "*/*"), listOf("docx")
    ),
    WORD_COMPRESS(
        ToolCategory.WORD_CONVERTER,
        BiText("Word Compress", "Word কম্প্রেস"),
        BiText("Optimize embedded media & ZIP deflate in .docx", "DOCX-এর ছবি ও আকার অপটিমাইজ করুন"),
        Icons.Filled.Compress, InputPickerMode.SINGLE_DOC,
        listOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "*/*"), listOf("docx")
    ),

    // 5. Excel Converter
    XLS_TO_PDF(
        ToolCategory.EXCEL_CONVERTER,
        BiText("XLS to PDF", "XLS থেকে PDF"),
        BiText("Parse binary .xls sheets with orientation & print area", "বাইনারি .xls শিট থেকে PDF তৈরি"),
        Icons.Filled.TableChart, InputPickerMode.SINGLE_DOC,
        listOf("application/vnd.ms-excel", "*/*"), listOf("xls")
    ),
    XLSX_TO_PDF(
        ToolCategory.EXCEL_CONVERTER,
        BiText("XLSX to PDF", "XLSX থেকে PDF"),
        BiText("Select sheets, Fit-to-Page, Orientation & Print Area", "শিট নির্বাচন, Fit-to-Page ও Print Area সহ PDF"),
        Icons.Filled.TableChart, InputPickerMode.SINGLE_DOC,
        listOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "*/*"), listOf("xlsx")
    ),
    PDF_TO_XLS(
        ToolCategory.EXCEL_CONVERTER,
        BiText("PDF to XLS", "PDF থেকে XLS"),
        BiText("Extract PDF table cells into Excel .xls", "PDF টেবিল ও সেল ডেটা থেকে .xls তৈরি"),
        Icons.Filled.GridOn, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),
    PDF_TO_XLSX(
        ToolCategory.EXCEL_CONVERTER,
        BiText("PDF to XLSX", "PDF থেকে XLSX"),
        BiText("Extract tables, cells & OCR rows to .xlsx workbook", "টেবিল ও সেল ডেটাসহ PDF থেকে .xlsx তৈরি"),
        Icons.Filled.GridOn, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),
    EXCEL_DATA_EXTRACT(
        ToolCategory.EXCEL_CONVERTER,
        BiText("Excel Data Extract", "Excel ডেটা এক্সট্র্যাক্ট"),
        BiText("Extract sheets & print areas into JSON / CSV / Preview", "শিট ও সেল ডেটা JSON/CSV হিসেবে এক্সট্র্যাক্ট"),
        Icons.Filled.GridOn, InputPickerMode.SINGLE_DOC,
        listOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel", "*/*"), listOf("xlsx", "xls")
    ),

    // 6. PowerPoint Converter
    PPT_TO_PDF(
        ToolCategory.POWERPOINT_CONVERTER,
        BiText("PPT to PDF", "PPT থেকে PDF"),
        BiText("Convert legacy .ppt slide text into PDF", "লিগ্যাসি .ppt স্লাইড থেকে PDF"),
        Icons.Filled.Slideshow, InputPickerMode.SINGLE_DOC,
        listOf("application/vnd.ms-powerpoint", "*/*"), listOf("ppt")
    ),
    PPTX_TO_PDF(
        ToolCategory.POWERPOINT_CONVERTER,
        BiText("PPTX to PDF", "PPTX থেকে PDF"),
        BiText("Render PowerPoint .pptx slides & images to PDF", "স্লাইড ও ছবিসহ PPTX থেকে PDF"),
        Icons.Filled.Slideshow, InputPickerMode.SINGLE_DOC,
        listOf("application/vnd.openxmlformats-officedocument.presentationml.presentation", "*/*"), listOf("pptx")
    ),
    PDF_TO_PPT(
        ToolCategory.POWERPOINT_CONVERTER,
        BiText("PDF to PPT", "PDF থেকে PPT"),
        BiText("Convert PDF pages into PowerPoint presentation", "PDF পেজগুলো স্লাইড ডেকে রূপান্তর"),
        Icons.Filled.Slideshow, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),
    PDF_TO_PPTX(
        ToolCategory.POWERPOINT_CONVERTER,
        BiText("PDF to PPTX", "PDF থেকে PPTX"),
        BiText("Create editable .pptx slides from PDF pages", "PDF পেজ থেকে .pptx স্লাইড তৈরি"),
        Icons.Filled.Slideshow, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),
    PPT_TO_JPG(
        ToolCategory.POWERPOINT_CONVERTER,
        BiText("PPT Slide to JPG", "স্লাইড থেকে JPG"),
        BiText("Export every presentation slide as JPG + ZIP", "প্রতিটি স্লাইড JPG ছবি ও ZIP হিসেবে সেভ"),
        Icons.Filled.Image, InputPickerMode.SINGLE_DOC,
        listOf("application/vnd.openxmlformats-officedocument.presentationml.presentation", "application/vnd.ms-powerpoint", "*/*"), listOf("pptx", "ppt")
    ),
    PPT_TO_PNG(
        ToolCategory.POWERPOINT_CONVERTER,
        BiText("PPT Slide to PNG", "স্লাইড থেকে PNG"),
        BiText("Export crisp PNG slide images + ZIP bundle", "প্রতিটি স্লাইড PNG ছবি ও ZIP হিসেবে সেভ"),
        Icons.Filled.PhotoLibrary, InputPickerMode.SINGLE_DOC,
        listOf("application/vnd.openxmlformats-officedocument.presentationml.presentation", "application/vnd.ms-powerpoint", "*/*"), listOf("pptx", "ppt")
    ),

    // 7. Other File Converters
    TXT_TO_PDF(
        ToolCategory.OTHER_CONVERTER,
        BiText("TXT to PDF", "TXT থেকে PDF"),
        BiText("Convert UTF-8 / Bengali plain text to PDF", "ইউনিকোড/বাংলা টেক্সট ফাইল থেকে PDF"),
        Icons.Filled.TextFields, InputPickerMode.SINGLE_DOC,
        listOf("text/plain", "*/*"), listOf("txt")
    ),
    PDF_TO_TXT(
        ToolCategory.OTHER_CONVERTER,
        BiText("PDF to TXT", "PDF থেকে TXT"),
        BiText("Extract text & scanned PDF OCR to plain text", "OCR সাপোর্টসহ PDF থেকে টেক্সট এক্সট্র্যাক্ট"),
        Icons.Filled.TextFields, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),
    HTML_TO_PDF(
        ToolCategory.OTHER_CONVERTER,
        BiText("HTML to PDF", "HTML থেকে PDF"),
        BiText("Parse & render styled HTML pages into PDF", "HTML কোড/ফাইলকে স্টাইলসহ PDF করুন"),
        Icons.Filled.Code, InputPickerMode.SINGLE_DOC,
        listOf("text/html", "*/*"), listOf("html", "htm")
    ),
    RTF_TO_PDF(
        ToolCategory.OTHER_CONVERTER,
        BiText("RTF to PDF", "RTF থেকে PDF"),
        BiText("Decode Rich Text (.rtf) formatting into PDF", "RTF ফরম্যাটেড ডকুমেন্ট থেকে PDF"),
        Icons.Filled.Description, InputPickerMode.SINGLE_DOC,
        listOf("application/rtf", "text/rtf", "*/*"), listOf("rtf")
    ),
    CSV_TO_PDF(
        ToolCategory.OTHER_CONVERTER,
        BiText("CSV to PDF", "CSV থেকে PDF"),
        BiText("Format CSV tables into clean paginated PDF", "CSV টেবিলকে সুন্দর PDF সারণিতে রূপান্তর"),
        Icons.Filled.TableChart, InputPickerMode.SINGLE_DOC,
        listOf("text/csv", "text/comma-separated-values", "*/*"), listOf("csv")
    ),
    CSV_TO_XLSX(
        ToolCategory.OTHER_CONVERTER,
        BiText("CSV to XLSX", "CSV থেকে XLSX"),
        BiText("Convert CSV rows into an Excel .xlsx workbook", "CSV ডেটাকে Excel .xlsx ফাইলে রূপান্তর"),
        Icons.Filled.GridOn, InputPickerMode.SINGLE_DOC,
        listOf("text/csv", "text/comma-separated-values", "*/*"), listOf("csv")
    ),
    XLSX_TO_CSV(
        ToolCategory.OTHER_CONVERTER,
        BiText("XLSX to CSV", "XLSX থেকে CSV"),
        BiText("Export Excel sheets into UTF-8 CSV (or ZIP)", "Excel শিটগুলোকে CSV ও ZIP-এ এক্সপোর্ট"),
        Icons.Filled.TableChart, InputPickerMode.SINGLE_DOC,
        listOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "*/*"), listOf("xlsx", "xls")
    ),
    ODT_TO_PDF(
        ToolCategory.OTHER_CONVERTER,
        BiText("ODT to PDF", "ODT থেকে PDF"),
        BiText("Convert OpenDocument Text (.odt) to PDF", "OpenDocument (.odt) থেকে PDF"),
        Icons.Filled.Description, InputPickerMode.SINGLE_DOC,
        listOf("application/vnd.oasis.opendocument.text", "*/*"), listOf("odt")
    ),
    ODS_TO_PDF(
        ToolCategory.OTHER_CONVERTER,
        BiText("ODS to PDF", "ODS থেকে PDF"),
        BiText("Convert OpenDocument Spreadsheet (.ods) to PDF", "OpenDocument (.ods) শিট থেকে PDF"),
        Icons.Filled.TableChart, InputPickerMode.SINGLE_DOC,
        listOf("application/vnd.oasis.opendocument.spreadsheet", "*/*"), listOf("ods")
    ),
    ODP_TO_PDF(
        ToolCategory.OTHER_CONVERTER,
        BiText("ODP to PDF", "ODP থেকে PDF"),
        BiText("Convert OpenDocument Presentation (.odp) to PDF", "OpenDocument (.odp) স্লাইড থেকে PDF"),
        Icons.Filled.Slideshow, InputPickerMode.SINGLE_DOC,
        listOf("application/vnd.oasis.opendocument.presentation", "*/*"), listOf("odp")
    ),

    // 8. PDF Editor Suite
    PDF_EDITOR_SUITE(
        ToolCategory.PDF_EDITOR,
        BiText("Full PDF Editor", "সম্পূর্ণ PDF এডিটর"),
        BiText("Add Text, Highlight, Underline, Strike, Draw, Sign, Image & Crop", "টেক্সট, হাইলাইট, আঁকা, স্বাক্ষর, ছবি ও ক্রপ"),
        Icons.Filled.Edit, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),
    PDF_CROP(
        ToolCategory.PDF_EDITOR,
        BiText("Crop PDF Pages", "PDF পেজ ক্রপ"),
        BiText("Trim margins & adjust visible page crop box", "PDF পৃষ্ঠার মার্জিন ক্রপ করুন"),
        Icons.Filled.Crop, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),
    PDF_DRAW_SIGN(
        ToolCategory.PDF_EDITOR,
        BiText("Draw & Sign PDF", "আঁকুন ও স্বাক্ষর করুন"),
        BiText("Hand-drawn signature, freehand ink & digital stamp", "হাতে স্বাক্ষর, ড্রইং ও ডিজিটাল স্ট্যাম্প"),
        Icons.Filled.Draw, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),
    PDF_DIGITAL_STAMP(
        ToolCategory.PDF_EDITOR,
        BiText("Digital Signature Stamp", "ডিজিটাল সিগনেচার স্ট্যাম্প"),
        BiText("Apply verified signer timestamp & certificate seal", "সইকারীর নাম, সময় ও ডিজিটাল সিল যুক্ত করুন"),
        Icons.Filled.VerifiedUser, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),

    // 9. File Compressor
    COMPRESS_PDF_TARGET(
        ToolCategory.FILE_COMPRESSOR,
        BiText("PDF Target Compressor", "PDF টার্গেট কম্প্রেসর"),
        BiText("Compress PDF to exact target KB/MB size", "নির্দিষ্ট KB/MB টার্গেটে PDF কম্প্রেস"),
        Icons.Filled.Compress, InputPickerMode.SINGLE_PDF,
        listOf("application/pdf"), listOf("pdf")
    ),
    COMPRESS_JPG(
        ToolCategory.FILE_COMPRESSOR,
        BiText("JPG Compressor", "JPG কম্প্রেসর"),
        BiText("Compress JPG/JPEG by quality or target KB/MB", "কোয়ালিটি বা টার্গেট KB/MB-তে JPG কম্প্রেস"),
        Icons.Filled.Compress, InputPickerMode.MULTIPLE_IMAGES,
        listOf("image/jpeg"), listOf("jpg", "jpeg")
    ),
    COMPRESS_PNG(
        ToolCategory.FILE_COMPRESSOR,
        BiText("PNG Compressor", "PNG কম্প্রেসর"),
        BiText("Optimize & resize PNG to hit target KB/MB", "টার্গেট KB/MB-তে PNG অপটিমাইজ করুন"),
        Icons.Filled.Compress, InputPickerMode.MULTIPLE_IMAGES,
        listOf("image/png"), listOf("png")
    ),
    COMPRESS_WORD(
        ToolCategory.FILE_COMPRESSOR,
        BiText("Word Compressor", "Word কম্প্রেসর"),
        BiText("Compress embedded images & XML in .docx", ".docx ফাইলের ছবি ও আকার কমান"),
        Icons.Filled.Compress, InputPickerMode.SINGLE_DOC,
        listOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "*/*"), listOf("docx")
    ),
    COMPRESS_EXCEL(
        ToolCategory.FILE_COMPRESSOR,
        BiText("Excel Compressor", "Excel কম্প্রেসর"),
        BiText("Recompress .xlsx media & workbook streams", ".xlsx ফাইলের মিডিয়া ও স্ট্রিম কম্প্রেস"),
        Icons.Filled.Compress, InputPickerMode.SINGLE_DOC,
        listOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "*/*"), listOf("xlsx")
    ),
    COMPRESS_PPT(
        ToolCategory.FILE_COMPRESSOR,
        BiText("PowerPoint Compressor", "PowerPoint কম্প্রেসর"),
        BiText("Shrink .pptx slide images & media size", ".pptx স্লাইডের ছবি ও আকার কমান"),
        Icons.Filled.Compress, InputPickerMode.SINGLE_DOC,
        listOf("application/vnd.openxmlformats-officedocument.presentationml.presentation", "*/*"), listOf("pptx")
    )
}
