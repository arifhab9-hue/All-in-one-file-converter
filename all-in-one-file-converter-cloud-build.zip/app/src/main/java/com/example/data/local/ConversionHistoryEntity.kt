package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "conversion_history")
data class ConversionHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val toolIdName: String,
    val inputNames: String,
    val outputName: String,
    val outputPath: String,
    val outputMimeType: String,
    val originalBytes: Long,
    val outputBytes: Long,
    val pageCount: Int,
    val timestamp: Long = System.currentTimeMillis()
)
