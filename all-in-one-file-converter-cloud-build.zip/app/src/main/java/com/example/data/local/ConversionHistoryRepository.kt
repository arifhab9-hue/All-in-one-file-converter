package com.example.data.local

import kotlinx.coroutines.flow.Flow

class ConversionHistoryRepository(private val dao: ConversionHistoryDao) {
    val history: Flow<List<ConversionHistoryEntity>> = dao.observeAll()

    suspend fun record(entry: ConversionHistoryEntity) = dao.insert(entry)

    suspend fun delete(id: Long) = dao.deleteById(id)

    suspend fun clearAll() = dao.clearAll()
}
