package com.example.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.core.i18n.AppLanguage
import com.example.ui.theme.ThemePreference
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "converter_prefs")

data class UserSettings(
    val language: AppLanguage = AppLanguage.EN,
    val theme: ThemePreference = ThemePreference.SYSTEM,
    val autoOcr: Boolean = true,
    val defaultDpi: Int = 150,
    val optionalBackendUrl: String = ""
)

class UserPreferencesRepository(private val context: Context) {
    private object Keys {
        val LANGUAGE = stringPreferencesKey("language")
        val THEME = stringPreferencesKey("theme")
        val AUTO_OCR = booleanPreferencesKey("auto_ocr")
        val DEFAULT_DPI = intPreferencesKey("default_dpi")
        val BACKEND_URL = stringPreferencesKey("backend_url")
    }

    val settings: Flow<UserSettings> = context.dataStore.data.map { prefs ->
        val lang = AppLanguage.entries.find { it.name == prefs[Keys.LANGUAGE] } ?: AppLanguage.EN
        val theme = ThemePreference.entries.find { it.name == prefs[Keys.THEME] } ?: ThemePreference.SYSTEM
        val ocr = prefs[Keys.AUTO_OCR] ?: true
        val dpi = prefs[Keys.DEFAULT_DPI] ?: 150
        val url = prefs[Keys.BACKEND_URL] ?: ""
        UserSettings(
            language = lang,
            theme = theme,
            autoOcr = ocr,
            defaultDpi = dpi,
            optionalBackendUrl = url
        )
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { it[Keys.LANGUAGE] = language.name }
    }

    suspend fun setTheme(theme: ThemePreference) {
        context.dataStore.edit { it[Keys.THEME] = theme.name }
    }

    suspend fun setAutoOcr(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_OCR] = enabled }
    }

    suspend fun setDefaultDpi(dpi: Int) {
        context.dataStore.edit { it[Keys.DEFAULT_DPI] = dpi }
    }

    suspend fun setBackendUrl(url: String) {
        context.dataStore.edit { it[Keys.BACKEND_URL] = url.trim() }
    }
}
