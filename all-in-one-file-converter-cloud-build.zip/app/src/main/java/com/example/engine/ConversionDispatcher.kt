package com.example.engine

import android.content.Context
import com.example.core.model.ConversionOptions
import com.example.core.model.ConversionOutputFile
import com.example.core.model.ConversionResult
import com.example.core.model.ToolId
import com.example.core.model.WorkspaceFile

object ConversionDispatcher {

    suspend fun execute(
        context: Context,
        toolId: ToolId,
        files: List<WorkspaceFile>,
        options: ConversionOptions,
        optionalBackendUrl: String = "",
        useServerIfConfigured: Boolean = false,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        if (files.isEmpty()) throw IllegalArgumentException("Please select at least one file.")

        // Optional user-configured self-hosted server conversion for Office -> PDF
        if (useServerIfConfigured && optionalBackendUrl.isNotBlank() && isOfficeToPdfTool(toolId)) {
            onProgress(0.25f)
            val first = files.first()
            val outName = "${first.name.substringBeforeLast('.')}.pdf"
            val outFile = OptionalBackendClient.convertViaServer(context, optionalBackendUrl, first.localFile, outName)
            onProgress(1f)
            return ConversionResult(
                toolId = toolId,
                outputFiles = listOf(ConversionOutputFile(outFile.name, outFile, "application/pdf", outFile.length())),
                originalTotalBytes = first.sizeBytes,
                outputTotalBytes = outFile.length(),
                pageCount = PdfToolsEngine.getPageCount(context, outFile),
                note = "Converted via configured self-hosted server backend."
            )
        }

        return when (toolId) {
            // 1. Image to PDF
            ToolId.JPG_TO_PDF,
            ToolId.JPEG_TO_PDF,
            ToolId.PNG_TO_PDF,
            ToolId.WEBP_TO_PDF,
            ToolId.BMP_TO_PDF,
            ToolId.TIFF_TO_PDF,
            ToolId.IMAGES_TO_PDF -> ImagePdfEngine.imagesToPdf(context, toolId, files, options, onProgress)

            // 2. PDF to Image
            ToolId.PDF_TO_JPG,
            ToolId.PDF_TO_JPEG,
            ToolId.PDF_TO_PNG,
            ToolId.PDF_TO_WEBP -> ImagePdfEngine.pdfToImages(context, toolId, files.first(), options, onProgress)

            // 3. PDF Tools
            ToolId.MERGE_PDF -> PdfToolsEngine.mergePdfs(context, files, onProgress)
            ToolId.SPLIT_PDF -> PdfToolsEngine.splitPdf(context, files.first(), options.pageRange, onProgress)
            ToolId.COMPRESS_PDF,
            ToolId.COMPRESS_PDF_TARGET -> PdfToolsEngine.compressPdf(context, toolId, files.first(), options, onProgress)
            ToolId.ROTATE_PDF -> PdfToolsEngine.rotatePdf(context, files.first(), options, onProgress)
            ToolId.DELETE_PDF_PAGES -> PdfToolsEngine.deletePages(context, files.first(), options.pageRange, onProgress)
            ToolId.EXTRACT_PDF_PAGES,
            ToolId.REARRANGE_PDF_PAGES -> PdfToolsEngine.extractOrRearrangePages(context, toolId, files.first(), options.pageRange, onProgress)
            ToolId.UNLOCK_PDF -> PdfToolsEngine.unlockPdf(context, files.first(), options.password, options.authorizedToUnlock, onProgress)
            ToolId.PROTECT_PDF -> PdfToolsEngine.protectPdf(context, files.first(), options.password, onProgress)
            ToolId.ADD_WATERMARK -> PdfToolsEngine.addWatermark(context, files.first(), options.watermarkText, onProgress)
            ToolId.ADD_PAGE_NUMBER -> PdfToolsEngine.addPageNumbers(context, files.first(), options.pageNumberPrefix, onProgress)
            ToolId.PDF_METADATA -> PdfToolsEngine.updateMetadata(context, files.first(), options)

            // 4. Word Converter
            ToolId.DOC_TO_PDF,
            ToolId.DOCX_TO_PDF -> OfficeWordEngine.wordToPdf(context, toolId, files.first(), onProgress)
            ToolId.PDF_TO_DOC,
            ToolId.PDF_TO_DOCX -> OfficeWordEngine.pdfToWord(context, toolId, files.first(), options, onProgress)
            ToolId.WORD_PREVIEW -> OfficeWordEngine.previewWord(files.first())
            ToolId.WORD_MERGE -> OfficeWordEngine.mergeDocx(context, files, onProgress)
            ToolId.WORD_COMPRESS,
            ToolId.COMPRESS_WORD -> OfficeWordEngine.compressDocx(context, toolId, files.first(), options, onProgress)

            // 5. Excel Converter
            ToolId.XLS_TO_PDF,
            ToolId.XLSX_TO_PDF,
            ToolId.ODS_TO_PDF,
            ToolId.CSV_TO_PDF -> OfficeExcelEngine.excelToPdf(context, toolId, files.first(), options, onProgress)
            ToolId.PDF_TO_XLS,
            ToolId.PDF_TO_XLSX -> OfficeExcelEngine.pdfToExcel(context, toolId, files.first(), options, onProgress)
            ToolId.EXCEL_DATA_EXTRACT -> OfficeExcelEngine.extractExcelData(context, files.first(), options, onProgress)

            // 6. PowerPoint Converter
            ToolId.PPT_TO_PDF,
            ToolId.PPTX_TO_PDF,
            ToolId.ODP_TO_PDF -> OfficePowerPointEngine.presentationToPdf(context, toolId, files.first(), onProgress)
            ToolId.PDF_TO_PPT,
            ToolId.PDF_TO_PPTX -> OfficePowerPointEngine.pdfToPowerPoint(context, toolId, files.first(), options, onProgress)
            ToolId.PPT_TO_JPG,
            ToolId.PPT_TO_PNG -> OfficePowerPointEngine.slidesToImages(context, toolId, files.first(), options, onProgress)

            // 7. Other Converters
            ToolId.TXT_TO_PDF -> TextFormatEngine.txtToPdf(context, files.first(), onProgress)
            ToolId.PDF_TO_TXT -> TextFormatEngine.pdfToTxt(context, files.first(), options, onProgress)
            ToolId.HTML_TO_PDF -> TextFormatEngine.htmlToPdf(context, files.first(), onProgress)
            ToolId.RTF_TO_PDF -> TextFormatEngine.rtfToPdf(context, files.first(), onProgress)
            ToolId.CSV_TO_XLSX -> OfficeExcelEngine.csvToXlsx(context, files.first(), onProgress)
            ToolId.XLSX_TO_CSV -> OfficeExcelEngine.xlsxToCsv(context, files.first(), onProgress)
            ToolId.ODT_TO_PDF -> TextFormatEngine.odtToPdf(context, files.first(), onProgress)

            // 8. PDF Editor quick actions (also accessible from full PdfEditorScreen)
            ToolId.PDF_EDITOR_SUITE,
            ToolId.PDF_CROP,
            ToolId.PDF_DRAW_SIGN,
            ToolId.PDF_DIGITAL_STAMP -> throw IllegalStateException("Open in interactive PDF Editor")

            // 9. Compressors
            ToolId.COMPRESS_JPG,
            ToolId.COMPRESS_PNG -> ImagePdfEngine.compressImages(context, toolId, files, options, onProgress)
            ToolId.COMPRESS_EXCEL -> OfficeExcelEngine.compressXlsx(context, toolId, files.first(), options, onProgress)
            ToolId.COMPRESS_PPT -> OfficePowerPointEngine.compressPptx(context, toolId, files.first(), options, onProgress)
        }
    }

    private fun isOfficeToPdfTool(toolId: ToolId): Boolean = toolId in setOf(
        ToolId.DOC_TO_PDF, ToolId.DOCX_TO_PDF,
        ToolId.XLS_TO_PDF, ToolId.XLSX_TO_PDF,
        ToolId.PPT_TO_PDF, ToolId.PPTX_TO_PDF,
        ToolId.ODT_TO_PDF, ToolId.ODS_TO_PDF, ToolId.ODP_TO_PDF
    )
}
