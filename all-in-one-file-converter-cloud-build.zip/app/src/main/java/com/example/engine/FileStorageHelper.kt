package com.example.engine

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import com.example.core.model.WorkspaceFile
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object FileStorageHelper {

    const val MAX_RECOMMENDED_MB = 80L

    fun getWorkspaceInputDir(context: Context): File =
        File(context.filesDir, "workspace/inputs").apply { mkdirs() }

    fun getWorkspaceOutputDir(context: Context): File =
        File(context.filesDir, "workspace/outputs").apply { mkdirs() }

    fun getDisplayName(context: Context, uri: Uri): String {
        var name: String? = null
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) name = cursor.getString(idx)
                }
            }
        }
        if (name.isNullOrBlank()) {
            name = uri.lastPathSegment?.substringAfterLast('/') ?: "document_${System.currentTimeMillis()}"
        }
        return sanitizeFileName(name!!)
    }

    fun sanitizeFileName(name: String): String {
        return name.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "file" }
    }

    fun copyUriToWorkspace(context: Context, uri: Uri): WorkspaceFile {
        val originalName = getDisplayName(context, uri)
        val mime = context.contentResolver.getType(uri) ?: guessMimeFromName(originalName)
        val destFile = uniqueFile(getWorkspaceInputDir(context), originalName)

        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(destFile).use { output ->
                input.copyTo(output, bufferSize = 64 * 1024)
            }
        } ?: throw IllegalStateException("Cannot read selected file: $originalName")

        val size = destFile.length()
        if (size > MAX_RECOMMENDED_MB * 1024L * 1024L) {
            destFile.delete()
            throw IllegalArgumentException(
                "File '$originalName' (${formatSize(size)}) exceeds the ${MAX_RECOMMENDED_MB} MB on-device processing limit."
            )
        }

        return WorkspaceFile(
            id = UUID.randomUUID().toString(),
            name = originalName,
            localFile = destFile,
            mimeType = mime,
            sizeBytes = size
        )
    }

    fun createOutputFile(context: Context, desiredName: String): File {
        return uniqueFile(getWorkspaceOutputDir(context), sanitizeFileName(desiredName))
    }

    fun uniqueFile(dir: File, name: String): File {
        dir.mkdirs()
        var candidate = File(dir, name)
        if (!candidate.exists()) return candidate
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var counter = 1
        while (candidate.exists()) {
            candidate = File(dir, "${base}_$counter$ext")
            counter++
        }
        return candidate
    }

    fun createZipArchive(files: List<File>, zipOutputFile: File): File {
        ZipOutputStream(BufferedOutputStream(FileOutputStream(zipOutputFile))).use { zos ->
            val usedNames = mutableSetOf<String>()
            for (file in files) {
                if (!file.exists()) continue
                var entryName = file.name
                var idx = 1
                while (!usedNames.add(entryName)) {
                    val dot = file.name.lastIndexOf('.')
                    entryName = if (dot > 0) {
                        "${file.name.substring(0, dot)}_$idx${file.name.substring(dot)}"
                    } else {
                        "${file.name}_$idx"
                    }
                    idx++
                }
                zos.putNextEntry(ZipEntry(entryName))
                BufferedInputStream(FileInputStream(file)).use { bis ->
                    bis.copyTo(zos, 32 * 1024)
                }
                zos.closeEntry()
            }
        }
        return zipOutputFile
    }

    fun shareFile(context: Context, file: File, mimeType: String) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, file.name))
    }

    fun openFileExternally(context: Context, file: File, mimeType: String) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, file.name))
    }

    fun copyFileToUri(context: Context, source: File, destinationUri: Uri) {
        context.contentResolver.openOutputStream(destinationUri)?.use { out ->
            FileInputStream(source).use { input ->
                input.copyTo(out, 64 * 1024)
            }
        } ?: throw IllegalStateException("Unable to write to destination location")
    }

    fun formatSize(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024.0) return String.format("%.1f KB", kb)
        val mb = kb / 1024.0
        return String.format("%.2f MB", mb)
    }

    fun guessMimeFromName(name: String): String {
        return when (name.substringAfterLast('.', "").lowercase()) {
            "pdf" -> "application/pdf"
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "webp" -> "image/webp"
            "bmp" -> "image/bmp"
            "tif", "tiff" -> "image/tiff"
            "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            "doc" -> "application/msword"
            "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            "xls" -> "application/vnd.ms-excel"
            "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
            "ppt" -> "application/vnd.ms-powerpoint"
            "txt" -> "text/plain"
            "html", "htm" -> "text/html"
            "rtf" -> "application/rtf"
            "csv" -> "text/csv"
            "odt" -> "application/vnd.oasis.opendocument.text"
            "ods" -> "application/vnd.oasis.opendocument.spreadsheet"
            "odp" -> "application/vnd.oasis.opendocument.presentation"
            "zip" -> "application/zip"
            else -> "application/octet-stream"
        }
    }
}
