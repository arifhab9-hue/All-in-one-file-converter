package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.Build
import android.os.ParcelFileDescriptor
import com.example.core.model.ConversionOptions
import com.example.core.model.ConversionOutputFile
import com.example.core.model.ConversionResult
import com.example.core.model.OutputImageFormat
import com.example.core.model.PageOrientation
import com.example.core.model.ToolId
import com.example.core.model.WorkspaceFile
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

object ImagePdfEngine {

    fun decodeImageSafe(file: File, maxDim: Int = 2400): Bitmap {
        val ext = file.extension.lowercase()
        if (ext == "tif" || ext == "tiff") {
            return TiffDecoder.decode(file)
                ?: throw IllegalStateException("Could not decode TIFF image: ${file.name}")
        }

        val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, boundsOpts)
        if (boundsOpts.outWidth <= 0 || boundsOpts.outHeight <= 0) {
            throw IllegalStateException("Unsupported or corrupted image: ${file.name}")
        }

        var sample = 1
        while (boundsOpts.outWidth / sample > maxDim || boundsOpts.outHeight / sample > maxDim) {
            sample *= 2
        }
        val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeFile(file.absolutePath, decodeOpts)
            ?: throw IllegalStateException("Failed to decode image: ${file.name}")
    }

    fun imagesToPdf(
        context: Context,
        toolId: ToolId,
        files: List<WorkspaceFile>,
        options: ConversionOptions,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        if (files.isEmpty()) throw IllegalArgumentException("No images selected")
        val pdfDoc = PdfDocument()
        val rawW = options.pageSize.widthPt.toInt()
        val rawH = options.pageSize.heightPt.toInt()
        val pageW = if (options.orientation == PageOrientation.LANDSCAPE) maxOf(rawW, rawH) else minOf(rawW, rawH)
        val pageH = if (options.orientation == PageOrientation.LANDSCAPE) minOf(rawW, rawH) else maxOf(rawW, rawH)
        val margin = options.margin.points

        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        try {
            files.forEachIndexed { index, wsFile ->
                onProgress((index.toFloat() / files.size) * 0.9f)
                val bmp = decodeImageSafe(wsFile.localFile, maxDim = 2200)
                try {
                    val pageInfo = PdfDocument.PageInfo.Builder(pageW, pageH, index + 1).create()
                    val page = pdfDoc.startPage(pageInfo)
                    val canvas = page.canvas
                    canvas.drawColor(Color.WHITE)

                    val availW = (pageW - margin * 2f).coerceAtLeast(20f)
                    val availH = (pageH - margin * 2f).coerceAtLeast(20f)
                    val scale = minOf(availW / bmp.width, availH / bmp.height)
                    val drawW = bmp.width * scale
                    val drawH = bmp.height * scale
                    val left = margin + (availW - drawW) / 2f
                    val top = margin + (availH - drawH) / 2f

                    canvas.drawBitmap(bmp, null, RectF(left, top, left + drawW, top + drawH), paint)
                    pdfDoc.finishPage(page)
                } finally {
                    bmp.recycle()
                }
            }

            val baseName = files.first().name.substringBeforeLast('.')
            val outName = if (files.size == 1) "${baseName}.pdf" else "images_combined_${files.size}.pdf"
            val outFile = FileStorageHelper.createOutputFile(context, outName)
            FileOutputStream(outFile).use { pdfDoc.writeTo(it) }
            onProgress(1f)

            val origTotal = files.sumOf { it.sizeBytes }
            return ConversionResult(
                toolId = toolId,
                outputFiles = listOf(
                    ConversionOutputFile(outFile.name, outFile, "application/pdf", outFile.length())
                ),
                originalTotalBytes = origTotal,
                outputTotalBytes = outFile.length(),
                pageCount = files.size
            )
        } finally {
            pdfDoc.close()
        }
    }

    fun pdfToImages(
        context: Context,
        toolId: ToolId,
        pdfFile: WorkspaceFile,
        options: ConversionOptions,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        val format = when (toolId) {
            ToolId.PDF_TO_PNG -> OutputImageFormat.PNG
            ToolId.PDF_TO_WEBP -> OutputImageFormat.WEBP
            ToolId.PDF_TO_JPEG -> OutputImageFormat.JPEG
            ToolId.PDF_TO_JPG -> OutputImageFormat.JPG
            else -> options.outputImageFormat
        }
        val pfd = ParcelFileDescriptor.open(pdfFile.localFile, ParcelFileDescriptor.MODE_READ_ONLY)
        val renderer = PdfRenderer(pfd)
        val outputs = mutableListOf<ConversionOutputFile>()
        val baseName = pdfFile.name.substringBeforeLast('.')
        val scale = (options.dpi / 72f).coerceIn(1f, 4.2f)

        try {
            val total = renderer.pageCount
            if (total == 0) throw IllegalStateException("PDF contains 0 pages")
            for (i in 0 until total) {
                onProgress((i.toFloat() / total) * 0.9f)
                renderer.openPage(i).use { page ->
                    val w = (page.width * scale).toInt().coerceIn(100, 3600)
                    val h = (page.height * scale).toInt().coerceIn(100, 4800)
                    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    val canvas = Canvas(bmp)
                    canvas.drawColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)

                    val outFile = FileStorageHelper.createOutputFile(
                        context,
                        "${baseName}_page_${i + 1}.${format.ext}"
                    )
                    FileOutputStream(outFile).use { fos ->
                        bmp.compress(toCompressFormat(format), options.quality.coerceIn(10, 100), fos)
                    }
                    bmp.recycle()
                    outputs.add(
                        ConversionOutputFile(
                            name = outFile.name,
                            file = outFile,
                            mimeType = format.mimeType,
                            sizeBytes = outFile.length()
                        )
                    )
                }
            }

            val zipFile = if (outputs.size > 1) {
                val z = FileStorageHelper.createOutputFile(context, "${baseName}_pages.zip")
                FileStorageHelper.createZipArchive(outputs.map { it.file }, z)
            } else null

            onProgress(1f)
            return ConversionResult(
                toolId = toolId,
                outputFiles = outputs,
                zipFile = zipFile,
                originalTotalBytes = pdfFile.sizeBytes,
                outputTotalBytes = outputs.sumOf { it.sizeBytes },
                pageCount = total
            )
        } finally {
            renderer.close()
            pfd.close()
        }
    }

    fun compressImages(
        context: Context,
        toolId: ToolId,
        files: List<WorkspaceFile>,
        options: ConversionOptions,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        if (files.isEmpty()) throw IllegalArgumentException("No image files selected")
        val isPngTool = toolId == ToolId.COMPRESS_PNG
        val compressFmt = if (isPngTool) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
        val ext = if (isPngTool) "png" else "jpg"
        val mime = if (isPngTool) "image/png" else "image/jpeg"

        val outputs = mutableListOf<ConversionOutputFile>()
        files.forEachIndexed { idx, ws ->
            onProgress((idx.toFloat() / files.size) * 0.9f)
            val originalBmp = decodeImageSafe(ws.localFile, maxDim = 2600)
            try {
                val outBytes = if (options.useTargetSize && options.targetSizeKb > 0) {
                    compressBitmapToTarget(
                        bitmap = originalBmp,
                        format = compressFmt,
                        targetBytes = options.targetSizeKb * 1024L,
                        initialQuality = options.quality
                    )
                } else {
                    val baos = ByteArrayOutputStream()
                    originalBmp.compress(compressFmt, options.quality.coerceIn(10, 100), baos)
                    baos.toByteArray()
                }
                val base = ws.name.substringBeforeLast('.')
                val outFile = FileStorageHelper.createOutputFile(context, "${base}_compressed.$ext")
                outFile.writeBytes(outBytes)
                outputs.add(ConversionOutputFile(outFile.name, outFile, mime, outFile.length()))
            } finally {
                originalBmp.recycle()
            }
        }

        val zipFile = if (outputs.size > 1) {
            val z = FileStorageHelper.createOutputFile(context, "compressed_images.zip")
            FileStorageHelper.createZipArchive(outputs.map { it.file }, z)
        } else null
        onProgress(1f)

        return ConversionResult(
            toolId = toolId,
            outputFiles = outputs,
            zipFile = zipFile,
            originalTotalBytes = files.sumOf { it.sizeBytes },
            outputTotalBytes = outputs.sumOf { it.sizeBytes },
            pageCount = outputs.size
        )
    }

    fun compressBitmapToTarget(
        bitmap: Bitmap,
        format: Bitmap.CompressFormat,
        targetBytes: Long,
        initialQuality: Int = 85
    ): ByteArray {
        val baos = ByteArrayOutputStream()
        if (format != Bitmap.CompressFormat.PNG) {
            var low = 10
            var high = initialQuality.coerceIn(15, 98)
            var bestBytes: ByteArray? = null
            while (low <= high) {
                val mid = (low + high) / 2
                baos.reset()
                bitmap.compress(format, mid, baos)
                val data = baos.toByteArray()
                if (data.size <= targetBytes) {
                    bestBytes = data
                    low = mid + 1
                } else {
                    high = mid - 1
                }
            }
            if (bestBytes != null) return bestBytes
        }

        // Scale down progressively if quality alone (or PNG) cannot reach targetBytes
        var scale = 0.85f
        var currentBmp = bitmap
        var latest = ByteArray(0)
        repeat(8) {
            val w = (bitmap.width * scale).toInt().coerceAtLeast(64)
            val h = (bitmap.height * scale).toInt().coerceAtLeast(64)
            val scaled = Bitmap.createScaledBitmap(bitmap, w, h, true)
            if (currentBmp !== bitmap) currentBmp.recycle()
            currentBmp = scaled
            baos.reset()
            currentBmp.compress(format, if (format == Bitmap.CompressFormat.PNG) 100 else 65, baos)
            latest = baos.toByteArray()
            if (latest.size <= targetBytes) {
                if (currentBmp !== bitmap) currentBmp.recycle()
                return latest
            }
            scale *= 0.78f
        }
        if (currentBmp !== bitmap) currentBmp.recycle()
        return latest
    }

    @Suppress("DEPRECATION")
    private fun toCompressFormat(format: OutputImageFormat): Bitmap.CompressFormat {
        return when (format) {
            OutputImageFormat.JPG, OutputImageFormat.JPEG -> Bitmap.CompressFormat.JPEG
            OutputImageFormat.PNG -> Bitmap.CompressFormat.PNG
            OutputImageFormat.WEBP -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Bitmap.CompressFormat.WEBP_LOSSY
            } else {
                Bitmap.CompressFormat.WEBP
            }
        }
    }
}
