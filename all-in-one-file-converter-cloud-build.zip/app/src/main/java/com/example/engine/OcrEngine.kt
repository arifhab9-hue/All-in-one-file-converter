package com.example.engine

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class OcrLineBox(
    val text: String,
    val bounds: Rect
)

data class OcrPageResult(
    val fullText: String,
    val lines: List<OcrLineBox>,
    val imageWidth: Int,
    val imageHeight: Int
)

object OcrEngine {

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    suspend fun recognizeBitmap(bitmap: Bitmap): OcrPageResult =
        suspendCancellableCoroutine { cont ->
            val image = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    val lines = mutableListOf<OcrLineBox>()
                    for (block in visionText.textBlocks) {
                        for (line in block.lines) {
                            val rect = line.boundingBox ?: Rect(0, 0, bitmap.width, 20)
                            lines.add(OcrLineBox(line.text, rect))
                        }
                    }
                    if (cont.isActive) {
                        cont.resume(
                            OcrPageResult(
                                fullText = visionText.text,
                                lines = lines,
                                imageWidth = bitmap.width,
                                imageHeight = bitmap.height
                            )
                        )
                    }
                }
                .addOnFailureListener { e ->
                    if (cont.isActive) cont.resumeWithException(e)
                }
        }
}
