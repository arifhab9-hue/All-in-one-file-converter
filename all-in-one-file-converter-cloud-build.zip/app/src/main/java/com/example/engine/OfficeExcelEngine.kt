package com.example.engine

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.example.core.model.ConversionOptions
import com.example.core.model.ConversionOutputFile
import com.example.core.model.ConversionResult
import com.example.core.model.PageOrientation
import com.example.core.model.ToolId
import com.example.core.model.WorkspaceFile
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.StringReader
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class ExcelSheetData(
    val name: String,
    val rows: List<List<String>>
)

object OfficeExcelEngine {

    fun parseWorkbook(file: File): List<ExcelSheetData> {
        val ext = file.extension.lowercase()
        return when {
            ext == "csv" -> listOf(ExcelSheetData("Sheet1", parseCsv(file.readText(Charsets.UTF_8))))
            ext == "ods" -> parseOdsSheets(file)
            ext == "xls" || Ole2BinaryReader.isOle2(file) -> {
                Ole2BinaryReader.extractXlsSheets(file).map { ExcelSheetData(it.name, it.rows) }
            }
            else -> parseXlsx(file)
        }
    }

    fun inspectSheetNames(file: File): List<String> {
        return try {
            parseWorkbook(file).map { it.name }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun parseXlsx(file: File): List<ExcelSheetData> {
        val entries = OfficeWordEngine.readZipEntries(file)
        val sharedStrings = entries["xl/sharedStrings.xml"]?.let { parseSharedStrings(it.toString(Charsets.UTF_8)) } ?: emptyList()
        val workbookXml = entries["xl/workbook.xml"]?.toString(Charsets.UTF_8)
            ?: throw IllegalStateException("Invalid XLSX file: xl/workbook.xml missing")
        val relsMap = OfficeWordEngine.parseRels(entries["xl/_rels/workbook.xml.rels"]?.toString(Charsets.UTF_8))

        val sheetTargets = mutableListOf<Pair<String, String>>() // name -> zip path
        val parser = XmlPullParserFactory.newInstance().newPullParser()
        parser.setInput(StringReader(workbookXml))
        var ev = parser.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG && parser.name?.substringAfter(':') == "sheet") {
                val name = parser.getAttributeValue(null, "name") ?: "Sheet${sheetTargets.size + 1}"
                val rId = parser.getAttributeValue(null, "r:id") ?: parser.getAttributeValue(null, "id")
                val target = relsMap[rId]
                val path = when {
                    target == null -> "xl/worksheets/sheet${sheetTargets.size + 1}.xml"
                    target.startsWith("/") -> target.removePrefix("/")
                    target.startsWith("xl/") -> target
                    else -> "xl/$target"
                }
                sheetTargets.add(name to path)
            }
            ev = parser.next()
        }

        if (sheetTargets.isEmpty()) {
            entries.keys.filter { it.startsWith("xl/worksheets/sheet") && it.endsWith(".xml") }.sorted()
                .forEachIndexed { idx, p -> sheetTargets.add("Sheet${idx + 1}" to p) }
        }

        return sheetTargets.map { (name, path) ->
            val xml = entries[path]?.toString(Charsets.UTF_8) ?: ""
            ExcelSheetData(name, if (xml.isEmpty()) emptyList() else parseWorksheetXml(xml, sharedStrings))
        }
    }

    private fun parseSharedStrings(xml: String): List<String> {
        val list = mutableListOf<String>()
        val parser = XmlPullParserFactory.newInstance().newPullParser()
        parser.setInput(StringReader(xml))
        var inSi = false
        var inT = false
        val sb = StringBuilder()
        var ev = parser.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            val tag = parser.name?.substringAfter(':')
            when (ev) {
                XmlPullParser.START_TAG -> {
                    if (tag == "si") { inSi = true; sb.clear() }
                    else if (tag == "t" && inSi) inT = true
                }
                XmlPullParser.TEXT -> if (inSi && inT) sb.append(parser.text)
                XmlPullParser.END_TAG -> {
                    if (tag == "t") inT = false
                    else if (tag == "si" && inSi) { list.add(sb.toString()); inSi = false }
                }
            }
            ev = parser.next()
        }
        return list
    }

    private fun parseWorksheetXml(xml: String, sst: List<String>): List<List<String>> {
        val rowMap = sortedMapOf<Int, java.util.TreeMap<Int, String>>()
        val parser = XmlPullParserFactory.newInstance().newPullParser()
        parser.setInput(StringReader(xml))
        var ev = parser.eventType
        var currentRow = 0
        var currentCol = 0
        var cellType = ""
        var inV = false
        var inInlineT = false
        val valBuf = StringBuilder()

        while (ev != XmlPullParser.END_DOCUMENT) {
            val tag = parser.name?.substringAfter(':')
            when (ev) {
                XmlPullParser.START_TAG -> when (tag) {
                    "c" -> {
                        val ref = parser.getAttributeValue(null, "r") ?: ""
                        cellType = parser.getAttributeValue(null, "t") ?: ""
                        val (r, c) = parseCellRef(ref, currentRow, currentCol)
                        currentRow = r
                        currentCol = c
                        valBuf.clear()
                    }
                    "v" -> { inV = true; valBuf.clear() }
                    "t" -> if (cellType == "inlineStr") { inInlineT = true; valBuf.clear() }
                }
                XmlPullParser.TEXT -> if (inV || inInlineT) valBuf.append(parser.text)
                XmlPullParser.END_TAG -> when (tag) {
                    "v" -> inV = false
                    "t" -> inInlineT = false
                    "c" -> {
                        val raw = valBuf.toString().trim()
                        val resolved = when (cellType) {
                            "s" -> raw.toIntOrNull()?.let { sst.getOrNull(it) } ?: raw
                            "b" -> if (raw == "1") "TRUE" else "FALSE"
                            else -> raw
                        }
                        if (resolved.isNotEmpty()) {
                            rowMap.getOrPut(currentRow) { java.util.TreeMap<Int, String>() }[currentCol] = resolved
                        }
                        currentCol++
                    }
                }
            }
            ev = parser.next()
        }

        if (rowMap.isEmpty()) return emptyList()
        val maxRow = rowMap.keys.max()
        val maxCol = rowMap.values.maxOf { it.keys.maxOrNull() ?: 0 }
        return (0..maxRow).map { r ->
            val rm = rowMap[r] ?: emptyMap()
            (0..maxCol).map { c -> rm[c] ?: "" }
        }
    }

    fun parseSpreadsheetMl(xml: String): List<Ole2BinaryReader.BiffSheet> {
        val sheets = mutableListOf<Ole2BinaryReader.BiffSheet>()
        val parser = XmlPullParserFactory.newInstance().newPullParser()
        parser.setInput(StringReader(xml))
        var ev = parser.eventType
        var sheetName = "Sheet1"
        var rows = mutableListOf<List<String>>()
        var row = mutableListOf<String>()
        var inData = false
        val sb = StringBuilder()

        while (ev != XmlPullParser.END_DOCUMENT) {
            val tag = parser.name?.substringAfter(':')
            when (ev) {
                XmlPullParser.START_TAG -> when (tag) {
                    "Worksheet" -> {
                        sheetName = parser.getAttributeValue(null, "ss:Name")
                            ?: parser.getAttributeValue(null, "Name") ?: "Sheet${sheets.size + 1}"
                        rows = mutableListOf()
                    }
                    "Row" -> row = mutableListOf()
                    "Data" -> { inData = true; sb.clear() }
                }
                XmlPullParser.TEXT -> if (inData) sb.append(parser.text)
                XmlPullParser.END_TAG -> when (tag) {
                    "Data" -> { row.add(sb.toString().trim()); inData = false }
                    "Row" -> if (row.isNotEmpty()) rows.add(row)
                    "Worksheet" -> sheets.add(Ole2BinaryReader.BiffSheet(sheetName, rows))
                }
            }
            ev = parser.next()
        }
        return sheets
    }

    private fun parseOdsSheets(file: File): List<ExcelSheetData> {
        val entries = OfficeWordEngine.readZipEntries(file)
        val contentXml = entries["content.xml"]?.toString(Charsets.UTF_8)
            ?: throw IllegalStateException("Invalid ODS file: content.xml missing")
        val sheets = mutableListOf<ExcelSheetData>()
        val parser = XmlPullParserFactory.newInstance().newPullParser()
        parser.setInput(StringReader(contentXml))
        var ev = parser.eventType
        var tableName = "Sheet1"
        var rows = mutableListOf<List<String>>()
        var row = mutableListOf<String>()
        var inCell = false
        var repeatCols = 1
        val cellText = StringBuilder()

        while (ev != XmlPullParser.END_DOCUMENT) {
            val tag = parser.name?.substringAfter(':')
            when (ev) {
                XmlPullParser.START_TAG -> when (tag) {
                    "table" -> {
                        tableName = parser.getAttributeValue(null, "table:name")
                            ?: parser.getAttributeValue(null, "name") ?: "Sheet${sheets.size + 1}"
                        rows = mutableListOf()
                    }
                    "table-row" -> row = mutableListOf()
                    "table-cell" -> {
                        inCell = true
                        cellText.clear()
                        repeatCols = (parser.getAttributeValue(null, "table:number-columns-repeated")
                            ?: parser.getAttributeValue(null, "number-columns-repeated"))?.toIntOrNull()?.coerceAtMost(25) ?: 1
                    }
                }
                XmlPullParser.TEXT -> if (inCell) cellText.append(parser.text)
                XmlPullParser.END_TAG -> when (tag) {
                    "p" -> if (inCell && cellText.isNotEmpty()) cellText.append(" ")
                    "table-cell" -> if (inCell) {
                        val txt = cellText.toString().trim()
                        repeat(repeatCols) { row.add(txt) }
                        inCell = false
                    }
                    "table-row" -> if (row.any { it.isNotEmpty() }) rows.add(row)
                    "table" -> sheets.add(ExcelSheetData(tableName, rows))
                }
            }
            ev = parser.next()
        }
        return sheets
    }

    fun excelToPdf(
        context: Context,
        toolId: ToolId,
        wsFile: WorkspaceFile,
        options: ConversionOptions,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        onProgress(0.15f)
        val allSheets = parseWorkbook(wsFile.localFile)
        val chosen = if (options.selectedExcelSheets.isNotEmpty()) {
            allSheets.filter { it.name in options.selectedExcelSheets }
        } else allSheets

        if (chosen.isEmpty()) throw IllegalStateException("No sheets available to convert.")
        val slicedSheets = chosen.map { sliceByPrintArea(it, options.printArea) }

        val outFile = FileStorageHelper.createOutputFile(
            context,
            "${wsFile.name.substringBeforeLast('.')}.pdf"
        )
        val pageCount = renderSheetsToPdf(slicedSheets, options, outFile) { p ->
            onProgress(0.25f + p * 0.72f)
        }
        onProgress(1f)
        return ConversionResult(
            toolId = toolId,
            outputFiles = listOf(ConversionOutputFile(outFile.name, outFile, "application/pdf", outFile.length())),
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outFile.length(),
            pageCount = pageCount
        )
    }

    fun extractExcelData(
        context: Context,
        wsFile: WorkspaceFile,
        options: ConversionOptions,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        onProgress(0.2f)
        val allSheets = parseWorkbook(wsFile.localFile)
        val chosen = if (options.selectedExcelSheets.isNotEmpty()) {
            allSheets.filter { it.name in options.selectedExcelSheets }
        } else allSheets
        val sliced = chosen.map { sliceByPrintArea(it, options.printArea) }
        val base = wsFile.name.substringBeforeLast('.')

        val outputs = mutableListOf<ConversionOutputFile>()
        val preview = buildString {
            for (sheet in sliced) {
                appendLine("=== ${sheet.name} (${sheet.rows.size} rows) ===")
                sheet.rows.take(40).forEach { r -> appendLine(r.joinToString(" | ")) }
                if (sheet.rows.size > 40) appendLine("... (${sheet.rows.size - 40} more rows)")
                appendLine()
            }
        }

        if (options.excelExtractFormat == "JSON") {
            val rootObj = JsonObject(
                sliced.associate { sheet ->
                    val rowsJson = JsonArray(
                        sheet.rows.map { row -> JsonArray(row.map { JsonPrimitive(it) }) }
                    )
                    sheet.name to rowsJson
                }
            )
            val jsonFile = FileStorageHelper.createOutputFile(context, "${base}_extracted.json")
            jsonFile.writeText(rootObj.toString(), Charsets.UTF_8)
            outputs.add(ConversionOutputFile(jsonFile.name, jsonFile, "application/json", jsonFile.length()))
        } else {
            sliced.forEach { sheet ->
                val csvFile = FileStorageHelper.createOutputFile(
                    context,
                    "${base}_${FileStorageHelper.sanitizeFileName(sheet.name)}.csv"
                )
                csvFile.writeText("\uFEFF" + toCsvText(sheet.rows), Charsets.UTF_8)
                outputs.add(ConversionOutputFile(csvFile.name, csvFile, "text/csv", csvFile.length()))
            }
        }

        val zipFile = if (outputs.size > 1) {
            val z = FileStorageHelper.createOutputFile(context, "${base}_extracted_sheets.zip")
            FileStorageHelper.createZipArchive(outputs.map { it.file }, z)
        } else null
        onProgress(1f)
        return ConversionResult(
            toolId = ToolId.EXCEL_DATA_EXTRACT,
            outputFiles = outputs,
            zipFile = zipFile,
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outputs.sumOf { it.sizeBytes },
            pageCount = sliced.size,
            previewText = preview
        )
    }

    suspend fun pdfToExcel(
        context: Context,
        toolId: ToolId,
        wsFile: WorkspaceFile,
        options: ConversionOptions,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        val pages = PdfStructuredExtractor.extractPages(context, wsFile.localFile, options.enableOcr) { p ->
            onProgress(p * 0.8f)
        }
        val sheets = pages.mapIndexed { idx, p ->
            val rows = if (p.tableGrid.isNotEmpty()) p.tableGrid else p.rawText.lines().map { listOf(it) }
            ExcelSheetData("Page_${idx + 1}", rows)
        }
        val base = wsFile.name.substringBeforeLast('.')
        return if (toolId == ToolId.PDF_TO_XLS) {
            val outFile = FileStorageHelper.createOutputFile(context, "$base.xls")
            writeSpreadsheetMlXls(sheets, outFile)
            onProgress(1f)
            ConversionResult(
                toolId = toolId,
                outputFiles = listOf(ConversionOutputFile(outFile.name, outFile, "application/vnd.ms-excel", outFile.length())),
                originalTotalBytes = wsFile.sizeBytes,
                outputTotalBytes = outFile.length(),
                pageCount = sheets.size,
                note = "Generated as Excel SpreadsheetML (.xls) with extracted tables & cells. For legacy binary BIFF8 encoding, configure optional LibreOffice backend in Settings."
            )
        } else {
            val outFile = FileStorageHelper.createOutputFile(context, "$base.xlsx")
            writeXlsxWorkbook(sheets, outFile)
            onProgress(1f)
            ConversionResult(
                toolId = toolId,
                outputFiles = listOf(
                    ConversionOutputFile(
                        outFile.name,
                        outFile,
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        outFile.length()
                    )
                ),
                originalTotalBytes = wsFile.sizeBytes,
                outputTotalBytes = outFile.length(),
                pageCount = sheets.size
            )
        }
    }

    fun csvToXlsx(context: Context, wsFile: WorkspaceFile, onProgress: (Float) -> Unit): ConversionResult {
        onProgress(0.3f)
        val rows = parseCsv(wsFile.localFile.readText(Charsets.UTF_8))
        val outFile = FileStorageHelper.createOutputFile(context, "${wsFile.name.substringBeforeLast('.')}.xlsx")
        writeXlsxWorkbook(listOf(ExcelSheetData("Sheet1", rows)), outFile)
        onProgress(1f)
        return ConversionResult(
            toolId = ToolId.CSV_TO_XLSX,
            outputFiles = listOf(
                ConversionOutputFile(
                    outFile.name,
                    outFile,
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    outFile.length()
                )
            ),
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outFile.length(),
            pageCount = 1
        )
    }

    fun xlsxToCsv(context: Context, wsFile: WorkspaceFile, onProgress: (Float) -> Unit): ConversionResult {
        onProgress(0.25f)
        val sheets = parseWorkbook(wsFile.localFile)
        val base = wsFile.name.substringBeforeLast('.')
        val outputs = sheets.mapIndexed { idx, sheet ->
            onProgress(0.3f + (idx.toFloat() / sheets.size.coerceAtLeast(1)) * 0.6f)
            val safeSheet = FileStorageHelper.sanitizeFileName(sheet.name)
            val out = FileStorageHelper.createOutputFile(
                context,
                if (sheets.size == 1) "$base.csv" else "${base}_$safeSheet.csv"
            )
            out.writeText("\uFEFF" + toCsvText(sheet.rows), Charsets.UTF_8)
            ConversionOutputFile(out.name, out, "text/csv", out.length())
        }
        val zipFile = if (outputs.size > 1) {
            val z = FileStorageHelper.createOutputFile(context, "${base}_csv_sheets.zip")
            FileStorageHelper.createZipArchive(outputs.map { it.file }, z)
        } else null
        onProgress(1f)
        return ConversionResult(
            toolId = ToolId.XLSX_TO_CSV,
            outputFiles = outputs,
            zipFile = zipFile,
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outputs.sumOf { it.sizeBytes },
            pageCount = sheets.size
        )
    }

    fun compressXlsx(
        context: Context,
        toolId: ToolId,
        wsFile: WorkspaceFile,
        options: ConversionOptions,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        val outFile = FileStorageHelper.createOutputFile(
            context,
            "${wsFile.name.substringBeforeLast('.')}_compressed.xlsx"
        )
        OfficeWordEngine.compressOoxmlPackage(wsFile.localFile, outFile, "xl/media/", options, onProgress)
        return ConversionResult(
            toolId = toolId,
            outputFiles = listOf(
                ConversionOutputFile(
                    outFile.name,
                    outFile,
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    outFile.length()
                )
            ),
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outFile.length(),
            pageCount = 1
        )
    }

    fun renderSheetsToPdf(
        sheets: List<ExcelSheetData>,
        options: ConversionOptions,
        outFile: File,
        onProgress: (Float) -> Unit
    ): Int {
        val isLand = options.orientation == PageOrientation.LANDSCAPE
        val pageW = if (isLand) 842 else 595
        val pageH = if (isLand) 595 else 842
        val margin = 32f
        val availW = pageW - margin * 2f

        val pdf = PdfDocument()
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#059669")
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
        }
        val headerBg = Paint().apply { color = Color.parseColor("#ECFDF5") }
        val borderPaint = Paint().apply {
            color = Color.parseColor("#CBD5E1")
            style = Paint.Style.STROKE
            strokeWidth = 0.7f
        }
        val cellPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F172A")
            textSize = 9f
        }
        val headerCellPaint = TextPaint(cellPaint).apply {
            typeface = Typeface.DEFAULT_BOLD
        }

        var pageNum = 1
        var page = pdf.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNum).create())
        var canvas = page.canvas
        canvas.drawColor(Color.WHITE)
        var cursorY = margin

        fun newPage() {
            pdf.finishPage(page)
            pageNum++
            page = pdf.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNum).create())
            canvas = page.canvas
            canvas.drawColor(Color.WHITE)
            cursorY = margin
        }

        sheets.forEachIndexed { sIdx, sheet ->
            onProgress(sIdx.toFloat() / sheets.size.coerceAtLeast(1))
            if (sIdx > 0) newPage()
            canvas.drawText(sheet.name, margin, cursorY + 13f, titlePaint)
            cursorY += 24f

            val cols = (sheet.rows.maxOfOrNull { it.size } ?: 1).coerceAtLeast(1)
            val colW = if (options.fitToPage) {
                (availW / cols).coerceAtLeast(26f)
            } else {
                (availW / cols.coerceAtMost(8)).coerceAtLeast(52f)
            }
            val visibleCols = if (options.fitToPage) cols else (availW / colW).toInt().coerceAtLeast(1)
            val pad = 4f
            val fontSize = if (options.fitToPage && cols > 8) 7.5f else 9f
            cellPaint.textSize = fontSize
            headerCellPaint.textSize = fontSize

            for ((rIdx, row) in sheet.rows.withIndex()) {
                val p = if (rIdx == 0) headerCellPaint else cellPaint
                val layouts = (0 until visibleCols).map { c ->
                    val txt = row.getOrElse(c) { "" }
                    StaticLayout.Builder.obtain(txt, 0, txt.length, p, (colW - pad * 2).toInt().coerceAtLeast(12)).build()
                }
                val rowH = (layouts.maxOfOrNull { it.height } ?: 12) + pad * 2
                if (cursorY + rowH > pageH - margin) {
                    newPage()
                }
                for (c in 0 until visibleCols) {
                    val left = margin + c * colW
                    if (rIdx == 0) canvas.drawRect(left, cursorY, left + colW, cursorY + rowH, headerBg)
                    canvas.drawRect(left, cursorY, left + colW, cursorY + rowH, borderPaint)
                    canvas.save()
                    canvas.translate(left + pad, cursorY + pad)
                    layouts[c].draw(canvas)
                    canvas.restore()
                }
                cursorY += rowH
            }
        }
        pdf.finishPage(page)
        FileOutputStream(outFile).use { pdf.writeTo(it) }
        pdf.close()
        return pageNum
    }

    private fun writeXlsxWorkbook(sheets: List<ExcelSheetData>, outFile: File) {
        val sharedList = mutableListOf<String>()
        val sharedMap = mutableMapOf<String, Int>()
        fun intern(s: String): Int = sharedMap.getOrPut(s) { sharedList.add(s); sharedList.lastIndex }

        val sheetXmls = sheets.map { sheet ->
            val sb = StringBuilder("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>""")
            sheet.rows.forEachIndexed { rIdx, row ->
                val rowNum = rIdx + 1
                sb.append("<row r=\"$rowNum\">")
                row.forEachIndexed { cIdx, cellVal ->
                    val ref = "${colIndexToLetters(cIdx)}$rowNum"
                    val numVal = cellVal.toDoubleOrNull()
                    if (numVal != null && !cellVal.startsWith("0") || cellVal == "0") {
                        sb.append("<c r=\"$ref\"><v>$cellVal</v></c>")
                    } else if (cellVal.isNotEmpty()) {
                        val sIdx = intern(cellVal)
                        val styleAttr = if (rIdx == 0) " s=\"1\"" else ""
                        sb.append("<c r=\"$ref\" t=\"s\"$styleAttr><v>$sIdx</v></c>")
                    }
                }
                sb.append("</row>")
            }
            sb.append("</sheetData></worksheet>")
            sb.toString()
        }

        val sstXml = buildString {
            append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="${sharedList.size}" uniqueCount="${sharedList.size}">""")
            for (s in sharedList) {
                append("<si><t xml:space=\"preserve\">${OfficeWordEngine.xmlEscape(s)}</t></si>")
            }
            append("</sst>")
        }

        val workbookXml = buildString {
            append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>""")
            sheets.forEachIndexed { idx, s ->
                append("""<sheet name="${OfficeWordEngine.xmlEscape(s.name.take(31))}" sheetId="${idx + 1}" r:id="rId${idx + 1}"/>""")
            }
            append("</sheets></workbook>")
        }

        val wbRels = buildString {
            append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
            sheets.indices.forEach { idx ->
                append("""<Relationship Id="rId${idx + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${idx + 1}.xml"/>""")
            }
            append("""<Relationship Id="rId${sheets.size + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>""")
            append("""<Relationship Id="rId${sheets.size + 2}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>""")
            append("</Relationships>")
        }

        val stylesXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts>
  <fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>
  <borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs>
</styleSheet>"""

        val contentTypes = buildString {
            append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/contenttypes">""")
            append("""<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>""")
            append("""<Default Extension="xml" ContentType="application/xml"/>""")
            append("""<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>""")
            append("""<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>""")
            append("""<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>""")
            sheets.indices.forEach { idx ->
                append("""<Override PartName="/xl/worksheets/sheet${idx + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>""")
            }
            append("</Types>")
        }

        val rootRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>"""

        ZipOutputStream(BufferedOutputStream(FileOutputStream(outFile))).use { zos ->
            fun put(name: String, data: String) {
                zos.putNextEntry(ZipEntry(name))
                zos.write(data.toByteArray(Charsets.UTF_8))
                zos.closeEntry()
            }
            put("[Content_Types].xml", contentTypes)
            put("_rels/.rels", rootRels)
            put("xl/workbook.xml", workbookXml)
            put("xl/_rels/workbook.xml.rels", wbRels)
            put("xl/sharedStrings.xml", sstXml)
            put("xl/styles.xml", stylesXml)
            sheetXmls.forEachIndexed { idx, xml ->
                put("xl/worksheets/sheet${idx + 1}.xml", xml)
            }
        }
    }

    private fun writeSpreadsheetMlXls(sheets: List<ExcelSheetData>, outFile: File) {
        val sb = StringBuilder("""<?xml version="1.0" encoding="UTF-8"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">""")
        for (sheet in sheets) {
            sb.append("""<Worksheet ss:Name="${OfficeWordEngine.xmlEscape(sheet.name.take(31))}"><Table>""")
            for (row in sheet.rows) {
                sb.append("<Row>")
                for (cell in row) {
                    val isNum = cell.toDoubleOrNull() != null
                    val type = if (isNum) "Number" else "String"
                    sb.append("""<Cell><Data ss:Type="$type">${OfficeWordEngine.xmlEscape(cell)}</Data></Cell>""")
                }
                sb.append("</Row>")
            }
            sb.append("</Table></Worksheet>")
        }
        sb.append("</Workbook>")
        outFile.writeText(sb.toString(), Charsets.UTF_8)
    }

    private fun sliceByPrintArea(sheet: ExcelSheetData, printArea: String): ExcelSheetData {
        val match = Regex("^([A-Za-z]+)(\\d+):([A-Za-z]+)(\\d+)$").find(printArea.trim()) ?: return sheet
        val c1 = lettersToColIndex(match.groupValues[1])
        val r1 = (match.groupValues[2].toIntOrNull() ?: 1) - 1
        val c2 = lettersToColIndex(match.groupValues[3])
        val r2 = (match.groupValues[4].toIntOrNull() ?: sheet.rows.size) - 1
        val startR = minOf(r1, r2).coerceAtLeast(0)
        val endR = maxOf(r1, r2).coerceAtMost(sheet.rows.lastIndex)
        val startC = minOf(c1, c2).coerceAtLeast(0)
        val endC = maxOf(c1, c2)
        if (startR > endR) return sheet
        val slicedRows = (startR..endR).map { r ->
            val row = sheet.rows[r]
            if (startC > row.lastIndex) emptyList()
            else row.subList(startC, (endC + 1).coerceAtMost(row.size))
        }
        return ExcelSheetData(sheet.name, slicedRows)
    }

    private fun parseCellRef(ref: String, fallbackRow: Int, fallbackCol: Int): Pair<Int, Int> {
        val m = Regex("^([A-Za-z]+)(\\d+)$").find(ref) ?: return fallbackRow to fallbackCol
        return (m.groupValues[2].toInt() - 1).coerceAtLeast(0) to lettersToColIndex(m.groupValues[1])
    }

    private fun lettersToColIndex(letters: String): Int {
        var idx = 0
        for (ch in letters.uppercase()) {
            idx = idx * 26 + (ch - 'A' + 1)
        }
        return (idx - 1).coerceAtLeast(0)
    }

    private fun colIndexToLetters(col: Int): String {
        var n = col + 1
        val sb = StringBuilder()
        while (n > 0) {
            val rem = (n - 1) % 26
            sb.append(('A'.code + rem).toChar())
            n = (n - 1) / 26
        }
        return sb.reverse().toString()
    }

    fun parseCsv(content: String): List<List<String>> {
        val clean = content.removePrefix("\uFEFF")
        val rows = mutableListOf<List<String>>()
        var currentRow = mutableListOf<String>()
        val cell = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < clean.length) {
            val ch = clean[i]
            when {
                inQuotes -> {
                    if (ch == '"') {
                        if (i + 1 < clean.length && clean[i + 1] == '"') {
                            cell.append('"'); i++
                        } else {
                            inQuotes = false
                        }
                    } else {
                        cell.append(ch)
                    }
                }
                ch == '"' -> inQuotes = true
                ch == ',' -> { currentRow.add(cell.toString()); cell.clear() }
                ch == '\r' -> Unit
                ch == '\n' -> {
                    currentRow.add(cell.toString()); cell.clear()
                    rows.add(currentRow)
                    currentRow = mutableListOf()
                }
                else -> cell.append(ch)
            }
            i++
        }
        if (cell.isNotEmpty() || currentRow.isNotEmpty()) {
            currentRow.add(cell.toString())
            rows.add(currentRow)
        }
        return rows
    }

    fun toCsvText(rows: List<List<String>>): String {
        return rows.joinToString("\n") { row ->
            row.joinToString(",") { cell ->
                if (cell.contains(',') || cell.contains('"') || cell.contains('\n')) {
                    "\"${cell.replace("\"", "\"\"")}\""
                } else cell
            }
        }
    }
}
