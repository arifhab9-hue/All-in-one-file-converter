package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.text.StaticLayout
import android.text.TextPaint
import com.example.core.model.ConversionOptions
import com.example.core.model.ConversionOutputFile
import com.example.core.model.ConversionResult
import com.example.core.model.OutputImageFormat
import com.example.core.model.ToolId
import com.example.core.model.WorkspaceFile
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.StringReader
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class SlideData(
    val index: Int,
    val title: String,
    val bodyLines: List<String>,
    val images: List<ByteArray> = emptyList()
)

object OfficePowerPointEngine {

    fun parsePresentation(file: File): List<SlideData> {
        val ext = file.extension.lowercase()
        if (ext == "odp") return parseOdpSlides(file)
        if (ext == "ppt" || Ole2BinaryReader.isOle2(file)) {
            val rawSlides = Ole2BinaryReader.extractPptSlides(file)
            return rawSlides.mapIndexed { idx, lines ->
                SlideData(
                    index = idx + 1,
                    title = lines.firstOrNull() ?: "Slide ${idx + 1}",
                    bodyLines = lines.drop(1)
                )
            }
        }
        return parsePptxSlides(file)
    }

    private fun parsePptxSlides(file: File): List<SlideData> {
        val entries = OfficeWordEngine.readZipEntries(file)
        val slideKeys = entries.keys
            .filter { it.matches(Regex("ppt/slides/slide\\d+\\.xml")) }
            .sortedBy { it.filter { ch -> ch.isDigit() }.toIntOrNull() ?: 0 }

        if (slideKeys.isEmpty()) throw IllegalStateException("No slides found inside ${file.name}")

        return slideKeys.mapIndexed { idx, slidePath ->
            val xml = entries[slidePath]?.toString(Charsets.UTF_8) ?: ""
            val slideFileName = slidePath.substringAfterLast('/')
            val relsPath = "ppt/slides/_rels/$slideFileName.rels"
            val rels = OfficeWordEngine.parseRels(entries[relsPath]?.toString(Charsets.UTF_8))

            val paragraphs = mutableListOf<String>()
            val parser = XmlPullParserFactory.newInstance().newPullParser()
            parser.setInput(StringReader(xml))
            var ev = parser.eventType
            var inP = false
            val pBuf = StringBuilder()
            val images = mutableListOf<ByteArray>()

            while (ev != XmlPullParser.END_DOCUMENT) {
                val tag = parser.name?.substringAfter(':')
                when (ev) {
                    XmlPullParser.START_TAG -> when (tag) {
                        "p" -> { inP = true; pBuf.clear() }
                        "blip" -> {
                            val rId = parser.getAttributeValue(null, "r:embed")
                                ?: parser.getAttributeValue(null, "embed")
                            val target = rels[rId]
                            if (target != null) {
                                val normalized = target.replace("../", "ppt/")
                                val key = if (normalized.startsWith("ppt/")) normalized else "ppt/slides/$normalized"
                                entries[key]?.let { images.add(it) }
                            }
                        }
                    }
                    XmlPullParser.TEXT -> if (inP) pBuf.append(parser.text)
                    XmlPullParser.END_TAG -> if (tag == "p" && inP) {
                        val t = pBuf.toString().trim()
                        if (t.isNotEmpty()) paragraphs.add(t)
                        inP = false
                    }
                }
                ev = parser.next()
            }

            SlideData(
                index = idx + 1,
                title = paragraphs.firstOrNull() ?: "Slide ${idx + 1}",
                bodyLines = paragraphs.drop(1),
                images = images
            )
        }
    }

    private fun parseOdpSlides(file: File): List<SlideData> {
        val entries = OfficeWordEngine.readZipEntries(file)
        val xml = entries["content.xml"]?.toString(Charsets.UTF_8)
            ?: throw IllegalStateException("Invalid ODP file: content.xml missing")
        val slides = mutableListOf<SlideData>()
        val parser = XmlPullParserFactory.newInstance().newPullParser()
        parser.setInput(StringReader(xml))
        var ev = parser.eventType
        var inPage = false
        var inP = false
        val lines = mutableListOf<String>()
        val pBuf = StringBuilder()

        while (ev != XmlPullParser.END_DOCUMENT) {
            val tag = parser.name?.substringAfter(':')
            when (ev) {
                XmlPullParser.START_TAG -> when (tag) {
                    "page" -> { inPage = true; lines.clear() }
                    "p", "h" -> if (inPage) { inP = true; pBuf.clear() }
                }
                XmlPullParser.TEXT -> if (inP) pBuf.append(parser.text)
                XmlPullParser.END_TAG -> when (tag) {
                    "p", "h" -> if (inP) {
                        val t = pBuf.toString().trim()
                        if (t.isNotEmpty()) lines.add(t)
                        inP = false
                    }
                    "page" -> if (inPage) {
                        slides.add(
                            SlideData(
                                index = slides.size + 1,
                                title = lines.firstOrNull() ?: "Slide ${slides.size + 1}",
                                bodyLines = lines.drop(1)
                            )
                        )
                        inPage = false
                    }
                }
            }
            ev = parser.next()
        }
        return slides
    }

    fun presentationToPdf(
        context: Context,
        toolId: ToolId,
        wsFile: WorkspaceFile,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        onProgress(0.15f)
        val slides = parsePresentation(wsFile.localFile)
        val outFile = FileStorageHelper.createOutputFile(
            context,
            "${wsFile.name.substringBeforeLast('.')}.pdf"
        )
        val pageW = 960
        val pageH = 540
        val pdf = PdfDocument()
        try {
            slides.forEachIndexed { idx, slide ->
                onProgress(0.2f + (idx.toFloat() / slides.size.coerceAtLeast(1)) * 0.75f)
                val page = pdf.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, idx + 1).create())
                renderSlideToCanvas(slide, page.canvas, pageW, pageH)
                pdf.finishPage(page)
            }
            FileOutputStream(outFile).use { pdf.writeTo(it) }
        } finally {
            pdf.close()
        }
        onProgress(1f)
        return ConversionResult(
            toolId = toolId,
            outputFiles = listOf(ConversionOutputFile(outFile.name, outFile, "application/pdf", outFile.length())),
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outFile.length(),
            pageCount = slides.size
        )
    }

    fun slidesToImages(
        context: Context,
        toolId: ToolId,
        wsFile: WorkspaceFile,
        options: ConversionOptions,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        val isPng = toolId == ToolId.PPT_TO_PNG
        val fmt = if (isPng) OutputImageFormat.PNG else OutputImageFormat.JPG
        val compressFmt = if (isPng) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
        val slides = parsePresentation(wsFile.localFile)
        val base = wsFile.name.substringBeforeLast('.')
        val outputs = mutableListOf<ConversionOutputFile>()
        val w = 1600
        val h = 900

        slides.forEachIndexed { idx, slide ->
            onProgress((idx.toFloat() / slides.size.coerceAtLeast(1)) * 0.9f)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            renderSlideToCanvas(slide, canvas, w, h)
            val outFile = FileStorageHelper.createOutputFile(context, "${base}_slide_${idx + 1}.${fmt.ext}")
            FileOutputStream(outFile).use { fos ->
                bmp.compress(compressFmt, options.quality.coerceIn(20, 100), fos)
            }
            bmp.recycle()
            outputs.add(ConversionOutputFile(outFile.name, outFile, fmt.mimeType, outFile.length()))
        }

        val zipFile = if (outputs.size > 1) {
            val z = FileStorageHelper.createOutputFile(context, "${base}_slides.zip")
            FileStorageHelper.createZipArchive(outputs.map { it.file }, z)
        } else null
        onProgress(1f)
        return ConversionResult(
            toolId = toolId,
            outputFiles = outputs,
            zipFile = zipFile,
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outputs.sumOf { it.sizeBytes },
            pageCount = slides.size
        )
    }

    suspend fun pdfToPowerPoint(
        context: Context,
        toolId: ToolId,
        wsFile: WorkspaceFile,
        options: ConversionOptions,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        val pages = PdfStructuredExtractor.extractPages(context, wsFile.localFile, options.enableOcr) { p ->
            onProgress(p * 0.55f)
        }
        val base = wsFile.name.substringBeforeLast('.')
        val ext = if (toolId == ToolId.PDF_TO_PPT) "ppt" else "pptx"
        val outFile = FileStorageHelper.createOutputFile(context, "$base.$ext")

        // Render page thumbnails for crisp visual slides alongside editable text boxes
        val slideImages = mutableListOf<ByteArray>()
        val pfd = ParcelFileDescriptor.open(wsFile.localFile, ParcelFileDescriptor.MODE_READ_ONLY)
        val renderer = PdfRenderer(pfd)
        try {
            for (i in 0 until renderer.pageCount) {
                onProgress(0.55f + (i.toFloat() / renderer.pageCount.coerceAtLeast(1)) * 0.35f)
                renderer.openPage(i).use { page ->
                    val bmp = Bitmap.createBitmap(1280, (1280f * page.height / page.width).toInt().coerceIn(400, 1800), Bitmap.Config.ARGB_8888)
                    Canvas(bmp).drawColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    val baos = ByteArrayOutputStream()
                    bmp.compress(Bitmap.CompressFormat.JPEG, 82, baos)
                    bmp.recycle()
                    slideImages.add(baos.toByteArray())
                }
            }
        } finally {
            renderer.close()
            pfd.close()
        }

        writePptxPackage(pages, slideImages, outFile)
        onProgress(1f)
        return ConversionResult(
            toolId = toolId,
            outputFiles = listOf(
                ConversionOutputFile(
                    outFile.name,
                    outFile,
                    if (ext == "ppt") "application/vnd.ms-powerpoint" else "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    outFile.length()
                )
            ),
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outFile.length(),
            pageCount = pages.size,
            note = if (ext == "ppt") "Saved using PowerPoint OpenXML structure with .ppt extension for modern Office compatibility." else null
        )
    }

    fun compressPptx(
        context: Context,
        toolId: ToolId,
        wsFile: WorkspaceFile,
        options: ConversionOptions,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        val outFile = FileStorageHelper.createOutputFile(
            context,
            "${wsFile.name.substringBeforeLast('.')}_compressed.pptx"
        )
        OfficeWordEngine.compressOoxmlPackage(wsFile.localFile, outFile, "ppt/media/", options, onProgress)
        return ConversionResult(
            toolId = toolId,
            outputFiles = listOf(
                ConversionOutputFile(
                    outFile.name,
                    outFile,
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    outFile.length()
                )
            ),
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outFile.length(),
            pageCount = 1
        )
    }

    private fun renderSlideToCanvas(slide: SlideData, canvas: Canvas, w: Int, h: Int) {
        canvas.drawColor(Color.WHITE)
        val headerBarPaint = Paint().apply { color = Color.parseColor("#EA580C") }
        canvas.drawRect(0f, 0f, w.toFloat(), h * 0.018f, headerBarPaint)

        val margin = w * 0.06f
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F172A")
            textSize = h * 0.056f
            typeface = Typeface.DEFAULT_BOLD
        }
        val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#334155")
            textSize = h * 0.036f
        }
        val footerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#94A3B8")
            textSize = h * 0.025f
        }

        val hasImage = slide.images.isNotEmpty()
        val textColW = if (hasImage) (w * 0.52f).toInt() else (w - margin * 2).toInt()

        val titleLayout = StaticLayout.Builder.obtain(slide.title, 0, slide.title.length, titlePaint, (w - margin * 2).toInt())
            .build()
        canvas.save()
        canvas.translate(margin, h * 0.08f)
        titleLayout.draw(canvas)
        canvas.restore()

        var cursorY = h * 0.08f + titleLayout.height + h * 0.04f
        for (line in slide.bodyLines) {
            if (cursorY > h * 0.88f) break
            val bullet = "• $line"
            val layout = StaticLayout.Builder.obtain(bullet, 0, bullet.length, bodyPaint, textColW)
                .setLineSpacing(2f, 1.15f)
                .build()
            canvas.save()
            canvas.translate(margin, cursorY)
            layout.draw(canvas)
            canvas.restore()
            cursorY += layout.height + h * 0.02f
        }

        if (hasImage) {
            val imgBytes = slide.images.first()
            val bmp = BitmapFactory.decodeByteArray(imgBytes, 0, imgBytes.size)
            if (bmp != null) {
                val boxLeft = (w * 0.6f).toInt()
                val boxTop = (h * 0.22f).toInt()
                val boxW = (w * 0.34f).toInt()
                val boxH = (h * 0.64f).toInt()
                val scale = minOf(boxW.toFloat() / bmp.width, boxH.toFloat() / bmp.height)
                val dw = (bmp.width * scale).toInt()
                val dh = (bmp.height * scale).toInt()
                canvas.drawBitmap(bmp, null, Rect(boxLeft, boxTop, boxLeft + dw, boxTop + dh), null)
                bmp.recycle()
            }
        }

        canvas.drawText("Slide ${slide.index}", w - margin - 60f, h * 0.95f, footerPaint)
    }

    private fun writePptxPackage(
        pages: List<StructuredPdfPage>,
        slideImages: List<ByteArray>,
        outFile: File
    ) {
        val slideW = 12192000L // 16:9 EMU
        val slideH = 6858000L

        val contentTypes = buildString {
            append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/contenttypes">""")
            append("""<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>""")
            append("""<Default Extension="xml" ContentType="application/xml"/>""")
            append("""<Default Extension="jpg" ContentType="image/jpeg"/>""")
            append("""<Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>""")
            append("""<Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/>""")
            append("""<Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/>""")
            pages.indices.forEach { i ->
                append("""<Override PartName="/ppt/slides/slide${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>""")
            }
            append("</Types>")
        }

        val rootRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/></Relationships>"""

        val presXml = buildString {
            append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:presentation xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst><p:sldIdLst>""")
            pages.indices.forEach { i ->
                append("""<p:sldId id="${256 + i}" r:id="rId${i + 2}"/>""")
            }
            append("""</p:sldIdLst><p:sldSz cx="$slideW" cy="$slideH"/><p:notesSz cx="$slideH" cy="$slideW"/></p:presentation>""")
        }

        val presRels = buildString {
            append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
            append("""<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="slideMasters/slideMaster1.xml"/>""")
            pages.indices.forEach { i ->
                append("""<Relationship Id="rId${i + 2}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide${i + 1}.xml"/>""")
            }
            append("</Relationships>")
        }

        val slideMaster = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sldMaster xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/></p:spTree></p:cSld><p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst></p:sldMaster>"""
        val masterRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/></Relationships>"""
        val slideLayout = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sldLayout xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" type="blank"><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/></p:spTree></p:cSld></p:sldLayout>"""
        val layoutRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="../slideMasters/slideMaster1.xml"/></Relationships>"""

        ZipOutputStream(BufferedOutputStream(FileOutputStream(outFile))).use { zos ->
            fun put(name: String, content: ByteArray) {
                zos.putNextEntry(ZipEntry(name))
                zos.write(content)
                zos.closeEntry()
            }
            put("[Content_Types].xml", contentTypes.toByteArray(Charsets.UTF_8))
            put("_rels/.rels", rootRels.toByteArray(Charsets.UTF_8))
            put("ppt/presentation.xml", presXml.toByteArray(Charsets.UTF_8))
            put("ppt/_rels/presentation.xml.rels", presRels.toByteArray(Charsets.UTF_8))
            put("ppt/slideMasters/slideMaster1.xml", slideMaster.toByteArray(Charsets.UTF_8))
            put("ppt/slideMasters/_rels/slideMaster1.xml.rels", masterRels.toByteArray(Charsets.UTF_8))
            put("ppt/slideLayouts/slideLayout1.xml", slideLayout.toByteArray(Charsets.UTF_8))
            put("ppt/slideLayouts/_rels/slideLayout1.xml.rels", layoutRels.toByteArray(Charsets.UTF_8))

            pages.forEachIndexed { idx, page ->
                val imgBytes = slideImages.getOrNull(idx)
                if (imgBytes != null) {
                    put("ppt/media/slide_${idx + 1}.jpg", imgBytes)
                }
                val sRels = buildString {
                    append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
                    append("""<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>""")
                    if (imgBytes != null) {
                        append("""<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/slide_${idx + 1}.jpg"/>""")
                    }
                    append("</Relationships>")
                }
                put("ppt/slides/_rels/slide${idx + 1}.xml.rels", sRels.toByteArray(Charsets.UTF_8))

                val lines = page.rawText.lines().filter { it.isNotBlank() }.take(18)
                val parasXml = lines.joinToString("") { line ->
                    "<a:p><a:r><a:rPr lang=\"en-US\" sz=\"1400\"/><a:t>${OfficeWordEngine.xmlEscape(line)}</a:t></a:r></a:p>"
                }.ifEmpty { "<a:p><a:r><a:t>Page ${idx + 1}</a:t></a:r></a:p>" }

                val picXml = if (imgBytes != null) {
                    """<p:pic><p:nvPicPr><p:cNvPr id="3" name="SlideImage"/><p:cNvPicPr/><p:nvPr/></p:nvPicPr><p:blipFill><a:blip r:embed="rId2"/><a:stretch><a:fillRect/></a:stretch></p:blipFill><p:spPr><a:xfrm><a:off x="6800000" y="500000"/><a:ext cx="4800000" cy="5800000"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic>"""
                } else ""

                val slideXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">
  <p:cSld><p:spTree>
    <p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/>
    <p:sp><p:nvSpPr><p:cNvPr id="2" name="TextBox"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>
      <p:spPr><a:xfrm><a:off x="450000" y="450000"/><a:ext cx="6100000" cy="5900000"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr>
      <p:txBody><a:bodyPr wrap="square"/><a:lstStyle/>$parasXml</p:txBody>
    </p:sp>
    $picXml
  </p:spTree></p:cSld>
</p:sld>"""
                put("ppt/slides/slide${idx + 1}.xml", slideXml.toByteArray(Charsets.UTF_8))
            }
        }
    }
}
