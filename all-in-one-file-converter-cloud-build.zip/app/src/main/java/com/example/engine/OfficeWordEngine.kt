package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.example.core.model.ConversionOptions
import com.example.core.model.ConversionOutputFile
import com.example.core.model.ConversionResult
import com.example.core.model.ToolId
import com.example.core.model.WorkspaceFile
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.BufferedOutputStream
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.StringReader
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

sealed class WordElement {
    data class Paragraph(val text: String, val isHeading: Boolean = false, val level: Int = 0, val isBold: Boolean = false) : WordElement()
    data class Table(val rows: List<List<String>>) : WordElement()
    data class EmbeddedImage(val name: String, val bytes: ByteArray) : WordElement()
}

data class WordDocumentModel(
    val title: String,
    val elements: List<WordElement>
) {
    fun toPreviewText(): String = buildString {
        for (el in elements) {
            when (el) {
                is WordElement.Paragraph -> {
                    if (el.isHeading) appendLine("\n# ${el.text}") else appendLine(el.text)
                }
                is WordElement.Table -> {
                    appendLine("\n[Table: ${el.rows.size} rows]")
                    el.rows.forEach { row -> appendLine(" | " + row.joinToString(" | ") + " |") }
                    appendLine()
                }
                is WordElement.EmbeddedImage -> appendLine("[Image: ${el.name}]")
            }
        }
    }
}

object OfficeWordEngine {

    fun parseWordFile(file: File): WordDocumentModel {
        val ext = file.extension.lowercase()
        if (ext == "doc" || Ole2BinaryReader.isOle2(file)) {
            val paras = Ole2BinaryReader.extractDocParagraphs(file)
            return WordDocumentModel(
                title = file.nameWithoutExtension,
                elements = paras.mapIndexed { idx, p ->
                    WordElement.Paragraph(p, isHeading = idx == 0 && p.length < 80, level = if (idx == 0) 1 else 0)
                }
            )
        }

        val entries = readZipEntries(file)
        val docXml = entries["word/document.xml"]?.toString(Charsets.UTF_8)
            ?: throw IllegalStateException("Invalid DOCX archive: word/document.xml missing")
        val relsXml = entries["word/_rels/document.xml.rels"]?.toString(Charsets.UTF_8)
        val rIdToTarget = parseRels(relsXml)

        val elements = mutableListOf<WordElement>()
        val factory = XmlPullParserFactory.newInstance().apply { isNamespaceAware = false }
        val parser = factory.newPullParser()
        parser.setInput(StringReader(docXml))

        var inBody = false
        var inTable = false
        var inRow = false
        var inCell = false
        var inPara = false
        var isHeading = false
        var headingLevel = 0
        var isBoldRun = false
        val paraText = StringBuilder()
        var currentRows = mutableListOf<MutableList<String>>()
        var currentRow = mutableListOf<String>()
        var cellText = StringBuilder()

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            val tag = parser.name?.substringAfter(':')
            when (event) {
                XmlPullParser.START_TAG -> when (tag) {
                    "body" -> inBody = true
                    "tbl" -> if (inBody) {
                        inTable = true
                        currentRows = mutableListOf()
                    }
                    "tr" -> if (inTable) {
                        inRow = true
                        currentRow = mutableListOf()
                    }
                    "tc" -> if (inRow) {
                        inCell = true
                        cellText = StringBuilder()
                    }
                    "p" -> if (inBody) {
                        inPara = true
                        isHeading = false
                        headingLevel = 0
                        isBoldRun = false
                        paraText.clear()
                    }
                    "pStyle" -> if (inPara) {
                        val valAttr = parser.getAttributeValue(null, "w:val")
                            ?: parser.getAttributeValue(null, "val") ?: ""
                        if (valAttr.startsWith("Heading", ignoreCase = true) || valAttr.equals("Title", true)) {
                            isHeading = true
                            headingLevel = valAttr.filter { it.isDigit() }.toIntOrNull() ?: 1
                        }
                    }
                    "b" -> if (inPara) isBoldRun = true
                    "br" -> if (inPara) paraText.append('\n')
                    "tab" -> if (inPara) paraText.append("    ")
                    "blip" -> if (inBody && !inTable) {
                        val rId = parser.getAttributeValue(null, "r:embed")
                            ?: parser.getAttributeValue(null, "embed")
                        val target = rIdToTarget[rId]
                        if (target != null) {
                            val zipKey = if (target.startsWith("word/")) target else "word/$target"
                            entries[zipKey]?.let { imgBytes ->
                                elements.add(WordElement.EmbeddedImage(zipKey.substringAfterLast('/'), imgBytes))
                            }
                        }
                    }
                }
                XmlPullParser.TEXT -> {
                    if (inPara) paraText.append(parser.text)
                }
                XmlPullParser.END_TAG -> when (tag) {
                    "p" -> if (inPara) {
                        val txt = paraText.toString().trim()
                        if (inCell) {
                            if (txt.isNotEmpty()) {
                                if (cellText.isNotEmpty()) cellText.append(" ")
                                cellText.append(txt)
                            }
                        } else if (txt.isNotEmpty()) {
                            elements.add(WordElement.Paragraph(txt, isHeading, headingLevel, isBoldRun))
                        }
                        inPara = false
                    }
                    "tc" -> if (inCell) {
                        currentRow.add(cellText.toString().trim())
                        inCell = false
                    }
                    "tr" -> if (inRow) {
                        if (currentRow.isNotEmpty()) currentRows.add(currentRow)
                        inRow = false
                    }
                    "tbl" -> if (inTable) {
                        if (currentRows.isNotEmpty()) elements.add(WordElement.Table(currentRows))
                        inTable = false
                    }
                    "body" -> inBody = false
                }
            }
            event = parser.next()
        }

        return WordDocumentModel(file.nameWithoutExtension, elements)
    }

    fun wordToPdf(
        context: Context,
        toolId: ToolId,
        wsFile: WorkspaceFile,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        onProgress(0.15f)
        val model = parseWordFile(wsFile.localFile)
        if (model.elements.isEmpty()) {
            throw IllegalStateException("No readable content found in ${wsFile.name}")
        }
        onProgress(0.4f)
        val outFile = FileStorageHelper.createOutputFile(
            context,
            "${wsFile.name.substringBeforeLast('.')}.pdf"
        )
        val pageCount = renderWordModelToPdf(model, outFile) { p ->
            onProgress(0.4f + p * 0.58f)
        }
        onProgress(1f)
        return ConversionResult(
            toolId = toolId,
            outputFiles = listOf(ConversionOutputFile(outFile.name, outFile, "application/pdf", outFile.length())),
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outFile.length(),
            pageCount = pageCount
        )
    }

    fun previewWord(wsFile: WorkspaceFile): ConversionResult {
        val model = parseWordFile(wsFile.localFile)
        return ConversionResult(
            toolId = ToolId.WORD_PREVIEW,
            outputFiles = emptyList(),
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = wsFile.sizeBytes,
            pageCount = 1,
            previewText = model.toPreviewText().ifBlank { "(Empty Word document)" }
        )
    }

    suspend fun pdfToWord(
        context: Context,
        toolId: ToolId,
        wsFile: WorkspaceFile,
        options: ConversionOptions,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        val pages = PdfStructuredExtractor.extractPages(context, wsFile.localFile, options.enableOcr) { p ->
            onProgress(p * 0.8f)
        }
        val base = wsFile.name.substringBeforeLast('.')
        return if (toolId == ToolId.PDF_TO_DOC) {
            val outFile = FileStorageHelper.createOutputFile(context, "$base.doc")
            writeCompatibleDocRtf(pages, outFile)
            onProgress(1f)
            ConversionResult(
                toolId = toolId,
                outputFiles = listOf(ConversionOutputFile(outFile.name, outFile, "application/msword", outFile.length())),
                originalTotalBytes = wsFile.sizeBytes,
                outputTotalBytes = outFile.length(),
                pageCount = pages.size,
                note = "Generated as Word-compatible Rich Text (.doc) preserving headings, tables & OCR text. For legacy binary 97-2003 encoding, optionally configure a LibreOffice backend in Settings."
            )
        } else {
            val outFile = FileStorageHelper.createOutputFile(context, "$base.docx")
            writeDocxFromPages(pages, outFile)
            onProgress(1f)
            val ocrPages = pages.count { it.usedOcr }
            ConversionResult(
                toolId = toolId,
                outputFiles = listOf(
                    ConversionOutputFile(
                        outFile.name,
                        outFile,
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        outFile.length()
                    )
                ),
                originalTotalBytes = wsFile.sizeBytes,
                outputTotalBytes = outFile.length(),
                pageCount = pages.size,
                note = if (ocrPages > 0) "ML Kit OCR processed $ocrPages scanned page(s) automatically." else null
            )
        }
    }

    fun mergeDocx(
        context: Context,
        files: List<WorkspaceFile>,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        if (files.size < 2) throw IllegalArgumentException("Select at least 2 .docx files to merge")
        val combinedElements = mutableListOf<WordElement>()
        files.forEachIndexed { idx, ws ->
            onProgress((idx.toFloat() / files.size) * 0.7f)
            val model = parseWordFile(ws.localFile)
            combinedElements.addAll(model.elements)
        }
        val outFile = FileStorageHelper.createOutputFile(context, "merged_${files.size}_docs.docx")
        writeDocxFromWordElements(combinedElements, outFile)
        onProgress(1f)
        return ConversionResult(
            toolId = ToolId.WORD_MERGE,
            outputFiles = listOf(
                ConversionOutputFile(
                    outFile.name,
                    outFile,
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    outFile.length()
                )
            ),
            originalTotalBytes = files.sumOf { it.sizeBytes },
            outputTotalBytes = outFile.length(),
            pageCount = files.size
        )
    }

    fun compressDocx(
        context: Context,
        toolId: ToolId,
        wsFile: WorkspaceFile,
        options: ConversionOptions,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        val outFile = FileStorageHelper.createOutputFile(
            context,
            "${wsFile.name.substringBeforeLast('.')}_compressed.docx"
        )
        compressOoxmlPackage(wsFile.localFile, outFile, "word/media/", options, onProgress)
        return ConversionResult(
            toolId = toolId,
            outputFiles = listOf(
                ConversionOutputFile(
                    outFile.name,
                    outFile,
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    outFile.length()
                )
            ),
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outFile.length(),
            pageCount = 1
        )
    }

    fun compressOoxmlPackage(
        inputFile: File,
        outputFile: File,
        mediaPrefix: String,
        options: ConversionOptions,
        onProgress: (Float) -> Unit
    ) {
        val entries = readZipEntries(inputFile)
        val total = entries.size.coerceAtLeast(1)
        val quality = options.quality.coerceIn(20, 92)
        ZipOutputStream(BufferedOutputStream(FileOutputStream(outputFile))).apply {
            setLevel(Deflater.BEST_COMPRESSION)
        }.use { zos ->
            var idx = 0
            for ((name, rawBytes) in entries) {
                onProgress((idx++.toFloat() / total) * 0.95f)
                // Strip bloated thumbnail previews
                if (name.equals("docProps/thumbnail.jpeg", true) || name.equals("docProps/thumbnail.png", true)) {
                    continue
                }
                val finalBytes = if (name.startsWith(mediaPrefix) && (name.endsWith(".jpg", true) || name.endsWith(".jpeg", true) || name.endsWith(".png", true))) {
                    val bmp = BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size)
                    if (bmp != null) {
                        val baos = ByteArrayOutputStream()
                        val fmt = if (name.endsWith(".png", true)) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
                        val scaled = if (options.useTargetSize && maxOf(bmp.width, bmp.height) > 1200) {
                            val ratio = 1200f / maxOf(bmp.width, bmp.height)
                            Bitmap.createScaledBitmap(bmp, (bmp.width * ratio).toInt(), (bmp.height * ratio).toInt(), true)
                        } else bmp
                        scaled.compress(fmt, quality, baos)
                        if (scaled !== bmp) scaled.recycle()
                        bmp.recycle()
                        val compressed = baos.toByteArray()
                        if (compressed.size < rawBytes.size) compressed else rawBytes
                    } else rawBytes
                } else rawBytes

                zos.putNextEntry(ZipEntry(name))
                zos.write(finalBytes)
                zos.closeEntry()
            }
        }
        onProgress(1f)
    }

    private fun renderWordModelToPdf(
        model: WordDocumentModel,
        outFile: File,
        onProgress: (Float) -> Unit
    ): Int {
        val pageW = 595
        val pageH = 842
        val margin = 48f
        val contentW = (pageW - margin * 2).toInt()
        val pdf = PdfDocument()

        val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#1E293B")
            textSize = 11.5f
        }
        val headingPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F172A")
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
        }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#CBD5E1")
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
        }

        var pageNum = 1
        var page = pdf.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNum).create())
        var canvas = page.canvas
        canvas.drawColor(Color.WHITE)
        var cursorY = margin

        fun newPage() {
            pdf.finishPage(page)
            pageNum++
            page = pdf.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNum).create())
            canvas = page.canvas
            canvas.drawColor(Color.WHITE)
            cursorY = margin
        }

        val total = model.elements.size.coerceAtLeast(1)
        model.elements.forEachIndexed { idx, el ->
            onProgress(idx.toFloat() / total)
            when (el) {
                is WordElement.Paragraph -> {
                    val paint = if (el.isHeading) {
                        headingPaint.apply { textSize = if (el.level <= 1) 17f else 14f }
                    } else {
                        bodyPaint.apply {
                            typeface = if (el.isBold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                        }
                    }
                    val layout = StaticLayout.Builder.obtain(el.text, 0, el.text.length, paint, contentW)
                        .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                        .setLineSpacing(2f, 1.2f)
                        .build()
                    if (cursorY + layout.height > pageH - margin) newPage()
                    canvas.save()
                    canvas.translate(margin, cursorY)
                    layout.draw(canvas)
                    canvas.restore()
                    cursorY += layout.height + if (el.isHeading) 10f else 7f
                }

                is WordElement.Table -> {
                    val cols = el.rows.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1
                    val colW = contentW.toFloat() / cols
                    val cellPad = 5f
                    val cellPaint = TextPaint(bodyPaint).apply { textSize = 9.5f }
                    for ((rIdx, row) in el.rows.withIndex()) {
                        val cellLayouts = (0 until cols).map { c ->
                            val txt = row.getOrElse(c) { "" }
                            val p = if (rIdx == 0) TextPaint(cellPaint).apply { typeface = Typeface.DEFAULT_BOLD } else cellPaint
                            StaticLayout.Builder.obtain(txt, 0, txt.length, p, (colW - cellPad * 2).toInt().coerceAtLeast(20))
                                .build()
                        }
                        val rowH = (cellLayouts.maxOfOrNull { it.height } ?: 14) + cellPad * 2
                        if (cursorY + rowH > pageH - margin) newPage()
                        for (c in 0 until cols) {
                            val left = margin + c * colW
                            canvas.drawRect(left, cursorY, left + colW, cursorY + rowH, borderPaint)
                            canvas.save()
                            canvas.translate(left + cellPad, cursorY + cellPad)
                            cellLayouts[c].draw(canvas)
                            canvas.restore()
                        }
                        cursorY += rowH
                    }
                    cursorY += 10f
                }

                is WordElement.EmbeddedImage -> {
                    val bmp = BitmapFactory.decodeByteArray(el.bytes, 0, el.bytes.size)
                    if (bmp != null) {
                        val scale = minOf(contentW.toFloat() / bmp.width, 260f / bmp.height, 1f)
                        val drawW = (bmp.width * scale).toInt()
                        val drawH = (bmp.height * scale).toInt()
                        if (cursorY + drawH > pageH - margin) newPage()
                        canvas.drawBitmap(
                            bmp,
                            null,
                            Rect(margin.toInt(), cursorY.toInt(), margin.toInt() + drawW, cursorY.toInt() + drawH),
                            null
                        )
                        bmp.recycle()
                        cursorY += drawH + 10f
                    }
                }
            }
        }
        pdf.finishPage(page)
        FileOutputStream(outFile).use { pdf.writeTo(it) }
        pdf.close()
        return pageNum
    }

    private fun writeDocxFromPages(pages: List<StructuredPdfPage>, outFile: File) {
        val bodyXml = StringBuilder()
        pages.forEachIndexed { pageIdx, page ->
            for (block in page.blocks) {
                when (block) {
                    is ExtractedBlock.Heading -> {
                        val style = if (block.level <= 1) "Heading1" else "Heading2"
                        bodyXml.append("<w:p><w:pPr><w:pStyle w:val=\"$style\"/></w:pPr>")
                        bodyXml.append("<w:r><w:rPr><w:b/></w:rPr><w:t xml:space=\"preserve\">${xmlEscape(block.text)}</w:t></w:r></w:p>")
                    }
                    is ExtractedBlock.Paragraph -> {
                        bodyXml.append("<w:p><w:r>")
                        if (block.isBold || block.isItalic) {
                            bodyXml.append("<w:rPr>")
                            if (block.isBold) bodyXml.append("<w:b/>")
                            if (block.isItalic) bodyXml.append("<w:i/>")
                            bodyXml.append("</w:rPr>")
                        }
                        bodyXml.append("<w:t xml:space=\"preserve\">${xmlEscape(block.text)}</w:t></w:r></w:p>")
                    }
                    is ExtractedBlock.Table -> {
                        appendWordTableXml(bodyXml, block.rows)
                    }
                }
            }
            if (pageIdx < pages.lastIndex) {
                bodyXml.append("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>")
            }
        }
        packageDocx(bodyXml.toString(), emptyList(), outFile)
    }

    private fun writeDocxFromWordElements(elements: List<WordElement>, outFile: File) {
        val bodyXml = StringBuilder()
        val media = mutableListOf<Pair<String, ByteArray>>()
        var imgCounter = 1
        for (el in elements) {
            when (el) {
                is WordElement.Paragraph -> {
                    bodyXml.append("<w:p>")
                    if (el.isHeading) {
                        val style = if (el.level <= 1) "Heading1" else "Heading2"
                        bodyXml.append("<w:pPr><w:pStyle w:val=\"$style\"/></w:pPr>")
                    }
                    bodyXml.append("<w:r>")
                    if (el.isBold || el.isHeading) bodyXml.append("<w:rPr><w:b/></w:rPr>")
                    bodyXml.append("<w:t xml:space=\"preserve\">${xmlEscape(el.text)}</w:t></w:r></w:p>")
                }
                is WordElement.Table -> appendWordTableXml(bodyXml, el.rows)
                is WordElement.EmbeddedImage -> {
                    // Keep text placeholder or embed in future if needed
                    media.add("image${imgCounter++}.png" to el.bytes)
                    bodyXml.append("<w:p><w:r><w:t>[Embedded Image: ${xmlEscape(el.name)}]</w:t></w:r></w:p>")
                }
            }
        }
        packageDocx(bodyXml.toString(), media, outFile)
    }

    private fun appendWordTableXml(sb: StringBuilder, rows: List<List<String>>) {
        sb.append("<w:tbl><w:tblPr><w:tblBorders>")
        listOf("top", "left", "bottom", "right", "insideH", "insideV").forEach { side ->
            sb.append("<w:$side w:val=\"single\" w:sz=\"4\" w:space=\"0\" w:color=\"CBD5E1\"/>")
        }
        sb.append("</w:tblBorders></w:tblPr>")
        for (row in rows) {
            sb.append("<w:tr>")
            for (cell in row) {
                sb.append("<w:tc><w:p><w:r><w:t xml:space=\"preserve\">${xmlEscape(cell)}</w:t></w:r></w:p></w:tc>")
            }
            sb.append("</w:tr>")
        }
        sb.append("</w:tbl>")
    }

    private fun packageDocx(bodyInnerXml: String, media: List<Pair<String, ByteArray>>, outFile: File) {
        val contentTypes = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/contenttypes">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Default Extension="png" ContentType="image/png"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>"""

        val rootRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""

        val docRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""

        val stylesXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:rPr><w:sz w:val="22"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:rPr><w:b/><w:sz w:val="34"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:rPr><w:b/><w:sz w:val="28"/></w:rPr></w:style>
</w:styles>"""

        val documentXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    $bodyInnerXml
    <w:sectPr><w:pgSz w:w="11906" w:h="16838"/></w:sectPr>
  </w:body>
</w:document>"""

        ZipOutputStream(BufferedOutputStream(FileOutputStream(outFile))).use { zos ->
            fun put(name: String, content: String) {
                zos.putNextEntry(ZipEntry(name))
                zos.write(content.toByteArray(Charsets.UTF_8))
                zos.closeEntry()
            }
            put("[Content_Types].xml", contentTypes)
            put("_rels/.rels", rootRels)
            put("word/_rels/document.xml.rels", docRels)
            put("word/styles.xml", stylesXml)
            put("word/document.xml", documentXml)
            for ((mName, mBytes) in media) {
                zos.putNextEntry(ZipEntry("word/media/$mName"))
                zos.write(mBytes)
                zos.closeEntry()
            }
        }
    }

    private fun writeCompatibleDocRtf(pages: List<StructuredPdfPage>, outFile: File) {
        val sb = StringBuilder("{\\rtf1\\ansi\\deff0{\\fonttbl{\\f0 Arial;}}\\fs22\n")
        pages.forEachIndexed { idx, page ->
            for (block in page.blocks) {
                when (block) {
                    is ExtractedBlock.Heading -> {
                        sb.append("\\b\\fs30 ").append(rtfEscape(block.text)).append("\\b0\\fs22\\par\n")
                    }
                    is ExtractedBlock.Paragraph -> {
                        if (block.isBold) sb.append("\\b ")
                        sb.append(rtfEscape(block.text))
                        if (block.isBold) sb.append("\\b0 ")
                        sb.append("\\par\n")
                    }
                    is ExtractedBlock.Table -> {
                        for (row in block.rows) {
                            sb.append(row.joinToString("\\tab ") { rtfEscape(it) }).append("\\par\n")
                        }
                    }
                }
            }
            if (idx < pages.lastIndex) sb.append("\\page\n")
        }
        sb.append("}")
        outFile.writeText(sb.toString(), Charsets.UTF_8)
    }

    private fun rtfEscape(s: String): String {
        val out = StringBuilder()
        for (ch in s) {
            when {
                ch == '\\' || ch == '{' || ch == '}' -> out.append('\\').append(ch)
                ch.code > 127 -> out.append("\\u").append(ch.code).append('?')
                else -> out.append(ch)
            }
        }
        return out.toString()
    }

    fun readZipEntries(file: File): LinkedHashMap<String, ByteArray> {
        val map = linkedMapOf<String, ByteArray>()
        ZipInputStream(FileInputStream(file)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                if (!entry.isDirectory) {
                    map[entry.name] = zis.readBytes()
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        return map
    }

    fun parseRels(relsXml: String?): Map<String, String> {
        if (relsXml.isNullOrBlank()) return emptyMap()
        val map = mutableMapOf<String, String>()
        val parser = XmlPullParserFactory.newInstance().newPullParser()
        parser.setInput(StringReader(relsXml))
        var ev = parser.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG && parser.name?.endsWith("Relationship") == true) {
                val id = parser.getAttributeValue(null, "Id")
                val target = parser.getAttributeValue(null, "Target")
                if (!id.isNullOrBlank() && !target.isNullOrBlank()) map[id] = target
            }
            ev = parser.next()
        }
        return map
    }

    fun xmlEscape(s: String): String = s
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")
}
