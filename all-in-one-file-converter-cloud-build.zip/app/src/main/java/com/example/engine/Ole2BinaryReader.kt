package com.example.engine

import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.Charset
import kotlin.math.pow

/**
 * Pure-Kotlin OLE2 / Compound File Binary Format (CFBF) reader and BIFF8/DOC/PPT stream extractors
 * so legacy .doc, .xls, and .ppt files can be parsed locally on Android without java.awt dependencies.
 */
object Ole2BinaryReader {

    private val MAGIC = byteArrayOf(
        0xD0.toByte(), 0xCF.toByte(), 0x11.toByte(), 0xE0.toByte(),
        0xA1.toByte(), 0xB1.toByte(), 0x1A.toByte(), 0xE1.toByte()
    )

    private const val END_OF_CHAIN = -2
    private const val FREE_SECT = -1

    fun isOle2(file: File): Boolean {
        if (!file.exists() || file.length() < 512) return false
        val header = ByteArray(8)
        file.inputStream().use { it.read(header) }
        return header.contentEquals(MAGIC)
    }

    fun readStreams(file: File): Map<String, ByteArray> {
        val data = file.readBytes()
        if (data.size < 512) return emptyMap()
        val buf = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until 8) {
            if (data[i] != MAGIC[i]) return emptyMap()
        }

        val sectorShift = buf.getShort(30).toInt() and 0xFFFF
        val sectorSize = 1 shl sectorShift
        val miniSectorShift = buf.getShort(32).toInt() and 0xFFFF
        val miniSectorSize = 1 shl miniSectorShift
        val firstDirSect = buf.getInt(48)
        val miniCutoff = buf.getInt(56)
        val firstMiniFatSect = buf.getInt(60)
        val firstDifatSect = buf.getInt(68)
        val numDifatSects = buf.getInt(72)

        // Build DIFAT -> FAT sector list
        val fatSectorIds = mutableListOf<Int>()
        for (i in 0 until 109) {
            val sid = buf.getInt(76 + i * 4)
            if (sid >= 0) fatSectorIds.add(sid)
        }
        var difatSid = firstDifatSect
        var difatGuard = 0
        while (difatSid >= 0 && difatGuard++ < numDifatSects + 2) {
            val off = (difatSid + 1) * sectorSize
            if (off + sectorSize > data.size) break
            val entries = sectorSize / 4 - 1
            for (i in 0 until entries) {
                val sid = buf.getInt(off + i * 4)
                if (sid >= 0) fatSectorIds.add(sid)
            }
            difatSid = buf.getInt(off + entries * 4)
        }

        // Read FAT table
        val fat = mutableListOf<Int>()
        for (sid in fatSectorIds) {
            val off = (sid + 1) * sectorSize
            if (off + sectorSize > data.size) continue
            for (i in 0 until sectorSize / 4) {
                fat.add(buf.getInt(off + i * 4))
            }
        }

        fun readChain(startSid: Int, expectedSize: Int = -1): ByteArray {
            val out = ByteArrayOutputStream()
            var cur = startSid
            var guard = 0
            while (cur >= 0 && cur < fat.size && guard++ < 50000) {
                val off = (cur + 1) * sectorSize
                if (off < 0 || off + sectorSize > data.size) break
                out.write(data, off, sectorSize)
                cur = fat[cur]
                if (cur == END_OF_CHAIN || cur == FREE_SECT) break
            }
            val arr = out.toByteArray()
            return if (expectedSize in 0..arr.size) arr.copyOf(expectedSize) else arr
        }

        val dirBytes = readChain(firstDirSect)
        val dirBuf = ByteBuffer.wrap(dirBytes).order(ByteOrder.LITTLE_ENDIAN)
        val dirCount = dirBytes.size / 128

        var rootMiniStream = ByteArray(0)
        val miniFat = mutableListOf<Int>()
        if (firstMiniFatSect >= 0) {
            val mfBytes = readChain(firstMiniFatSect)
            val mfBuf = ByteBuffer.wrap(mfBytes).order(ByteOrder.LITTLE_ENDIAN)
            for (i in 0 until mfBytes.size / 4) miniFat.add(mfBuf.getInt(i * 4))
        }

        // First locate Root Entry for mini-stream
        if (dirCount > 0) {
            val rootStart = dirBuf.getInt(116)
            val rootSize = dirBuf.getInt(120)
            if (rootStart >= 0 && rootSize > 0) {
                rootMiniStream = readChain(rootStart, rootSize)
            }
        }

        fun readMiniChain(startSid: Int, expectedSize: Int): ByteArray {
            val out = ByteArrayOutputStream()
            var cur = startSid
            var guard = 0
            while (cur >= 0 && cur < miniFat.size && guard++ < 50000) {
                val off = cur * miniSectorSize
                if (off + miniSectorSize > rootMiniStream.size) break
                out.write(rootMiniStream, off, miniSectorSize)
                cur = miniFat[cur]
                if (cur == END_OF_CHAIN || cur == FREE_SECT) break
            }
            val arr = out.toByteArray()
            return if (expectedSize in 0..arr.size) arr.copyOf(expectedSize) else arr
        }

        val streams = linkedMapOf<String, ByteArray>()
        for (i in 0 until dirCount) {
            val base = i * 128
            val nameLen = dirBuf.getShort(base + 64).toInt() and 0xFFFF
            val objType = dirBuf.get(base + 66).toInt() and 0xFF
            if (objType == 2 && nameLen in 2..64) {
                val nameBytes = dirBytes.copyOfRange(base, base + nameLen - 2)
                val name = String(nameBytes, Charsets.UTF_16LE)
                val startSect = dirBuf.getInt(base + 116)
                val sizeLow = dirBuf.getInt(base + 120)
                if (startSect >= 0 && sizeLow > 0) {
                    val content = if (sizeLow < miniCutoff && rootMiniStream.isNotEmpty()) {
                        readMiniChain(startSect, sizeLow)
                    } else {
                        readChain(startSect, sizeLow)
                    }
                    streams[name] = content
                }
            }
        }
        return streams
    }

    fun extractDocParagraphs(file: File): List<String> {
        val streams = readStreams(file)
        val wordDoc = streams["WordDocument"]
        if (wordDoc == null) {
            // Fallback: some .doc files are actually RTF or HTML saved with .doc extension
            val raw = file.readText(Charsets.UTF_8)
            if (raw.startsWith("{\\rtf")) return TextFormatEngine.parseRtfParagraphs(raw)
            if (raw.contains("<html", ignoreCase = true) || raw.contains("<body", ignoreCase = true)) {
                return org.jsoup.Jsoup.parse(raw).select("p,h1,h2,h3,li,tr").map { it.text().trim() }.filter { it.isNotEmpty() }
            }
            throw IllegalStateException("Unsupported or encrypted .doc binary structure.")
        }

        val buf = ByteBuffer.wrap(wordDoc).order(ByteOrder.LITTLE_ENDIAN)
        if (wordDoc.size < 64) return emptyList()
        val flags = buf.getShort(10).toInt() and 0xFFFF
        val useTable1 = (flags and 0x0200) != 0
        val tableStream = streams[if (useTable1) "1Table" else "0Table"]

        // Try Piece Table (CLX) extraction from Table stream
        if (tableStream != null && wordDoc.size > 0x1A6) {
            val fcClx = buf.getInt(0x1A2)
            val lcbClx = buf.getInt(0x1A6)
            if (fcClx >= 0 && lcbClx > 4 && fcClx + lcbClx <= tableStream.size) {
                val extracted = parseClxPieces(wordDoc, tableStream, fcClx, lcbClx)
                if (extracted.isNotBlank()) {
                    return extracted.split('\r', '\n').map { it.trim() }.filter { it.isNotEmpty() }
                }
            }
        }

        // Fallback: scan WordDocument text body (ccpText length from FIB)
        val ccpText = if (wordDoc.size > 0x50) buf.getInt(0x4C) else 0
        val fcMin = if (wordDoc.size > 0x1C) buf.getInt(0x18) else 0x800
        if (ccpText > 0 && fcMin in 512 until wordDoc.size) {
            val end = (fcMin + ccpText).coerceAtMost(wordDoc.size)
            val slice = wordDoc.copyOfRange(fcMin, end)
            val decoded = String(slice, Charset.forName("windows-1252"))
                .replace('\u0007', '\t')
                .replace(Regex("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]"), "")
            val lines = decoded.split('\r', '\n').map { it.trim() }.filter { it.length >= 2 }
            if (lines.isNotEmpty()) return lines
        }
        return emptyList()
    }

    private fun parseClxPieces(wordDoc: ByteArray, tableStream: ByteArray, fcClx: Int, lcbClx: Int): String {
        val endClx = (fcClx + lcbClx).coerceAtMost(tableStream.size)
        var pos = fcClx
        val tBuf = ByteBuffer.wrap(tableStream).order(ByteOrder.LITTLE_ENDIAN)
        while (pos < endClx) {
            val type = tableStream[pos].toInt() and 0xFF
            if (type == 1) {
                if (pos + 3 > endClx) break
                val cb = tBuf.getShort(pos + 1).toInt() and 0xFFFF
                pos += 3 + cb
            } else if (type == 2) {
                if (pos + 5 > endClx) break
                val lcb = tBuf.getInt(pos + 1)
                pos += 5
                val nPieces = (lcb - 4) / 12
                if (nPieces <= 0 || pos + lcb > endClx) break
                val cpStart = pos
                val pcdStart = pos + (nPieces + 1) * 4
                val sb = StringBuilder()
                for (i in 0 until nPieces) {
                    val cp0 = tBuf.getInt(cpStart + i * 4)
                    val cp1 = tBuf.getInt(cpStart + (i + 1) * 4)
                    val charCount = cp1 - cp0
                    if (charCount <= 0) continue
                    val fcRaw = tBuf.getInt(pcdStart + i * 8 + 2)
                    val isCompressed = (fcRaw and 0x40000000) != 0
                    val fc = fcRaw and 0x3FFFFFFF
                    if (isCompressed) {
                        val byteOffset = fc / 2
                        val len = charCount.coerceAtMost(wordDoc.size - byteOffset)
                        if (byteOffset >= 0 && len > 0) {
                            sb.append(String(wordDoc, byteOffset, len, Charset.forName("windows-1252")))
                        }
                    } else {
                        val byteLen = (charCount * 2).coerceAtMost(wordDoc.size - fc)
                        if (fc >= 0 && byteLen > 0) {
                            sb.append(String(wordDoc, fc, byteLen, Charsets.UTF_16LE))
                        }
                    }
                }
                return sb.toString()
                    .replace('\u0007', '\t')
                    .replace(Regex("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]"), "")
            } else {
                break
            }
        }
        return ""
    }

    data class BiffSheet(val name: String, val rows: List<List<String>>)

    fun extractXlsSheets(file: File): List<BiffSheet> {
        val streams = readStreams(file)
        val wb = streams["Workbook"] ?: streams["Book"]
        if (wb == null) {
            // Check if SpreadsheetML 2003 XML or HTML table saved as .xls
            val text = file.readText(Charsets.UTF_8)
            if (text.contains("<Workbook", ignoreCase = true) || text.contains("<Worksheet", ignoreCase = true)) {
                return OfficeExcelEngine.parseSpreadsheetMl(text)
            }
            if (text.contains("<table", ignoreCase = true)) {
                val doc = org.jsoup.Jsoup.parse(text)
                val rows = doc.select("tr").map { tr -> tr.select("th,td").map { it.text().trim() } }.filter { it.isNotEmpty() }
                return listOf(BiffSheet("Sheet1", rows))
            }
            throw IllegalStateException("Unsupported or encrypted .xls binary file.")
        }

        val buf = ByteBuffer.wrap(wb).order(ByteOrder.LITTLE_ENDIAN)
        val sheetInfos = mutableListOf<Pair<Int, String>>() // offset -> name
        val sst = mutableListOf<String>()

        // Pass 1: parse BOUNDSHEET and SST (with CONTINUE record stitching)
        var pos = 0
        while (pos + 4 <= wb.size) {
            val recId = buf.getShort(pos).toInt() and 0xFFFF
            val recLen = buf.getShort(pos + 2).toInt() and 0xFFFF
            val dataStart = pos + 4
            if (dataStart + recLen > wb.size) break

            if (recId == 0x0085 && recLen >= 8) { // BOUNDSHEET
                val offset = buf.getInt(dataStart)
                val nameLen = wb[dataStart + 6].toInt() and 0xFF
                val flags = wb[dataStart + 7].toInt() and 0xFF
                val isUnicode = (flags and 0x01) != 0
                val name = if (isUnicode && dataStart + 8 + nameLen * 2 <= wb.size) {
                    String(wb, dataStart + 8, nameLen * 2, Charsets.UTF_16LE)
                } else if (dataStart + 8 + nameLen <= wb.size) {
                    String(wb, dataStart + 8, nameLen, Charset.forName("windows-1252"))
                } else {
                    "Sheet${sheetInfos.size + 1}"
                }
                sheetInfos.add(offset to name)
            } else if (recId == 0x00FC && recLen >= 8) { // SST
                parseSstWithContinue(wb, pos, sst)
            }
            pos = dataStart + recLen
        }

        if (sheetInfos.isEmpty()) sheetInfos.add(0 to "Sheet1")

        // Pass 2: parse cells per sheet
        val resultSheets = mutableListOf<BiffSheet>()
        for (sIdx in sheetInfos.indices) {
            val startOff = sheetInfos[sIdx].first
            val sheetName = sheetInfos[sIdx].second
            val cellMap = sortedMapOf<Int, java.util.TreeMap<Int, String>>() // row -> (col -> val)

            var p = startOff
            var started = false
            while (p + 4 <= wb.size) {
                val recId = buf.getShort(p).toInt() and 0xFFFF
                val recLen = buf.getShort(p + 2).toInt() and 0xFFFF
                val ds = p + 4
                if (ds + recLen > wb.size) break

                if (recId == 0x0809) { // BOF
                    if (started) break
                    started = true
                } else if (recId == 0x000A && started) { // EOF
                    break
                } else if (started) {
                    when (recId) {
                        0x00FD -> if (recLen >= 10) { // LABELSST
                            val r = buf.getShort(ds).toInt() and 0xFFFF
                            val c = buf.getShort(ds + 2).toInt() and 0xFFFF
                            val sstIdx = buf.getInt(ds + 6)
                            val value = sst.getOrElse(sstIdx) { "" }
                            cellMap.getOrPut(r) { java.util.TreeMap<Int, String>() }[c] = value
                        }
                        0x0204 -> if (recLen >= 8) { // LABEL
                            val r = buf.getShort(ds).toInt() and 0xFFFF
                            val c = buf.getShort(ds + 2).toInt() and 0xFFFF
                            val len = buf.getShort(ds + 6).toInt() and 0xFFFF
                            val txt = if (ds + 8 + len <= wb.size) String(wb, ds + 8, len, Charsets.UTF_8) else ""
                            cellMap.getOrPut(r) { java.util.TreeMap<Int, String>() }[c] = txt
                        }
                        0x0203 -> if (recLen >= 14) { // NUMBER
                            val r = buf.getShort(ds).toInt() and 0xFFFF
                            val c = buf.getShort(ds + 2).toInt() and 0xFFFF
                            val num = buf.getDouble(ds + 6)
                            cellMap.getOrPut(r) { java.util.TreeMap<Int, String>() }[c] = formatBiffNumber(num)
                        }
                        0x027E -> if (recLen >= 10) { // RK
                            val r = buf.getShort(ds).toInt() and 0xFFFF
                            val c = buf.getShort(ds + 2).toInt() and 0xFFFF
                            val rk = buf.getInt(ds + 6)
                            cellMap.getOrPut(r) { java.util.TreeMap<Int, String>() }[c] = formatBiffNumber(decodeRk(rk))
                        }
                        0x00BD -> if (recLen >= 6) { // MULRK
                            val r = buf.getShort(ds).toInt() and 0xFFFF
                            val firstCol = buf.getShort(ds + 2).toInt() and 0xFFFF
                            val numRks = (recLen - 6) / 6
                            for (k in 0 until numRks) {
                                val rk = buf.getInt(ds + 4 + k * 6 + 2)
                                cellMap.getOrPut(r) { java.util.TreeMap<Int, String>() }[firstCol + k] = formatBiffNumber(decodeRk(rk))
                            }
                        }
                        0x0006 -> if (recLen >= 20) { // FORMULA cached numeric
                            val r = buf.getShort(ds).toInt() and 0xFFFF
                            val c = buf.getShort(ds + 2).toInt() and 0xFFFF
                            val num = buf.getDouble(ds + 6)
                            if (!num.isNaN()) {
                                cellMap.getOrPut(r) { java.util.TreeMap<Int, String>() }[c] = formatBiffNumber(num)
                            }
                        }
                    }
                }
                p = ds + recLen
            }

            if (cellMap.isNotEmpty()) {
                val maxRow = cellMap.keys.max()
                val maxCol = cellMap.values.maxOf { it.keys.maxOrNull() ?: 0 }
                val rows = (0..maxRow).map { r ->
                    val rowMap = cellMap[r] ?: emptyMap()
                    (0..maxCol).map { c -> rowMap[c] ?: "" }
                }
                resultSheets.add(BiffSheet(sheetName, rows))
            } else {
                resultSheets.add(BiffSheet(sheetName, emptyList()))
            }
        }
        return resultSheets
    }

    private fun parseSstWithContinue(wb: ByteArray, sstStartPos: Int, outSst: MutableList<String>) {
        val buf = ByteBuffer.wrap(wb).order(ByteOrder.LITTLE_ENDIAN)
        val firstLen = buf.getShort(sstStartPos + 2).toInt() and 0xFFFF
        val totalStrings = buf.getInt(sstStartPos + 8)
        val chunks = mutableListOf<ByteArray>()
        chunks.add(wb.copyOfRange(sstStartPos + 12, (sstStartPos + 4 + firstLen).coerceAtMost(wb.size)))
        var nextPos = sstStartPos + 4 + firstLen
        while (nextPos + 4 <= wb.size) {
            val id = buf.getShort(nextPos).toInt() and 0xFFFF
            val len = buf.getShort(nextPos + 2).toInt() and 0xFFFF
            if (id != 0x003C) break // CONTINUE
            chunks.add(wb.copyOfRange(nextPos + 4, (nextPos + 4 + len).coerceAtMost(wb.size)))
            nextPos += 4 + len
        }
        // Parse from primary chunk cleanly (best-effort across CONTINUE boundaries)
        val data = chunks.first()
        val dBuf = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        var p = 0
        while (outSst.size < totalStrings && p + 3 <= data.size) {
            val charLen = dBuf.getShort(p).toInt() and 0xFFFF
            val flags = data[p + 2].toInt() and 0xFF
            p += 3
            val isUnicode = (flags and 0x01) != 0
            val hasExt = (flags and 0x04) != 0
            val hasRich = (flags and 0x08) != 0
            val rtRuns = if (hasRich && p + 2 <= data.size) {
                val v = dBuf.getShort(p).toInt() and 0xFFFF; p += 2; v
            } else 0
            val extBytes = if (hasExt && p + 4 <= data.size) {
                val v = dBuf.getInt(p); p += 4; v
            } else 0
            val strBytes = if (isUnicode) charLen * 2 else charLen
            if (p + strBytes > data.size) break
            val str = if (isUnicode) {
                String(data, p, strBytes, Charsets.UTF_16LE)
            } else {
                String(data, p, strBytes, Charset.forName("windows-1252"))
            }
            outSst.add(str)
            p += strBytes + rtRuns * 4 + extBytes
        }
    }

    private fun decodeRk(rk: Int): Double {
        val isInt = (rk and 0x02) != 0
        val div100 = (rk and 0x01) != 0
        var v = if (isInt) {
            (rk shr 2).toDouble()
        } else {
            val bits = (rk.toLong() and 0xFFFFFFFCL) shl 32
            java.lang.Double.longBitsToDouble(bits)
        }
        if (div100) v /= 100.0
        return v
    }

    private fun formatBiffNumber(v: Double): String {
        return if (v % 1.0 == 0.0 && kotlin.math.abs(v) < 1e12) {
            v.toLong().toString()
        } else {
            String.format("%.2f", v).trimEnd('0').trimEnd('.')
        }
    }

    fun extractPptSlides(file: File): List<List<String>> {
        val streams = readStreams(file)
        val pptData = streams["PowerPoint Document"]
            ?: throw IllegalStateException("Unsupported or encrypted .ppt binary file.")
        val buf = ByteBuffer.wrap(pptData).order(ByteOrder.LITTLE_ENDIAN)
        val slides = mutableListOf<MutableList<String>>()
        var currentSlide = mutableListOf<String>()

        var pos = 0
        while (pos + 8 <= pptData.size) {
            val verInst = buf.getShort(pos).toInt() and 0xFFFF
            val ver = verInst and 0x0F
            val recType = buf.getShort(pos + 2).toInt() and 0xFFFF
            val recLen = buf.getInt(pos + 4)
            if (recLen < 0 || pos + 8 + recLen > pptData.size) break

            if (recType == 0x03EE && ver == 0x0F) { // Slide container
                if (currentSlide.isNotEmpty()) {
                    slides.add(currentSlide)
                    currentSlide = mutableListOf()
                }
            } else if (recType == 0x0FA0 && recLen > 0) { // TextCharsAtom (UTF-16LE)
                val text = String(pptData, pos + 8, recLen, Charsets.UTF_16LE)
                    .replace('\r', '\n')
                    .trim()
                if (text.isNotEmpty()) currentSlide.addAll(text.lines().filter { it.isNotBlank() })
            } else if (recType == 0x0FA8 && recLen > 0) { // TextBytesAtom (CP1252)
                val text = String(pptData, pos + 8, recLen, Charset.forName("windows-1252"))
                    .replace('\r', '\n')
                    .trim()
                if (text.isNotEmpty()) currentSlide.addAll(text.lines().filter { it.isNotBlank() })
            }

            // Recurse into containers (ver == 0xF) or advance past atoms
            pos += if (ver == 0x0F) 8 else (8 + recLen)
        }
        if (currentSlide.isNotEmpty()) slides.add(currentSlide)
        return slides
    }
}
