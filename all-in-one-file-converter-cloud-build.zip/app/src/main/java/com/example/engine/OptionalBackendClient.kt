package com.example.engine

import android.content.Context
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

/**
 * Optional self-hosted server backend integration (compatible with Gotenberg LibreOffice endpoint
 * or any user-deployed REST endpoint accepting multipart "files" and returning the converted file).
 * Never required — all conversions work locally on-device by default with zero paid APIs.
 */
object OptionalBackendClient {

    private val client by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    fun testHealth(baseUrl: String): Result<String> {
        val clean = baseUrl.trim().trimEnd('/')
        if (clean.isBlank()) return Result.failure(IllegalArgumentException("Server URL is empty"))
        return try {
            val req = Request.Builder().url(clean).get().build()
            client.newCall(req).execute().use { resp ->
                if (resp.isSuccessful || resp.code in 200..405) {
                    Result.success("Connected (HTTP ${resp.code})")
                } else {
                    Result.failure(IllegalStateException("Server responded HTTP ${resp.code}"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun convertViaServer(
        context: Context,
        endpointUrl: String,
        inputFile: File,
        outputFileName: String
    ): File {
        val clean = endpointUrl.trim().trimEnd('/')
        val body = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart(
                "files",
                inputFile.name,
                inputFile.asRequestBody(FileStorageHelper.guessMimeFromName(inputFile.name).toMediaTypeOrNull())
            )
            .build()

        val request = Request.Builder()
            .url(clean)
            .post(body)
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException("Server conversion failed (HTTP ${response.code}): ${response.message}")
            }
            val outFile = FileStorageHelper.createOutputFile(context, outputFileName)
            response.body?.byteStream()?.use { input ->
                FileOutputStream(outFile).use { output -> input.copyTo(output) }
            } ?: throw IllegalStateException("Empty response from server")
            return outFile
        }
    }
}
