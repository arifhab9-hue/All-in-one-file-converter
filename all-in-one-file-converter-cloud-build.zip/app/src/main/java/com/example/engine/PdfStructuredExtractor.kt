package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import java.io.File
import kotlin.math.abs

data class TextSpanBox(
    val text: String,
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val fontSize: Float,
    val isBold: Boolean,
    val isItalic: Boolean
)

sealed class ExtractedBlock {
    data class Heading(val text: String, val level: Int) : ExtractedBlock()
    data class Paragraph(val text: String, val isBold: Boolean = false, val isItalic: Boolean = false) : ExtractedBlock()
    data class Table(val rows: List<List<String>>) : ExtractedBlock()
}

data class StructuredPdfPage(
    val pageIndex: Int,
    val pageWidthPt: Float,
    val pageHeightPt: Float,
    val rawText: String,
    val blocks: List<ExtractedBlock>,
    val tableGrid: List<List<String>>,
    val usedOcr: Boolean
)

object PdfStructuredExtractor {

    suspend fun extractPages(
        context: Context,
        pdfFile: File,
        enableOcr: Boolean,
        onProgress: (Float) -> Unit
    ): List<StructuredPdfPage> {
        PDFBoxResourceLoader.init(context.applicationContext)
        val results = mutableListOf<StructuredPdfPage>()

        PDDocument.load(pdfFile).use { doc ->
            val totalPages = doc.numberOfPages
            if (totalPages == 0) return emptyList()

            var pfd: ParcelFileDescriptor? = null
            var renderer: PdfRenderer? = null
            try {
                for (pageIdx in 0 until totalPages) {
                    onProgress((pageIdx.toFloat() / totalPages) * 0.8f)
                    val page = doc.getPage(pageIdx)
                    val pageW = page.mediaBox.width
                    val pageH = page.mediaBox.height

                    val collectedSpans = mutableListOf<TextSpanBox>()
                    val stripper = object : PDFTextStripper() {
                        override fun writeString(text: String?, textPositions: MutableList<TextPosition>?) {
                            if (text.isNullOrBlank() || textPositions.isNullOrEmpty()) return
                            val first = textPositions.first()
                            val last = textPositions.last()
                            val fontName = first.font?.name?.lowercase() ?: ""
                            val bold = fontName.contains("bold") || fontName.contains("black") || fontName.contains("heavy")
                            val italic = fontName.contains("italic") || fontName.contains("oblique")
                            val spanW = (last.xDirAdj + last.widthDirAdj - first.xDirAdj).coerceAtLeast(first.widthDirAdj)
                            collectedSpans.add(
                                TextSpanBox(
                                    text = text.trim(),
                                    x = first.xDirAdj,
                                    y = first.yDirAdj,
                                    width = spanW,
                                    height = first.heightDir.coerceAtLeast(8f),
                                    fontSize = first.fontSizeInPt.coerceAtLeast(8f),
                                    isBold = bold,
                                    isItalic = italic
                                )
                            )
                        }
                    }
                    stripper.startPage = pageIdx + 1
                    stripper.endPage = pageIdx + 1
                    stripper.sortByPosition = true
                    val plainText = stripper.getText(doc).trim()

                    var usedOcr = false
                    if (plainText.length < 12 && enableOcr) {
                        if (renderer == null) {
                            pfd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
                            renderer = PdfRenderer(pfd)
                        }
                        if (pageIdx < renderer.pageCount) {
                            renderer.openPage(pageIdx).use { rPage ->
                                val bmpW = (rPage.width * 2).coerceIn(600, 2200)
                                val bmpH = (rPage.height * 2).coerceIn(600, 2800)
                                val bmp = Bitmap.createBitmap(bmpW, bmpH, Bitmap.Config.ARGB_8888)
                                Canvas(bmp).drawColor(Color.WHITE)
                                rPage.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                try {
                                    val ocr = OcrEngine.recognizeBitmap(bmp)
                                    if (ocr.lines.isNotEmpty()) {
                                        usedOcr = true
                                        collectedSpans.clear()
                                        val scaleX = pageW / ocr.imageWidth.toFloat()
                                        val scaleY = pageH / ocr.imageHeight.toFloat()
                                        for (line in ocr.lines) {
                                            collectedSpans.add(
                                                TextSpanBox(
                                                    text = line.text,
                                                    x = line.bounds.left * scaleX,
                                                    y = line.bounds.top * scaleY,
                                                    width = line.bounds.width() * scaleX,
                                                    height = (line.bounds.height() * scaleY).coerceAtLeast(10f),
                                                    fontSize = (line.bounds.height() * scaleY * 0.8f).coerceIn(9f, 26f),
                                                    isBold = false,
                                                    isItalic = false
                                                )
                                            )
                                        }
                                    }
                                } finally {
                                    bmp.recycle()
                                }
                            }
                        }
                    }

                    val blocks = buildStructuredBlocks(collectedSpans, pageW)
                    val tableGrid = buildSpreadsheetGrid(collectedSpans)
                    val finalText = if (usedOcr) {
                        collectedSpans.joinToString("\n") { it.text }
                    } else {
                        plainText
                    }

                    results.add(
                        StructuredPdfPage(
                            pageIndex = pageIdx,
                            pageWidthPt = pageW,
                            pageHeightPt = pageH,
                            rawText = finalText,
                            blocks = blocks,
                            tableGrid = tableGrid,
                            usedOcr = usedOcr
                        )
                    )
                }
            } finally {
                renderer?.close()
                pfd?.close()
            }
        }
        return results
    }

    private fun clusterLines(spans: List<TextSpanBox>): List<List<TextSpanBox>> {
        if (spans.isEmpty()) return emptyList()
        val sorted = spans.sortedWith(compareBy<TextSpanBox> { it.y }.thenBy { it.x })
        val lines = mutableListOf<MutableList<TextSpanBox>>()
        for (span in sorted) {
            val existing = lines.lastOrNull()
            if (existing != null && abs(existing.first().y - span.y) <= (span.height * 0.65f).coerceIn(5f, 14f)) {
                existing.add(span)
            } else {
                lines.add(mutableListOf(span))
            }
        }
        lines.forEach { it.sortBy { s -> s.x } }
        return lines
    }

    private fun buildStructuredBlocks(spans: List<TextSpanBox>, pageW: Float): List<ExtractedBlock> {
        val lines = clusterLines(spans)
        if (lines.isEmpty()) return emptyList()

        val medianFont = spans.map { it.fontSize }.sorted().let { it[it.size / 2] }
        val blocks = mutableListOf<ExtractedBlock>()
        val pendingTableLines = mutableListOf<List<String>>()

        fun flushTable() {
            if (pendingTableLines.size >= 2) {
                val maxCols = pendingTableLines.maxOf { it.size }
                val normalized = pendingTableLines.map { row ->
                    if (row.size < maxCols) row + List(maxCols - row.size) { "" } else row
                }
                blocks.add(ExtractedBlock.Table(normalized))
            } else {
                for (row in pendingTableLines) {
                    blocks.add(ExtractedBlock.Paragraph(row.joinToString("  ")))
                }
            }
            pendingTableLines.clear()
        }

        for (line in lines) {
            // Split line into horizontal cells if large x-gaps exist (potential table row)
            val cells = mutableListOf<String>()
            val currentCell = StringBuilder()
            var prevEnd = -1f
            for (span in line) {
                if (prevEnd >= 0f && (span.x - prevEnd) > maxOf(18f, span.fontSize * 1.8f)) {
                    cells.add(currentCell.toString().trim())
                    currentCell.clear()
                } else if (currentCell.isNotEmpty()) {
                    currentCell.append(' ')
                }
                currentCell.append(span.text)
                prevEnd = span.x + span.width
            }
            if (currentCell.isNotEmpty()) cells.add(currentCell.toString().trim())

            if (cells.size >= 2) {
                pendingTableLines.add(cells)
            } else {
                flushTable()
                val text = line.joinToString(" ") { it.text }.trim()
                if (text.isBlank()) continue
                val avgFont = line.map { it.fontSize }.average().toFloat()
                val mostlyBold = line.count { it.isBold } > line.size / 2
                val mostlyItalic = line.count { it.isItalic } > line.size / 2
                if (avgFont >= medianFont * 1.32f && text.length < 120) {
                    blocks.add(ExtractedBlock.Heading(text, 1))
                } else if ((avgFont >= medianFont * 1.15f || mostlyBold) && text.length < 90 && line.first().x < pageW * 0.35f) {
                    blocks.add(ExtractedBlock.Heading(text, 2))
                } else {
                    blocks.add(ExtractedBlock.Paragraph(text, isBold = mostlyBold, isItalic = mostlyItalic))
                }
            }
        }
        flushTable()
        return blocks
    }

    private fun buildSpreadsheetGrid(spans: List<TextSpanBox>): List<List<String>> {
        val lines = clusterLines(spans)
        if (lines.isEmpty()) return emptyList()

        // Cluster x-positions into global column buckets for aligned tabular extraction
        val xBuckets = mutableListOf<Float>()
        val allX = spans.map { it.x }.sorted()
        for (x in allX) {
            val match = xBuckets.indexOfFirst { abs(it - x) <= 24f }
            if (match == -1) xBuckets.add(x)
        }
        xBuckets.sort()
        if (xBuckets.isEmpty()) return emptyList()

        return lines.map { line ->
            val row = MutableList(xBuckets.size) { "" }
            for (span in line) {
                val colIdx = xBuckets.indices.minByOrNull { abs(xBuckets[it] - span.x) } ?: 0
                row[colIdx] = if (row[colIdx].isEmpty()) span.text else "${row[colIdx]} ${span.text}"
            }
            // Trim trailing empty cells
            var lastNonEmpty = row.indexOfLast { it.isNotBlank() }
            if (lastNonEmpty < 0) listOf("") else row.subList(0, lastNonEmpty + 1)
        }
    }
}
