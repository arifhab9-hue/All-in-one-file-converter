package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.example.R
import com.example.core.model.ConversionOptions
import com.example.core.model.ConversionOutputFile
import com.example.core.model.ConversionResult
import com.example.core.model.MarkupKind
import com.example.core.model.PdfAnnotationItem
import com.example.core.model.PdfMetadataInfo
import com.example.core.model.ToolId
import com.example.core.model.WorkspaceFile
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import com.tom_roush.pdfbox.pdmodel.font.PDFont
import com.tom_roush.pdfbox.pdmodel.font.PDType0Font
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState
import com.tom_roush.pdfbox.util.Matrix
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

object PdfToolsEngine {

    private fun ensureInit(context: Context) {
        PDFBoxResourceLoader.init(context.applicationContext)
    }

    private fun loadSafeFont(context: Context, doc: PDDocument, text: String): PDFont {
        val hasNonAscii = text.any { it.code > 127 }
        if (hasNonAscii) {
            return try {
                val hasBengali = text.any { it.code in 0x0980..0x09FF }
                val resId = if (hasBengali) R.font.noto_sans_bengali else R.font.plus_jakarta_sans
                context.resources.openRawResource(resId).use { stream ->
                    PDType0Font.load(doc, stream)
                }
            } catch (_: Exception) {
                PDType1Font.HELVETICA
            }
        }
        return PDType1Font.HELVETICA_BOLD
    }

    fun getPageCount(context: Context, file: File): Int {
        ensureInit(context)
        return PDDocument.load(file).use { it.numberOfPages }
    }

    fun inspectMetadata(context: Context, file: File): PdfMetadataInfo {
        ensureInit(context)
        return PDDocument.load(file).use { doc ->
            val info = doc.documentInformation
            PdfMetadataInfo(
                title = info?.title ?: "",
                author = info?.author ?: "",
                subject = info?.subject ?: "",
                keywords = info?.keywords ?: "",
                creator = info?.creator ?: "",
                producer = info?.producer ?: "",
                pageCount = doc.numberOfPages,
                isEncrypted = doc.isEncrypted,
                fileSizeBytes = file.length()
            )
        }
    }

    fun updateMetadata(
        context: Context,
        wsFile: WorkspaceFile,
        options: ConversionOptions
    ): ConversionResult {
        ensureInit(context)
        val outFile = FileStorageHelper.createOutputFile(
            context,
            "${wsFile.name.substringBeforeLast('.')}_metadata.pdf"
        )
        var pages = 0
        PDDocument.load(wsFile.localFile).use { doc ->
            pages = doc.numberOfPages
            val info = doc.documentInformation
            if (options.customMetadataTitle.isNotBlank()) info.title = options.customMetadataTitle
            if (options.customMetadataAuthor.isNotBlank()) info.author = options.customMetadataAuthor
            if (options.customMetadataSubject.isNotBlank()) info.subject = options.customMetadataSubject
            if (options.customMetadataKeywords.isNotBlank()) info.keywords = options.customMetadataKeywords
            doc.documentInformation = info
            doc.save(outFile)
        }
        val meta = inspectMetadata(context, outFile)
        val summary = buildString {
            appendLine("Pages: ${meta.pageCount}")
            appendLine("Title: ${meta.title.ifBlank { "-" }}")
            appendLine("Author: ${meta.author.ifBlank { "-" }}")
            appendLine("Subject: ${meta.subject.ifBlank { "-" }}")
            appendLine("Keywords: ${meta.keywords.ifBlank { "-" }}")
            appendLine("Creator: ${meta.creator.ifBlank { "-" }}")
            appendLine("Producer: ${meta.producer.ifBlank { "-" }}")
            appendLine("Encrypted: ${meta.isEncrypted}")
        }
        return ConversionResult(
            toolId = ToolId.PDF_METADATA,
            outputFiles = listOf(ConversionOutputFile(outFile.name, outFile, "application/pdf", outFile.length())),
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outFile.length(),
            pageCount = pages,
            previewText = summary
        )
    }

    fun mergePdfs(
        context: Context,
        files: List<WorkspaceFile>,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        if (files.size < 2) throw IllegalArgumentException("Select at least 2 PDF files to merge")
        ensureInit(context)
        val outFile = FileStorageHelper.createOutputFile(context, "merged_${files.size}_files.pdf")
        val merger = PDFMergerUtility()
        merger.destinationFileName = outFile.absolutePath
        files.forEachIndexed { idx, ws ->
            onProgress((idx.toFloat() / files.size) * 0.7f)
            merger.addSource(ws.localFile)
        }
        merger.mergeDocuments(null)
        onProgress(1f)
        val pages = getPageCount(context, outFile)
        return ConversionResult(
            toolId = ToolId.MERGE_PDF,
            outputFiles = listOf(ConversionOutputFile(outFile.name, outFile, "application/pdf", outFile.length())),
            originalTotalBytes = files.sumOf { it.sizeBytes },
            outputTotalBytes = outFile.length(),
            pageCount = pages
        )
    }

    fun splitPdf(
        context: Context,
        wsFile: WorkspaceFile,
        pageRangeExpr: String,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        ensureInit(context)
        val base = wsFile.name.substringBeforeLast('.')
        val outputs = mutableListOf<ConversionOutputFile>()
        PDDocument.load(wsFile.localFile).use { src ->
            val total = src.numberOfPages
            if (total == 0) throw IllegalStateException("PDF has 0 pages")
            if (pageRangeExpr.isBlank()) {
                // Split into individual pages + ZIP
                for (i in 0 until total) {
                    onProgress((i.toFloat() / total) * 0.9f)
                    PDDocument().use { single ->
                        single.importPage(src.getPage(i))
                        val f = FileStorageHelper.createOutputFile(context, "${base}_page_${i + 1}.pdf")
                        single.save(f)
                        outputs.add(ConversionOutputFile(f.name, f, "application/pdf", f.length()))
                    }
                }
            } else {
                val pagesToKeep = parsePageSelection(pageRangeExpr, total)
                if (pagesToKeep.isEmpty()) throw IllegalArgumentException("Invalid page range: $pageRangeExpr")
                PDDocument().use { part ->
                    pagesToKeep.forEachIndexed { idx, pageNum1Based ->
                        onProgress((idx.toFloat() / pagesToKeep.size) * 0.9f)
                        part.importPage(src.getPage(pageNum1Based - 1))
                    }
                    val f = FileStorageHelper.createOutputFile(context, "${base}_split.pdf")
                    part.save(f)
                    outputs.add(ConversionOutputFile(f.name, f, "application/pdf", f.length()))
                }
            }
        }
        val zipFile = if (outputs.size > 1) {
            val z = FileStorageHelper.createOutputFile(context, "${base}_split_pages.zip")
            FileStorageHelper.createZipArchive(outputs.map { it.file }, z)
        } else null
        onProgress(1f)
        return ConversionResult(
            toolId = ToolId.SPLIT_PDF,
            outputFiles = outputs,
            zipFile = zipFile,
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outputs.sumOf { it.sizeBytes },
            pageCount = outputs.size
        )
    }

    fun compressPdf(
        context: Context,
        toolId: ToolId,
        wsFile: WorkspaceFile,
        options: ConversionOptions,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        ensureInit(context)
        val pfd = ParcelFileDescriptor.open(wsFile.localFile, ParcelFileDescriptor.MODE_READ_ONLY)
        val renderer = PdfRenderer(pfd)
        val outFile = FileStorageHelper.createOutputFile(
            context,
            "${wsFile.name.substringBeforeLast('.')}_compressed.pdf"
        )
        try {
            val total = renderer.pageCount
            if (total == 0) throw IllegalStateException("PDF has 0 pages")

            val targetBytes = if (options.useTargetSize && options.targetSizeKb > 0) {
                options.targetSizeKb * 1024L
            } else null

            val perPageTarget = targetBytes?.let { (it * 0.92 / total).toLong().coerceAtLeast(8 * 1024L) }
            val scale = when {
                options.quality >= 80 -> 1.6f
                options.quality >= 55 -> 1.25f
                else -> 1.0f
            }

            val pdfDoc = PdfDocument()
            try {
                for (i in 0 until total) {
                    onProgress((i.toFloat() / total) * 0.88f)
                    renderer.openPage(i).use { page ->
                        val bmpW = (page.width * scale).toInt().coerceIn(240, 2000)
                        val bmpH = (page.height * scale).toInt().coerceIn(240, 2600)
                        val rawBmp = Bitmap.createBitmap(bmpW, bmpH, Bitmap.Config.ARGB_8888)
                        Canvas(rawBmp).drawColor(Color.WHITE)
                        page.render(rawBmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)

                        val jpegBytes = if (perPageTarget != null) {
                            ImagePdfEngine.compressBitmapToTarget(
                                bitmap = rawBmp,
                                format = Bitmap.CompressFormat.JPEG,
                                targetBytes = perPageTarget,
                                initialQuality = options.quality
                            )
                        } else {
                            ByteArrayOutputStream().use { baos ->
                                rawBmp.compress(Bitmap.CompressFormat.JPEG, options.quality.coerceIn(15, 95), baos)
                                baos.toByteArray()
                            }
                        }
                        rawBmp.recycle()

                        val compressedBmp = BitmapFactory.decodeByteArray(jpegBytes, 0, jpegBytes.size)
                        try {
                            val pageInfo = PdfDocument.PageInfo.Builder(page.width, page.height, i + 1).create()
                            val outPage = pdfDoc.startPage(pageInfo)
                            outPage.canvas.drawBitmap(
                                compressedBmp,
                                null,
                                android.graphics.Rect(0, 0, page.width, page.height),
                                null
                            )
                            pdfDoc.finishPage(outPage)
                        } finally {
                            compressedBmp.recycle()
                        }
                    }
                }
                FileOutputStream(outFile).use { pdfDoc.writeTo(it) }
            } finally {
                pdfDoc.close()
            }
            onProgress(1f)
            return ConversionResult(
                toolId = toolId,
                outputFiles = listOf(ConversionOutputFile(outFile.name, outFile, "application/pdf", outFile.length())),
                originalTotalBytes = wsFile.sizeBytes,
                outputTotalBytes = outFile.length(),
                pageCount = total
            )
        } finally {
            renderer.close()
            pfd.close()
        }
    }

    fun rotatePdf(
        context: Context,
        wsFile: WorkspaceFile,
        options: ConversionOptions,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        ensureInit(context)
        val outFile = FileStorageHelper.createOutputFile(
            context,
            "${wsFile.name.substringBeforeLast('.')}_rotated.pdf"
        )
        var total = 0
        PDDocument.load(wsFile.localFile).use { doc ->
            total = doc.numberOfPages
            val targets = if (options.pageRange.isBlank()) (1..total).toList() else parsePageSelection(options.pageRange, total)
            targets.forEachIndexed { idx, pageNum ->
                onProgress((idx.toFloat() / targets.size.coerceAtLeast(1)) * 0.9f)
                val page = doc.getPage(pageNum - 1)
                page.rotation = (page.rotation + options.rotationDegrees) % 360
            }
            doc.save(outFile)
        }
        onProgress(1f)
        return ConversionResult(
            toolId = ToolId.ROTATE_PDF,
            outputFiles = listOf(ConversionOutputFile(outFile.name, outFile, "application/pdf", outFile.length())),
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outFile.length(),
            pageCount = total
        )
    }

    fun deletePages(
        context: Context,
        wsFile: WorkspaceFile,
        pageRangeExpr: String,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        ensureInit(context)
        val outFile = FileStorageHelper.createOutputFile(
            context,
            "${wsFile.name.substringBeforeLast('.')}_trimmed.pdf"
        )
        var remaining = 0
        PDDocument.load(wsFile.localFile).use { doc ->
            val total = doc.numberOfPages
            val toDelete = parsePageSelection(pageRangeExpr, total).toSet()
            if (toDelete.isEmpty()) throw IllegalArgumentException("Specify page numbers to delete (e.g. 2, 4-5)")
            if (toDelete.size >= total) throw IllegalArgumentException("Cannot delete all pages from the PDF")
            onProgress(0.4f)
            for (pageNum in toDelete.sortedDescending()) {
                doc.removePage(pageNum - 1)
            }
            remaining = doc.numberOfPages
            doc.save(outFile)
        }
        onProgress(1f)
        return ConversionResult(
            toolId = ToolId.DELETE_PDF_PAGES,
            outputFiles = listOf(ConversionOutputFile(outFile.name, outFile, "application/pdf", outFile.length())),
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outFile.length(),
            pageCount = remaining
        )
    }

    fun extractOrRearrangePages(
        context: Context,
        toolId: ToolId,
        wsFile: WorkspaceFile,
        pageSequenceExpr: String,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        ensureInit(context)
        val suffix = if (toolId == ToolId.REARRANGE_PDF_PAGES) "reordered" else "extracted"
        val outFile = FileStorageHelper.createOutputFile(
            context,
            "${wsFile.name.substringBeforeLast('.')}_$suffix.pdf"
        )
        var count = 0
        PDDocument.load(wsFile.localFile).use { src ->
            val total = src.numberOfPages
            val sequence = if (pageSequenceExpr.isBlank()) {
                (1..total).toList()
            } else {
                parsePageSelection(pageSequenceExpr, total, preserveOrder = true)
            }
            if (sequence.isEmpty()) throw IllegalArgumentException("Enter valid page numbers (1..$total)")
            PDDocument().use { dst ->
                sequence.forEachIndexed { idx, p ->
                    onProgress((idx.toFloat() / sequence.size) * 0.9f)
                    dst.importPage(src.getPage(p - 1))
                }
                count = dst.numberOfPages
                dst.save(outFile)
            }
        }
        onProgress(1f)
        return ConversionResult(
            toolId = toolId,
            outputFiles = listOf(ConversionOutputFile(outFile.name, outFile, "application/pdf", outFile.length())),
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outFile.length(),
            pageCount = count
        )
    }

    fun unlockPdf(
        context: Context,
        wsFile: WorkspaceFile,
        password: String,
        authorized: Boolean,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        if (!authorized) {
            throw IllegalArgumentException("Please confirm you are authorized to unlock this PDF.")
        }
        ensureInit(context)
        val outFile = FileStorageHelper.createOutputFile(
            context,
            "${wsFile.name.substringBeforeLast('.')}_unlocked.pdf"
        )
        onProgress(0.3f)
        var total = 0
        PDDocument.load(wsFile.localFile, password).use { doc ->
            doc.isAllSecurityToBeRemoved = true
            total = doc.numberOfPages
            onProgress(0.75f)
            doc.save(outFile)
        }
        onProgress(1f)
        return ConversionResult(
            toolId = ToolId.UNLOCK_PDF,
            outputFiles = listOf(ConversionOutputFile(outFile.name, outFile, "application/pdf", outFile.length())),
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outFile.length(),
            pageCount = total
        )
    }

    fun protectPdf(
        context: Context,
        wsFile: WorkspaceFile,
        password: String,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        if (password.isBlank()) throw IllegalArgumentException("Please enter a password to protect the PDF.")
        ensureInit(context)
        val outFile = FileStorageHelper.createOutputFile(
            context,
            "${wsFile.name.substringBeforeLast('.')}_protected.pdf"
        )
        onProgress(0.3f)
        var total = 0
        PDDocument.load(wsFile.localFile).use { doc ->
            total = doc.numberOfPages
            val ap = AccessPermission()
            val spp = StandardProtectionPolicy(password, password, ap)
            spp.encryptionKeyLength = 128
            doc.protect(spp)
            onProgress(0.8f)
            doc.save(outFile)
        }
        onProgress(1f)
        return ConversionResult(
            toolId = ToolId.PROTECT_PDF,
            outputFiles = listOf(ConversionOutputFile(outFile.name, outFile, "application/pdf", outFile.length())),
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outFile.length(),
            pageCount = total
        )
    }

    fun addWatermark(
        context: Context,
        wsFile: WorkspaceFile,
        watermarkText: String,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        val text = watermarkText.ifBlank { "CONFIDENTIAL" }
        ensureInit(context)
        val outFile = FileStorageHelper.createOutputFile(
            context,
            "${wsFile.name.substringBeforeLast('.')}_watermarked.pdf"
        )
        var total = 0
        PDDocument.load(wsFile.localFile).use { doc ->
            total = doc.numberOfPages
            val font = loadSafeFont(context, doc, text)
            for (i in 0 until total) {
                onProgress((i.toFloat() / total) * 0.9f)
                val page = doc.getPage(i)
                val box = page.mediaBox
                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                    val gs = PDExtendedGraphicsState()
                    gs.nonStrokingAlphaConstant = 0.22f
                    cs.setGraphicsStateParameters(gs)
                    cs.setNonStrokingColor(220, 38, 38)
                    val fontSize = (minOf(box.width, box.height) / 10f).coerceIn(24f, 64f)
                    cs.beginText()
                    cs.setFont(font, fontSize)
                    val cx = box.width / 2f
                    val cy = box.height / 2f
                    val rad = Math.toRadians(38.0)
                    val matrix = Matrix.getRotateInstance(rad, cx - box.width * 0.28f, cy - box.height * 0.1f)
                    cs.setTextMatrix(matrix)
                    cs.showText(text)
                    cs.endText()
                }
            }
            doc.save(outFile)
        }
        onProgress(1f)
        return ConversionResult(
            toolId = ToolId.ADD_WATERMARK,
            outputFiles = listOf(ConversionOutputFile(outFile.name, outFile, "application/pdf", outFile.length())),
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outFile.length(),
            pageCount = total
        )
    }

    fun addPageNumbers(
        context: Context,
        wsFile: WorkspaceFile,
        prefix: String,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        ensureInit(context)
        val outFile = FileStorageHelper.createOutputFile(
            context,
            "${wsFile.name.substringBeforeLast('.')}_numbered.pdf"
        )
        var total = 0
        PDDocument.load(wsFile.localFile).use { doc ->
            total = doc.numberOfPages
            val sampleLabel = "${prefix}1 / $total"
            val font = loadSafeFont(context, doc, sampleLabel)
            for (i in 0 until total) {
                onProgress((i.toFloat() / total) * 0.9f)
                val page = doc.getPage(i)
                val box = page.mediaBox
                val label = "$prefix${i + 1} / $total"
                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                    cs.setNonStrokingColor(40, 40, 40)
                    cs.beginText()
                    cs.setFont(font, 11f)
                    val textW = (font.getStringWidth(label) / 1000f) * 11f
                    cs.newLineAtOffset((box.width - textW) / 2f, 22f)
                    cs.showText(label)
                    cs.endText()
                }
            }
            doc.save(outFile)
        }
        onProgress(1f)
        return ConversionResult(
            toolId = ToolId.ADD_PAGE_NUMBER,
            outputFiles = listOf(ConversionOutputFile(outFile.name, outFile, "application/pdf", outFile.length())),
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outFile.length(),
            pageCount = total
        )
    }

    fun applyEditorEdits(
        context: Context,
        sourcePdf: File,
        annotations: List<PdfAnnotationItem>,
        watermarkText: String?,
        addPageNumbers: Boolean,
        onProgress: (Float) -> Unit
    ): File {
        ensureInit(context)
        val outFile = FileStorageHelper.createOutputFile(
            context,
            "${sourcePdf.nameWithoutExtension}_edited.pdf"
        )
        PDDocument.load(sourcePdf).use { doc ->
            val total = doc.numberOfPages
            for (pageIdx in 0 until total) {
                onProgress((pageIdx.toFloat() / total.coerceAtLeast(1)) * 0.9f)
                val page = doc.getPage(pageIdx)
                val box = page.cropBox ?: page.mediaBox
                val pageW = box.width
                val pageH = box.height
                val originX = box.lowerLeftX
                val originY = box.lowerLeftY

                val pageItems = annotations.filter { it.pageIndex == pageIdx }
                val cropItem = pageItems.filterIsInstance<PdfAnnotationItem.CropAnnotation>().lastOrNull()
                if (cropItem != null) {
                    val newLeft = originX + pageW * cropItem.marginLeftFrac.coerceIn(0f, 0.4f)
                    val newBottom = originY + pageH * cropItem.marginBottomFrac.coerceIn(0f, 0.4f)
                    val newW = (pageW * (1f - cropItem.marginLeftFrac - cropItem.marginRightFrac)).coerceAtLeast(60f)
                    val newH = (pageH * (1f - cropItem.marginTopFrac - cropItem.marginBottomFrac)).coerceAtLeast(60f)
                    page.cropBox = PDRectangle(newLeft, newBottom, newW, newH)
                }

                if (pageItems.isNotEmpty() || !watermarkText.isNullOrBlank() || addPageNumbers) {
                    PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                        for (item in pageItems) {
                            when (item) {
                                is PdfAnnotationItem.MarkupAnnotation -> {
                                    val r = (item.colorArgb shr 16) and 0xFF
                                    val g = (item.colorArgb shr 8) and 0xFF
                                    val b = item.colorArgb and 0xFF
                                    val left = originX + item.normLeft * pageW
                                    val right = originX + item.normRight * pageW
                                    val topPdf = originY + (1f - item.normTop) * pageH
                                    val bottomPdf = originY + (1f - item.normBottom) * pageH
                                    when (item.kind) {
                                        MarkupKind.HIGHLIGHT -> {
                                            val gs = PDExtendedGraphicsState()
                                            gs.nonStrokingAlphaConstant = 0.35f
                                            cs.setGraphicsStateParameters(gs)
                                            cs.setNonStrokingColor(r, g, b)
                                            cs.addRect(
                                                minOf(left, right),
                                                minOf(bottomPdf, topPdf),
                                                kotlin.math.abs(right - left).coerceAtLeast(18f),
                                                kotlin.math.abs(topPdf - bottomPdf).coerceAtLeast(12f)
                                            )
                                            cs.fill()
                                            val resetGs = PDExtendedGraphicsState()
                                            resetGs.nonStrokingAlphaConstant = 1f
                                            cs.setGraphicsStateParameters(resetGs)
                                        }
                                        MarkupKind.UNDERLINE -> {
                                            cs.setStrokingColor(r, g, b)
                                            cs.setLineWidth(1.8f)
                                            cs.moveTo(minOf(left, right), minOf(bottomPdf, topPdf))
                                            cs.lineTo(maxOf(left, right), minOf(bottomPdf, topPdf))
                                            cs.stroke()
                                        }
                                        MarkupKind.STRIKE_THROUGH -> {
                                            val midY = (topPdf + bottomPdf) / 2f
                                            cs.setStrokingColor(r, g, b)
                                            cs.setLineWidth(1.8f)
                                            cs.moveTo(minOf(left, right), midY)
                                            cs.lineTo(maxOf(left, right), midY)
                                            cs.stroke()
                                        }
                                    }
                                }

                                is PdfAnnotationItem.FreehandAnnotation -> {
                                    if (item.pointsNorm.size >= 2) {
                                        val r = (item.colorArgb shr 16) and 0xFF
                                        val g = (item.colorArgb shr 8) and 0xFF
                                        val b = item.colorArgb and 0xFF
                                        cs.setStrokingColor(r, g, b)
                                        cs.setLineWidth(item.strokeWidthDp.coerceIn(1f, 8f))
                                        val first = item.pointsNorm.first()
                                        cs.moveTo(originX + first.first * pageW, originY + (1f - first.second) * pageH)
                                        for (pt in item.pointsNorm.drop(1)) {
                                            cs.lineTo(originX + pt.first * pageW, originY + (1f - pt.second) * pageH)
                                        }
                                        cs.stroke()
                                    }
                                }

                                is PdfAnnotationItem.ImageAnnotation -> {
                                    if (item.imageFile.exists()) {
                                        val bmp = ImagePdfEngine.decodeImageSafe(item.imageFile, maxDim = 1200)
                                        val pdImg = LosslessFactory.createFromImage(doc, bmp)
                                        bmp.recycle()
                                        val imgW = item.normWidth * pageW
                                        val imgH = item.normHeight * pageH
                                        val imgX = originX + item.normLeft * pageW
                                        val imgY = originY + (1f - item.normTop) * pageH - imgH
                                        cs.drawImage(pdImg, imgX, imgY, imgW, imgH)
                                    }
                                }

                                is PdfAnnotationItem.TextAnnotation -> {
                                    val r = (item.colorArgb shr 16) and 0xFF
                                    val g = (item.colorArgb shr 8) and 0xFF
                                    val b = item.colorArgb and 0xFF
                                    val font = loadSafeFont(context, doc, item.text)
                                    val px = originX + item.normX * pageW
                                    val py = originY + (1f - item.normY) * pageH
                                    if (item.isBoxed) {
                                        val boxW = (item.text.length * item.fontSizePt * 0.6f + 16f).coerceIn(80f, pageW * 0.7f)
                                        val boxH = item.fontSizePt + 14f
                                        cs.setNonStrokingColor(255, 251, 235)
                                        cs.addRect(px - 6f, py - 6f, boxW, boxH)
                                        cs.fill()
                                        cs.setStrokingColor(r, g, b)
                                        cs.setLineWidth(1.2f)
                                        cs.addRect(px - 6f, py - 6f, boxW, boxH)
                                        cs.stroke()
                                    }
                                    cs.setNonStrokingColor(r, g, b)
                                    cs.beginText()
                                    cs.setFont(font, item.fontSizePt)
                                    cs.newLineAtOffset(px, py)
                                    cs.showText(item.text)
                                    cs.endText()
                                }

                                is PdfAnnotationItem.DigitalSealAnnotation -> {
                                    val sx = originX + item.normX * pageW
                                    val sy = originY + (1f - item.normY) * pageH
                                    val sealW = 195f
                                    val sealH = 54f
                                    cs.setNonStrokingColor(239, 246, 255)
                                    cs.addRect(sx, sy - sealH, sealW, sealH)
                                    cs.fill()
                                    cs.setStrokingColor(21, 110, 252)
                                    cs.setLineWidth(1.5f)
                                    cs.addRect(sx, sy - sealH, sealW, sealH)
                                    cs.stroke()

                                    val font = loadSafeFont(context, doc, item.signerName + item.reason)
                                    cs.setNonStrokingColor(15, 23, 42)
                                    cs.beginText()
                                    cs.setFont(font, 9.5f)
                                    cs.newLineAtOffset(sx + 8f, sy - 16f)
                                    cs.showText("Digitally Signed: ${item.signerName}")
                                    cs.endText()

                                    cs.beginText()
                                    cs.setFont(font, 8f)
                                    cs.newLineAtOffset(sx + 8f, sy - 30f)
                                    cs.showText("Reason: ${item.reason}")
                                    cs.endText()

                                    cs.beginText()
                                    cs.setFont(font, 7.5f)
                                    cs.newLineAtOffset(sx + 8f, sy - 43f)
                                    cs.showText(item.timestampText)
                                    cs.endText()
                                }

                                is PdfAnnotationItem.CropAnnotation -> Unit
                            }
                        }

                        if (!watermarkText.isNullOrBlank()) {
                            val font = loadSafeFont(context, doc, watermarkText)
                            val gs = PDExtendedGraphicsState()
                            gs.nonStrokingAlphaConstant = 0.2f
                            cs.setGraphicsStateParameters(gs)
                            cs.setNonStrokingColor(220, 38, 38)
                            cs.beginText()
                            cs.setFont(font, 36f)
                            cs.setTextMatrix(Matrix.getRotateInstance(Math.toRadians(35.0), originX + pageW * 0.22f, originY + pageH * 0.4f))
                            cs.showText(watermarkText)
                            cs.endText()
                            val reset = PDExtendedGraphicsState()
                            reset.nonStrokingAlphaConstant = 1f
                            cs.setGraphicsStateParameters(reset)
                        }

                        if (addPageNumbers) {
                            val label = "${pageIdx + 1} / $total"
                            val font = PDType1Font.HELVETICA
                            cs.setNonStrokingColor(50, 50, 50)
                            cs.beginText()
                            cs.setFont(font, 10.5f)
                            cs.newLineAtOffset(originX + pageW / 2f - 18f, originY + 18f)
                            cs.showText(label)
                            cs.endText()
                        }
                    }
                }
            }
            doc.save(outFile)
        }
        onProgress(1f)
        return outFile
    }

    fun parsePageSelection(expr: String, totalPages: Int, preserveOrder: Boolean = false): List<Int> {
        val result = mutableListOf<Int>()
        val parts = expr.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        for (part in parts) {
            if (part.contains('-')) {
                val bounds = part.split("-").mapNotNull { it.trim().toIntOrNull() }
                if (bounds.size == 2) {
                    val start = bounds[0].coerceIn(1, totalPages)
                    val end = bounds[1].coerceIn(1, totalPages)
                    if (start <= end) {
                        for (p in start..end) result.add(p)
                    } else {
                        for (p in start downTo end) result.add(p)
                    }
                }
            } else {
                val p = part.toIntOrNull()
                if (p != null && p in 1..totalPages) {
                    result.add(p)
                }
            }
        }
        return if (preserveOrder) result else result.distinct().sorted()
    }
}
