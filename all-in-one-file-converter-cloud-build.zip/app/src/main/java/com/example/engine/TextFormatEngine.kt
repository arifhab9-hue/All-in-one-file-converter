package com.example.engine

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.example.core.model.ConversionOptions
import com.example.core.model.ConversionOutputFile
import com.example.core.model.ConversionResult
import com.example.core.model.ToolId
import com.example.core.model.WorkspaceFile
import org.jsoup.Jsoup
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.File
import java.io.FileOutputStream
import java.io.StringReader

object TextFormatEngine {

    fun txtToPdf(context: Context, wsFile: WorkspaceFile, onProgress: (Float) -> Unit): ConversionResult {
        onProgress(0.2f)
        val text = wsFile.localFile.readText(Charsets.UTF_8)
        val lines = text.split('\n')
        val outFile = FileStorageHelper.createOutputFile(context, "${wsFile.name.substringBeforeLast('.')}.pdf")
        val pages = renderParagraphsToPdf(lines.map { it to false }, outFile, onProgress)
        return ConversionResult(
            toolId = ToolId.TXT_TO_PDF,
            outputFiles = listOf(ConversionOutputFile(outFile.name, outFile, "application/pdf", outFile.length())),
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outFile.length(),
            pageCount = pages
        )
    }

    suspend fun pdfToTxt(
        context: Context,
        wsFile: WorkspaceFile,
        options: ConversionOptions,
        onProgress: (Float) -> Unit
    ): ConversionResult {
        val pages = PdfStructuredExtractor.extractPages(context, wsFile.localFile, options.enableOcr) { p ->
            onProgress(p * 0.85f)
        }
        val combined = buildString {
            pages.forEachIndexed { idx, p ->
                appendLine("=== Page ${idx + 1}${if (p.usedOcr) " (OCR)" else ""} ===")
                appendLine(p.rawText)
                appendLine()
            }
        }
        val outFile = FileStorageHelper.createOutputFile(context, "${wsFile.name.substringBeforeLast('.')}.txt")
        outFile.writeText(combined, Charsets.UTF_8)
        onProgress(1f)
        return ConversionResult(
            toolId = ToolId.PDF_TO_TXT,
            outputFiles = listOf(ConversionOutputFile(outFile.name, outFile, "text/plain", outFile.length())),
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outFile.length(),
            pageCount = pages.size,
            previewText = combined.take(3500)
        )
    }

    fun htmlToPdf(context: Context, wsFile: WorkspaceFile, onProgress: (Float) -> Unit): ConversionResult {
        onProgress(0.2f)
        val html = wsFile.localFile.readText(Charsets.UTF_8)
        val doc = Jsoup.parse(html)
        val blocks = mutableListOf<Pair<String, Boolean>>()
        val title = doc.title().trim()
        if (title.isNotEmpty()) blocks.add(title to true)
        for (el in doc.select("h1,h2,h3,h4,p,li,pre,blockquote,tr")) {
            val t = el.text().trim()
            if (t.isNotEmpty()) {
                val isHeading = el.tagName().startsWith("h")
                val prefix = if (el.tagName() == "li") "• " else ""
                blocks.add((prefix + t) to isHeading)
            }
        }
        if (blocks.isEmpty()) {
            val fallback = doc.body()?.text()?.ifBlank { "(Empty HTML)" } ?: "(Empty HTML)"
            blocks.add(fallback to false)
        }
        val outFile = FileStorageHelper.createOutputFile(context, "${wsFile.name.substringBeforeLast('.')}.pdf")
        val pages = renderParagraphsToPdf(blocks, outFile, onProgress)
        return ConversionResult(
            toolId = ToolId.HTML_TO_PDF,
            outputFiles = listOf(ConversionOutputFile(outFile.name, outFile, "application/pdf", outFile.length())),
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outFile.length(),
            pageCount = pages
        )
    }

    fun rtfToPdf(context: Context, wsFile: WorkspaceFile, onProgress: (Float) -> Unit): ConversionResult {
        onProgress(0.2f)
        val raw = wsFile.localFile.readText(Charsets.UTF_8)
        val paras = parseRtfParagraphs(raw)
        val outFile = FileStorageHelper.createOutputFile(context, "${wsFile.name.substringBeforeLast('.')}.pdf")
        val pages = renderParagraphsToPdf(paras.map { it to false }, outFile, onProgress)
        return ConversionResult(
            toolId = ToolId.RTF_TO_PDF,
            outputFiles = listOf(ConversionOutputFile(outFile.name, outFile, "application/pdf", outFile.length())),
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outFile.length(),
            pageCount = pages
        )
    }

    fun odtToPdf(context: Context, wsFile: WorkspaceFile, onProgress: (Float) -> Unit): ConversionResult {
        onProgress(0.2f)
        val entries = OfficeWordEngine.readZipEntries(wsFile.localFile)
        val contentXml = entries["content.xml"]?.toString(Charsets.UTF_8)
            ?: throw IllegalStateException("Invalid ODT file: content.xml missing")
        val paras = mutableListOf<Pair<String, Boolean>>()
        val parser = XmlPullParserFactory.newInstance().newPullParser()
        parser.setInput(StringReader(contentXml))
        var ev = parser.eventType
        var inText = false
        var isH = false
        val sb = StringBuilder()
        while (ev != XmlPullParser.END_DOCUMENT) {
            val tag = parser.name?.substringAfter(':')
            when (ev) {
                XmlPullParser.START_TAG -> when (tag) {
                    "h" -> { inText = true; isH = true; sb.clear() }
                    "p" -> { inText = true; isH = false; sb.clear() }
                    "tab" -> if (inText) sb.append("    ")
                    "line-break" -> if (inText) sb.append('\n')
                }
                XmlPullParser.TEXT -> if (inText) sb.append(parser.text)
                XmlPullParser.END_TAG -> if ((tag == "h" || tag == "p") && inText) {
                    val txt = sb.toString().trim()
                    if (txt.isNotEmpty()) paras.add(txt to isH)
                    inText = false
                }
            }
            ev = parser.next()
        }
        val outFile = FileStorageHelper.createOutputFile(context, "${wsFile.name.substringBeforeLast('.')}.pdf")
        val pages = renderParagraphsToPdf(paras, outFile, onProgress)
        return ConversionResult(
            toolId = ToolId.ODT_TO_PDF,
            outputFiles = listOf(ConversionOutputFile(outFile.name, outFile, "application/pdf", outFile.length())),
            originalTotalBytes = wsFile.sizeBytes,
            outputTotalBytes = outFile.length(),
            pageCount = pages
        )
    }

    fun parseRtfParagraphs(rtf: String): List<String> {
        val out = StringBuilder()
        var i = 0
        var depth = 0
        var skipDepth = Int.MAX_VALUE
        val skipGroups = setOf("fonttbl", "colortbl", "stylesheet", "info", "pict", "object", "header", "footer")

        while (i < rtf.length) {
            val ch = rtf[i]
            when (ch) {
                '{' -> {
                    depth++
                    val lookahead = rtf.substring((i + 1).coerceAtMost(rtf.length), (i + 24).coerceAtMost(rtf.length))
                    if (skipGroups.any { lookahead.startsWith("\\$it") || lookahead.startsWith("\\*\\$it") }) {
                        if (depth < skipDepth) skipDepth = depth
                    }
                    i++
                }
                '}' -> {
                    if (depth == skipDepth) skipDepth = Int.MAX_VALUE
                    depth--
                    i++
                }
                '\\' -> {
                    i++
                    if (i >= rtf.length) break
                    val next = rtf[i]
                    if (next == '\\' || next == '{' || next == '}') {
                        if (depth < skipDepth) out.append(next)
                        i++
                    } else if (next == '\'') {
                        if (i + 2 < rtf.length) {
                            val hex = rtf.substring(i + 1, i + 3).toIntOrNull(16)
                            if (hex != null && depth < skipDepth) out.append(hex.toChar())
                            i += 3
                        } else i++
                    } else {
                        val wordStart = i
                        while (i < rtf.length && rtf[i].isLetter()) i++
                        val word = rtf.substring(wordStart, i)
                        val numStart = i
                        if (i < rtf.length && (rtf[i] == '-' || rtf[i].isDigit())) {
                            i++
                            while (i < rtf.length && rtf[i].isDigit()) i++
                        }
                        val param = rtf.substring(numStart, i).toIntOrNull()
                        if (i < rtf.length && rtf[i] == ' ') i++

                        if (depth < skipDepth) {
                            when (word) {
                                "par", "line" -> out.append('\n')
                                "tab" -> out.append("    ")
                                "u" -> if (param != null) {
                                    val code = if (param < 0) param + 65536 else param
                                    out.append(code.toChar())
                                    if (i < rtf.length && rtf[i] == '?') i++
                                }
                            }
                        }
                    }
                }
                '\r', '\n' -> i++
                else -> {
                    if (depth < skipDepth) out.append(ch)
                    i++
                }
            }
        }
        return out.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }
    }

    private fun renderParagraphsToPdf(
        paragraphs: List<Pair<String, Boolean>>,
        outFile: File,
        onProgress: (Float) -> Unit
    ): Int {
        val pageW = 595
        val pageH = 842
        val margin = 46f
        val contentW = (pageW - margin * 2).toInt()
        val pdf = PdfDocument()

        val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#1E293B")
            textSize = 11.5f
        }
        val headingPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F172A")
            textSize = 15.5f
            typeface = Typeface.DEFAULT_BOLD
        }

        var pageNum = 1
        var page = pdf.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNum).create())
        var canvas = page.canvas
        canvas.drawColor(Color.WHITE)
        var cursorY = margin

        val total = paragraphs.size.coerceAtLeast(1)
        paragraphs.forEachIndexed { idx, (text, isHeading) ->
            onProgress(0.25f + (idx.toFloat() / total) * 0.7f)
            val safe = text.ifEmpty { " " }
            val paint = if (isHeading) headingPaint else bodyPaint
            val layout = StaticLayout.Builder.obtain(safe, 0, safe.length, paint, contentW)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(2f, 1.22f)
                .build()
            if (cursorY + layout.height > pageH - margin) {
                pdf.finishPage(page)
                pageNum++
                page = pdf.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNum).create())
                canvas = page.canvas
                canvas.drawColor(Color.WHITE)
                cursorY = margin
            }
            canvas.save()
            canvas.translate(margin, cursorY)
            layout.draw(canvas)
            canvas.restore()
            cursorY += layout.height + if (isHeading) 10f else 6f
        }
        pdf.finishPage(page)
        FileOutputStream(outFile).use { pdf.writeTo(it) }
        pdf.close()
        onProgress(1f)
        return pageNum
    }
}
