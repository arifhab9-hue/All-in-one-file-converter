package com.example.engine

import android.graphics.Bitmap
import android.graphics.Color
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.Inflater

/**
 * Pure-Kotlin Baseline TIFF decoder (supports Uncompressed, PackBits, and Deflate/ZIP compression
 * for 1-bit bilevel, 8-bit grayscale, 24-bit RGB, and 32-bit RGBA baseline TIFFs).
 */
object TiffDecoder {

    fun decode(file: File): Bitmap? {
        val bytes = file.readBytes()
        if (bytes.size < 8) return null
        val order = when {
            bytes[0] == 'I'.code.toByte() && bytes[1] == 'I'.code.toByte() -> ByteOrder.LITTLE_ENDIAN
            bytes[0] == 'M'.code.toByte() && bytes[1] == 'M'.code.toByte() -> ByteOrder.BIG_ENDIAN
            else -> return null
        }
        val buf = ByteBuffer.wrap(bytes).order(order)
        val magic = buf.getShort(2).toInt() and 0xFFFF
        if (magic != 42) return null

        val ifdOffset = buf.getInt(4)
        if (ifdOffset <= 0 || ifdOffset + 2 > bytes.size) return null

        val entryCount = buf.getShort(ifdOffset).toInt() and 0xFFFF
        var width = 0
        var height = 0
        var compression = 1 // 1=none, 8/32946=deflate, 32773=packbits
        var photometric = 2 // 0=WhiteIsZero, 1=BlackIsZero, 2=RGB
        var samplesPerPixel = 1
        var bitsPerSample = 8
        var stripOffsets = intArrayOf()
        var stripByteCounts = intArrayOf()
        var rowsPerStrip = Int.MAX_VALUE

        for (i in 0 until entryCount) {
            val pos = ifdOffset + 2 + i * 12
            if (pos + 12 > bytes.size) break
            val tag = buf.getShort(pos).toInt() and 0xFFFF
            val type = buf.getShort(pos + 2).toInt() and 0xFFFF
            val count = buf.getInt(pos + 4)
            when (tag) {
                256 -> width = readSingleInt(buf, pos + 8, type)
                257 -> height = readSingleInt(buf, pos + 8, type)
                258 -> bitsPerSample = readIntArray(buf, pos + 8, type, count).firstOrNull() ?: 8
                259 -> compression = readSingleInt(buf, pos + 8, type)
                262 -> photometric = readSingleInt(buf, pos + 8, type)
                273 -> stripOffsets = readIntArray(buf, pos + 8, type, count)
                277 -> samplesPerPixel = readSingleInt(buf, pos + 8, type)
                278 -> rowsPerStrip = readSingleInt(buf, pos + 8, type)
                279 -> stripByteCounts = readIntArray(buf, pos + 8, type, count)
            }
        }

        if (width <= 0 || height <= 0 || stripOffsets.isEmpty()) return null
        if (rowsPerStrip <= 0) rowsPerStrip = height

        val rawPixels = ByteArrayOutputStream()
        for (idx in stripOffsets.indices) {
            val off = stripOffsets[idx]
            val len = if (idx < stripByteCounts.size) stripByteCounts[idx] else (bytes.size - off)
            if (off < 0 || off >= bytes.size || len <= 0) continue
            val safeLen = len.coerceAtMost(bytes.size - off)
            val stripData = bytes.copyOfRange(off, off + safeLen)
            val decoded = when (compression) {
                1 -> stripData
                32773 -> decodePackBits(stripData)
                8, 32946 -> decodeDeflate(stripData)
                else -> throw UnsupportedOperationException(
                    "Unsupported TIFF compression codec ($compression). Please convert uncompressed/PackBits/Deflate TIFF or JPEG/PNG."
                )
            }
            rawPixels.write(decoded)
        }

        val data = rawPixels.toByteArray()
        val pixels = IntArray(width * height)
        if (bitsPerSample == 1 && samplesPerPixel == 1) {
            val rowBytes = (width + 7) / 8
            for (y in 0 until height) {
                for (x in 0 until width) {
                    val bIdx = y * rowBytes + (x / 8)
                    val bit = if (bIdx < data.size) (data[bIdx].toInt() shr (7 - (x % 8))) and 1 else 0
                    val isWhite = if (photometric == 0) bit == 0 else bit == 1
                    pixels[y * width + x] = if (isWhite) Color.WHITE else Color.BLACK
                }
            }
        } else if (samplesPerPixel == 1) {
            for (i in 0 until minOf(width * height, data.size)) {
                var v = data[i].toInt() and 0xFF
                if (photometric == 0) v = 255 - v
                pixels[i] = Color.rgb(v, v, v)
            }
        } else if (samplesPerPixel >= 3) {
            for (i in 0 until width * height) {
                val base = i * samplesPerPixel
                if (base + 2 >= data.size) break
                val r = data[base].toInt() and 0xFF
                val g = data[base + 1].toInt() and 0xFF
                val b = data[base + 2].toInt() and 0xFF
                val a = if (samplesPerPixel >= 4 && base + 3 < data.size) data[base + 3].toInt() and 0xFF else 255
                pixels[i] = Color.argb(a, r, g, b)
            }
        }

        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        bmp.setPixels(pixels, 0, width, 0, 0, width, height)
        return bmp
    }

    private fun readSingleInt(buf: ByteBuffer, valueOffset: Int, type: Int): Int {
        return when (type) {
            3 -> buf.getShort(valueOffset).toInt() and 0xFFFF
            4 -> buf.getInt(valueOffset)
            1 -> buf.get(valueOffset).toInt() and 0xFF
            else -> buf.getInt(valueOffset)
        }
    }

    private fun readIntArray(buf: ByteBuffer, valueOffset: Int, type: Int, count: Int): IntArray {
        val typeSize = when (type) {
            1 -> 1
            3 -> 2
            4 -> 4
            else -> 4
        }
        if (count <= 0) return intArrayOf()
        val totalBytes = count * typeSize
        val start = if (totalBytes <= 4) valueOffset else buf.getInt(valueOffset)
        val out = IntArray(count)
        for (i in 0 until count) {
            val pos = start + i * typeSize
            if (pos + typeSize > buf.capacity()) break
            out[i] = when (type) {
                1 -> buf.get(pos).toInt() and 0xFF
                3 -> buf.getShort(pos).toInt() and 0xFFFF
                else -> buf.getInt(pos)
            }
        }
        return out
    }

    private fun decodePackBits(input: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        var i = 0
        while (i < input.size) {
            val n = input[i++].toInt()
            if (n in 0..127) {
                val len = (n + 1).coerceAtMost(input.size - i)
                out.write(input, i, len)
                i += len
            } else if (n in -127..-1) {
                if (i < input.size) {
                    val b = input[i++]
                    repeat(-n + 1) { out.write(b.toInt()) }
                }
            }
        }
        return out.toByteArray()
    }

    private fun decodeDeflate(input: ByteArray): ByteArray {
        val inflater = Inflater()
        inflater.setInput(input)
        val out = ByteArrayOutputStream()
        val buf = ByteArray(4096)
        while (!inflater.finished()) {
            val count = inflater.inflate(buf)
            if (count == 0) break
            out.write(buf, 0, count)
        }
        inflater.end()
        return out.toByteArray()
    }
}
