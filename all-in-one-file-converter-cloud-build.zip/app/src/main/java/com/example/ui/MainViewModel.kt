package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.i18n.AppLanguage
import com.example.core.model.ConversionOptions
import com.example.core.model.ConversionOutputFile
import com.example.core.model.ConversionResult
import com.example.core.model.PdfAnnotationItem
import com.example.core.model.PdfMetadataInfo
import com.example.core.model.ToolCategory
import com.example.core.model.ToolId
import com.example.core.model.WorkspaceFile
import com.example.data.local.AppDatabase
import com.example.data.local.ConversionHistoryEntity
import com.example.data.local.ConversionHistoryRepository
import com.example.data.local.UserPreferencesRepository
import com.example.data.local.UserSettings
import com.example.engine.ConversionDispatcher
import com.example.engine.FileStorageHelper
import com.example.engine.OfficeExcelEngine
import com.example.engine.OptionalBackendClient
import com.example.engine.PdfToolsEngine
import com.example.ui.theme.ThemePreference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

sealed interface ProcessingUiState {
    data object Idle : ProcessingUiState
    data class Running(val progress: Float, val message: String) : ProcessingUiState
    data class Success(val result: ConversionResult) : ProcessingUiState
    data class Error(val message: String) : ProcessingUiState
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val prefsRepo = UserPreferencesRepository(application)
    private val historyRepo = ConversionHistoryRepository(
        AppDatabase.getInstance(application).conversionHistoryDao()
    )

    val settings: StateFlow<UserSettings> = prefsRepo.settings.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        UserSettings()
    )

    val history: StateFlow<List<ConversionHistoryEntity>> = historyRepo.history.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    // Dashboard search & category filter
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow<ToolCategory?>(null)
    val selectedCategory = _selectedCategory.asStateFlow()

    // Active Tool Workspace
    private val _activeTool = MutableStateFlow<ToolId?>(null)
    val activeTool = _activeTool.asStateFlow()

    private val _selectedFiles = MutableStateFlow<List<WorkspaceFile>>(emptyList())
    val selectedFiles = _selectedFiles.asStateFlow()

    private val _options = MutableStateFlow(ConversionOptions())
    val options = _options.asStateFlow()

    private val _detectedExcelSheets = MutableStateFlow<List<String>>(emptyList())
    val detectedExcelSheets = _detectedExcelSheets.asStateFlow()

    private val _inspectedMetadata = MutableStateFlow<PdfMetadataInfo?>(null)
    val inspectedMetadata = _inspectedMetadata.asStateFlow()

    private val _processingState = MutableStateFlow<ProcessingUiState>(ProcessingUiState.Idle)
    val processingState = _processingState.asStateFlow()

    private val _useBackendServer = MutableStateFlow(false)
    val useBackendServer = _useBackendServer.asStateFlow()

    // Global Workspace File Manager
    private val _workspaceLibrary = MutableStateFlow<List<WorkspaceFile>>(emptyList())
    val workspaceLibrary = _workspaceLibrary.asStateFlow()

    // PDF Editor State
    private val _editorPdfFile = MutableStateFlow<WorkspaceFile?>(null)
    val editorPdfFile = _editorPdfFile.asStateFlow()

    private val _editorAnnotations = MutableStateFlow<List<PdfAnnotationItem>>(emptyList())
    val editorAnnotations = _editorAnnotations.asStateFlow()

    private val _backendTestStatus = MutableStateFlow<String?>(null)
    val backendTestStatus = _backendTestStatus.asStateFlow()

    fun setSearchQuery(q: String) {
        _searchQuery.value = q
    }

    fun setSelectedCategory(cat: ToolCategory?) {
        _selectedCategory.value = cat
    }

    fun setLanguage(lang: AppLanguage) {
        viewModelScope.launch { prefsRepo.setLanguage(lang) }
    }

    fun setTheme(theme: ThemePreference) {
        viewModelScope.launch { prefsRepo.setTheme(theme) }
    }

    fun setAutoOcr(enabled: Boolean) {
        viewModelScope.launch { prefsRepo.setAutoOcr(enabled) }
        _options.update { it.copy(enableOcr = enabled) }
    }

    fun setDefaultDpi(dpi: Int) {
        viewModelScope.launch { prefsRepo.setDefaultDpi(dpi) }
        _options.update { it.copy(dpi = dpi) }
    }

    fun setBackendUrl(url: String) {
        viewModelScope.launch { prefsRepo.setBackendUrl(url) }
    }

    fun setUseBackendServer(enabled: Boolean) {
        _useBackendServer.value = enabled
    }

    fun testBackendConnection(url: String) {
        viewModelScope.launch {
            _backendTestStatus.value = "Testing..."
            val res = withContext(Dispatchers.IO) { OptionalBackendClient.testHealth(url) }
            _backendTestStatus.value = res.fold(
                onSuccess = { it },
                onFailure = { "Error: ${it.message ?: "Connection failed"}" }
            )
        }
    }

    fun openTool(toolId: ToolId, preloadedFiles: List<WorkspaceFile> = emptyList()) {
        _activeTool.value = toolId
        _selectedFiles.value = preloadedFiles
        _processingState.value = ProcessingUiState.Idle
        _detectedExcelSheets.value = emptyList()
        _inspectedMetadata.value = null
        val curSettings = settings.value
        _options.value = ConversionOptions(
            dpi = curSettings.defaultDpi,
            enableOcr = curSettings.autoOcr
        )
        if (preloadedFiles.isNotEmpty()) {
            inspectPickedFiles(toolId, preloadedFiles)
        }
    }

    fun addUrisToActiveTool(uris: List<Uri>) {
        val tool = _activeTool.value ?: return
        viewModelScope.launch {
            try {
                val copied = withContext(Dispatchers.IO) {
                    uris.map { FileStorageHelper.copyUriToWorkspace(getApplication(), it) }
                }
                val isSingle = tool.pickerMode.name.startsWith("SINGLE")
                val updated = if (isSingle) listOf(copied.first()) else (_selectedFiles.value + copied)
                _selectedFiles.value = updated
                _workspaceLibrary.update { lib -> (copied + lib).distinctBy { it.id } }
                _processingState.value = ProcessingUiState.Idle
                inspectPickedFiles(tool, updated)
            } catch (e: Exception) {
                _processingState.value = ProcessingUiState.Error(e.message ?: "Failed to load selected file(s)")
            }
        }
    }

    private fun inspectPickedFiles(tool: ToolId, files: List<WorkspaceFile>) {
        val first = files.firstOrNull() ?: return
        viewModelScope.launch(Dispatchers.IO) {
            if (tool.category.name == "EXCEL_CONVERTER" || tool == ToolId.XLSX_TO_CSV) {
                val sheets = OfficeExcelEngine.inspectSheetNames(first.localFile)
                _detectedExcelSheets.value = sheets
                if (sheets.isNotEmpty()) {
                    _options.update { it.copy(selectedExcelSheets = sheets.toSet()) }
                }
            }
            if (tool == ToolId.PDF_METADATA) {
                try {
                    val meta = PdfToolsEngine.inspectMetadata(getApplication(), first.localFile)
                    _inspectedMetadata.value = meta
                    _options.update {
                        it.copy(
                            customMetadataTitle = meta.title,
                            customMetadataAuthor = meta.author,
                            customMetadataSubject = meta.subject,
                            customMetadataKeywords = meta.keywords
                        )
                    }
                } catch (_: Exception) {
                }
            }
        }
    }

    fun removeSelectedFile(id: String) {
        _selectedFiles.update { list -> list.filterNot { it.id == id } }
    }

    fun moveSelectedFile(index: Int, delta: Int) {
        _selectedFiles.update { list ->
            val target = index + delta
            if (index !in list.indices || target !in list.indices) return@update list
            val mutable = list.toMutableList()
            val item = mutable.removeAt(index)
            mutable.add(target, item)
            mutable
        }
    }

    fun updateOptions(transform: (ConversionOptions) -> ConversionOptions) {
        _options.update(transform)
    }

    fun runActiveTool() {
        val tool = _activeTool.value ?: return
        val files = _selectedFiles.value
        if (files.isEmpty()) {
            _processingState.value = ProcessingUiState.Error("Select at least one file first.")
            return
        }
        viewModelScope.launch {
            _processingState.value = ProcessingUiState.Running(0.05f, tool.title.en)
            try {
                val result = withContext(Dispatchers.IO) {
                    ConversionDispatcher.execute(
                        context = getApplication(),
                        toolId = tool,
                        files = files,
                        options = _options.value,
                        optionalBackendUrl = settings.value.optionalBackendUrl,
                        useServerIfConfigured = _useBackendServer.value,
                        onProgress = { p ->
                            _processingState.value = ProcessingUiState.Running(p, "${(p * 100).toInt()}%")
                        }
                    )
                }
                _processingState.value = ProcessingUiState.Success(result)

                // Add generated outputs to File Manager workspace & Room History
                val outWorkspace = result.outputFiles.map { out ->
                    WorkspaceFile(
                        id = UUID.randomUUID().toString(),
                        name = out.name,
                        localFile = out.file,
                        mimeType = out.mimeType,
                        sizeBytes = out.sizeBytes
                    )
                }
                if (outWorkspace.isNotEmpty()) {
                    _workspaceLibrary.update { lib -> outWorkspace + lib }
                }

                val primaryOut = result.outputFiles.firstOrNull()
                if (primaryOut != null) {
                    historyRepo.record(
                        ConversionHistoryEntity(
                            toolIdName = tool.name,
                            inputNames = files.joinToString(", ") { it.name },
                            outputName = primaryOut.name,
                            outputPath = primaryOut.file.absolutePath,
                            outputMimeType = primaryOut.mimeType,
                            originalBytes = result.originalTotalBytes,
                            outputBytes = result.outputTotalBytes,
                            pageCount = result.pageCount
                        )
                    )
                }
            } catch (e: OutOfMemoryError) {
                _processingState.value = ProcessingUiState.Error(
                    "File is too large for device memory. Try splitting the PDF or lowering DPI/Quality."
                )
            } catch (e: Exception) {
                _processingState.value = ProcessingUiState.Error(
                    e.message ?: "Conversion failed. Please verify the file is valid and uncorrupted."
                )
            }
        }
    }

    // File Manager Operations
    fun uploadToWorkspace(uris: List<Uri>) {
        viewModelScope.launch {
            try {
                val added = withContext(Dispatchers.IO) {
                    uris.map { FileStorageHelper.copyUriToWorkspace(getApplication(), it) }
                }
                _workspaceLibrary.update { added + it }
            } catch (_: Exception) {
            }
        }
    }

    fun renameWorkspaceFile(id: String, newName: String) {
        val clean = FileStorageHelper.sanitizeFileName(newName)
        if (clean.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            _workspaceLibrary.update { list ->
                list.map { wf ->
                    if (wf.id == id) {
                        val dest = FileStorageHelper.uniqueFile(wf.localFile.parentFile!!, clean)
                        val renamed = wf.localFile.renameTo(dest)
                        if (renamed) wf.copy(name = dest.name, localFile = dest) else wf
                    } else wf
                }
            }
        }
    }

    fun deleteWorkspaceFile(id: String) {
        _workspaceLibrary.update { list ->
            val target = list.find { it.id == id }
            target?.localFile?.delete()
            list.filterNot { it.id == id }
        }
    }

    suspend fun createZipFromWorkspaceIds(ids: Set<String>): File? = withContext(Dispatchers.IO) {
        val targets = _workspaceLibrary.value.filter { it.id in ids }.map { it.localFile }
        if (targets.isEmpty()) return@withContext null
        val zipFile = FileStorageHelper.createOutputFile(getApplication(), "workspace_bundle_${targets.size}.zip")
        FileStorageHelper.createZipArchive(targets, zipFile)
    }

    fun batchConvertWorkspaceFiles(
        ids: Set<String>,
        targetTool: ToolId,
        onComplete: (ConversionResult?) -> Unit
    ) {
        val targets = _workspaceLibrary.value.filter { it.id in ids }
        if (targets.isEmpty()) return
        viewModelScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    if (targetTool == ToolId.IMAGES_TO_PDF || targetTool == ToolId.MERGE_PDF || targetTool == ToolId.WORD_MERGE || targetTool == ToolId.COMPRESS_JPG || targetTool == ToolId.COMPRESS_PNG) {
                        ConversionDispatcher.execute(getApplication(), targetTool, targets, _options.value) {}
                    } else {
                        val outs = mutableListOf<ConversionOutputFile>()
                        var totalIn = 0L
                        var totalPages = 0
                        for (wf in targets) {
                            val r = ConversionDispatcher.execute(getApplication(), targetTool, listOf(wf), _options.value) {}
                            outs.addAll(r.outputFiles)
                            totalIn += r.originalTotalBytes
                            totalPages += r.pageCount
                        }
                        val zip = if (outs.size > 1) {
                            val z = FileStorageHelper.createOutputFile(getApplication(), "batch_${targetTool.name.lowercase()}.zip")
                            FileStorageHelper.createZipArchive(outs.map { it.file }, z)
                        } else null
                        ConversionResult(
                            toolId = targetTool,
                            outputFiles = outs,
                            zipFile = zip,
                            originalTotalBytes = totalIn,
                            outputTotalBytes = outs.sumOf { it.sizeBytes },
                            pageCount = totalPages
                        )
                    }
                }
                val newEntries = result.outputFiles.map {
                    WorkspaceFile(UUID.randomUUID().toString(), it.name, it.file, it.mimeType, it.sizeBytes)
                }
                _workspaceLibrary.update { newEntries + it }
                onComplete(result)
            } catch (_: Exception) {
                onComplete(null)
            }
        }
    }

    fun deleteHistoryItem(id: Long) {
        viewModelScope.launch { historyRepo.delete(id) }
    }

    fun clearHistory() {
        viewModelScope.launch { historyRepo.clearAll() }
    }

    // PDF Editor Actions
    fun loadPdfIntoEditor(uri: Uri) {
        viewModelScope.launch {
            try {
                val wf = withContext(Dispatchers.IO) {
                    FileStorageHelper.copyUriToWorkspace(getApplication(), uri)
                }
                _editorPdfFile.value = wf
                _editorAnnotations.value = emptyList()
                _workspaceLibrary.update { listOf(wf) + it }
            } catch (_: Exception) {
            }
        }
    }

    fun loadWorkspacePdfIntoEditor(wf: WorkspaceFile) {
        _editorPdfFile.value = wf
        _editorAnnotations.value = emptyList()
    }

    fun addEditorAnnotation(item: PdfAnnotationItem) {
        _editorAnnotations.update { it + item }
    }

    fun undoLastEditorAnnotation(pageIndex: Int) {
        _editorAnnotations.update { list ->
            val idx = list.indexOfLast { it.pageIndex == pageIndex }
            if (idx >= 0) list.toMutableList().apply { removeAt(idx) } else list
        }
    }

    fun exportEditedPdf(
        watermarkText: String?,
        addPageNumbers: Boolean,
        onDone: (Result<File>) -> Unit
    ) {
        val pdf = _editorPdfFile.value ?: return
        viewModelScope.launch {
            try {
                val outFile = withContext(Dispatchers.IO) {
                    PdfToolsEngine.applyEditorEdits(
                        context = getApplication(),
                        sourcePdf = pdf.localFile,
                        annotations = _editorAnnotations.value,
                        watermarkText = watermarkText,
                        addPageNumbers = addPageNumbers,
                        onProgress = {}
                    )
                }
                val wf = WorkspaceFile(
                    UUID.randomUUID().toString(),
                    outFile.name,
                    outFile,
                    "application/pdf",
                    outFile.length()
                )
                _workspaceLibrary.update { listOf(wf) + it }
                historyRepo.record(
                    ConversionHistoryEntity(
                        toolIdName = ToolId.PDF_EDITOR_SUITE.name,
                        inputNames = pdf.name,
                        outputName = outFile.name,
                        outputPath = outFile.absolutePath,
                        outputMimeType = "application/pdf",
                        originalBytes = pdf.sizeBytes,
                        outputBytes = outFile.length(),
                        pageCount = PdfToolsEngine.getPageCount(getApplication(), outFile)
                    )
                )
                onDone(Result.success(outFile))
            } catch (e: Exception) {
                onDone(Result.failure(e))
            }
        }
    }
}
