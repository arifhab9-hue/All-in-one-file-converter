package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.NavigateBefore
import androidx.compose.material.icons.automirrored.filled.NavigateNext
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.engine.FileStorageHelper
import com.example.engine.ImagePdfEngine
import com.example.engine.OfficeExcelEngine
import com.example.engine.OfficePowerPointEngine
import com.example.engine.OfficeWordEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun FilePreviewDialog(
    file: File,
    mimeType: String,
    textOverride: String? = null,
    onDismiss: () -> Unit
) {
    val ext = file.extension.lowercase()
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 620.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = file.name,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = FileStorageHelper.formatSize(file.length()),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_preview_button")
                    ) {
                        Icon(Icons.Filled.Close, contentDescription = "Close preview")
                    }
                }

                Spacer(Modifier.height(10.dp))

                when {
                    textOverride != null -> {
                        TextPreviewBox(textOverride)
                    }
                    ext == "pdf" || mimeType == "application/pdf" -> {
                        PdfPagesPreview(file)
                    }
                    ext in listOf("jpg", "jpeg", "png", "webp", "bmp", "tif", "tiff") || mimeType.startsWith("image/") -> {
                        if (ext == "tif" || ext == "tiff") {
                            var bmp by remember(file) { mutableStateOf<Bitmap?>(null) }
                            LaunchedEffect(file) {
                                bmp = withContext(Dispatchers.IO) {
                                    runCatching { ImagePdfEngine.decodeImageSafe(file, 1400) }.getOrNull()
                                }
                            }
                            DisposableEffect(bmp) {
                                onDispose { bmp?.recycle() }
                            }
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(380.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant),
                                contentAlignment = Alignment.Center
                            ) {
                                val loaded = bmp
                                if (loaded != null) {
                                    Image(
                                        bitmap = loaded.asImageBitmap(),
                                        contentDescription = file.name,
                                        contentScale = ContentScale.Fit,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                } else {
                                    Text("Decoding TIFF...", style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        } else {
                            AsyncImage(
                                model = file,
                                contentDescription = file.name,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(380.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                            )
                        }
                    }
                    else -> {
                        var previewText by remember(file) { mutableStateOf("Loading preview...") }
                        LaunchedEffect(file) {
                            previewText = withContext(Dispatchers.IO) {
                                runCatching {
                                    when (ext) {
                                        "docx", "doc" -> OfficeWordEngine.parseWordFile(file).toPreviewText()
                                        "xlsx", "xls", "csv", "ods" -> {
                                            OfficeExcelEngine.parseWorkbook(file).joinToString("\n\n") { sheet ->
                                                "=== ${sheet.name} ===\n" + sheet.rows.take(35).joinToString("\n") { it.joinToString(" | ") }
                                            }
                                        }
                                        "pptx", "ppt", "odp" -> {
                                            OfficePowerPointEngine.parsePresentation(file).joinToString("\n\n") { s ->
                                                "Slide ${s.index}: ${s.title}\n" + s.bodyLines.joinToString("\n") { "• $it" }
                                            }
                                        }
                                        else -> file.readText(Charsets.UTF_8).take(8000)
                                    }
                                }.getOrElse { "Preview unavailable: ${it.message}" }
                            }
                        }
                        TextPreviewBox(previewText)
                    }
                }

                Spacer(Modifier.height(10.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) {
                        Text("Close")
                    }
                }
            }
        }
    }
}

@Composable
private fun TextPreviewBox(text: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(380.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
    ) {
        Text(
            text = text.ifBlank { "(Empty document)" },
            style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun PdfPagesPreview(file: File) {
    var pageIndex by remember(file) { mutableIntStateOf(0) }
    var pageCount by remember(file) { mutableIntStateOf(1) }
    var rendered by remember(file) { mutableStateOf<Bitmap?>(null) }
    var errorMsg by remember(file) { mutableStateOf<String?>(null) }

    LaunchedEffect(file, pageIndex) {
        val result = withContext(Dispatchers.IO) {
            runCatching {
                val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                val renderer = PdfRenderer(pfd)
                try {
                    val count = renderer.pageCount
                    val safeIdx = pageIndex.coerceIn(0, (count - 1).coerceAtLeast(0))
                    val bmp = renderer.openPage(safeIdx).use { p ->
                        val scale = (900f / p.width).coerceIn(1f, 2.5f)
                        val b = Bitmap.createBitmap((p.width * scale).toInt(), (p.height * scale).toInt(), Bitmap.Config.ARGB_8888)
                        Canvas(b).drawColor(Color.WHITE)
                        p.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        b
                    }
                    count to bmp
                } finally {
                    renderer.close()
                    pfd.close()
                }
            }
        }
        result.onSuccess { (cnt, bmp) ->
            pageCount = cnt
            rendered?.recycle()
            rendered = bmp
            errorMsg = null
        }.onFailure {
            errorMsg = it.message ?: "Cannot preview PDF (may be password protected)"
        }
    }

    DisposableEffect(Unit) {
        onDispose { rendered?.recycle() }
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(350.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            val bmp = rendered
            if (errorMsg != null) {
                Text(errorMsg!!, modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error)
            } else if (bmp != null) {
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = "PDF Page ${pageIndex + 1}",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { if (pageIndex > 0) pageIndex-- }, enabled = pageIndex > 0) {
                Icon(Icons.AutoMirrored.Filled.NavigateBefore, contentDescription = "Previous page")
            }
            Text(
                text = "Page ${pageIndex + 1} / $pageCount",
                style = MaterialTheme.typography.labelLarge
            )
            IconButton(onClick = { if (pageIndex < pageCount - 1) pageIndex++ }, enabled = pageIndex < pageCount - 1) {
                Icon(Icons.AutoMirrored.Filled.NavigateNext, contentDescription = "Next page")
            }
        }
    }
}
