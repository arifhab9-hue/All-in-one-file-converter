package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatchPrediction
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Preview
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.AppStrings
import com.example.core.model.ConversionResult
import com.example.core.model.ToolId
import com.example.core.model.WorkspaceFile
import com.example.data.local.ConversionHistoryEntity
import com.example.engine.FileStorageHelper
import com.example.ui.components.FilePreviewDialog
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun FileManagerScreen(
    language: AppLanguage,
    workspaceFiles: List<WorkspaceFile>,
    historyItems: List<ConversionHistoryEntity>,
    onUploadUris: (List<Uri>) -> Unit,
    onRenameFile: (String, String) -> Unit,
    onDeleteFile: (String) -> Unit,
    onCreateZip: suspend (Set<String>) -> File?,
    onBatchConvert: (Set<String>, ToolId, (ConversionResult?) -> Unit) -> Unit,
    onDeleteHistory: (Long) -> Unit,
    onClearHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var previewFile by remember { mutableStateOf<Pair<File, String>?>(null) }
    var renameTarget by remember { mutableStateOf<WorkspaceFile?>(null) }
    var renameText by remember { mutableStateOf("") }
    var showBatchDialog by remember { mutableStateOf(false) }
    var pendingSave by remember { mutableStateOf<File?>(null) }

    val multiUploadLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) onUploadUris(uris)
    }
    val saveDocLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
        val src = pendingSave
        if (uri != null && src != null && src.exists()) {
            runCatching { FileStorageHelper.copyFileToUri(context, src, uri) }
                .onSuccess { Toast.makeText(context, "Saved!", Toast.LENGTH_SHORT).show() }
        }
        pendingSave = null
    }

    Column(modifier = modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = selectedTab) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("${AppStrings.workspaceTab.get(language)} (${workspaceFiles.size})") }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("${AppStrings.historyTab.get(language)} (${historyItems.size})") }
            )
        }

        if (selectedTab == 0) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = { multiUploadLauncher.launch(arrayOf("*/*")) },
                    modifier = Modifier.testTag("workspace_upload_button")
                ) {
                    Icon(Icons.Filled.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(AppStrings.quickUpload.get(language))
                }
                if (selectedIds.isNotEmpty()) {
                    OutlinedButton(onClick = {
                        scope.launch {
                            val zip = onCreateZip(selectedIds)
                            if (zip != null) {
                                pendingSave = zip
                                saveDocLauncher.launch(zip.name)
                            }
                        }
                    }) {
                        Icon(Icons.Filled.FolderZip, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("ZIP (${selectedIds.size})")
                    }
                    OutlinedButton(onClick = { showBatchDialog = true }) {
                        Icon(Icons.Filled.BatchPrediction, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(AppStrings.batchConvert.get(language))
                    }
                }
            }

            if (workspaceFiles.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(
                        text = AppStrings.emptyWorkspace.get(language),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(workspaceFiles, key = { it.id }) { wf ->
                        val checked = wf.id in selectedIds
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surface,
                            tonalElevation = 1.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedIds = if (checked) selectedIds - wf.id else selectedIds + wf.id
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = checked,
                                    onCheckedChange = { isChecked ->
                                        selectedIds = if (isChecked) selectedIds + wf.id else selectedIds - wf.id
                                    }
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(wf.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(
                                        "${FileStorageHelper.formatSize(wf.sizeBytes)} • ${wf.localFile.extension.uppercase()}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(onClick = { previewFile = wf.localFile to wf.mimeType }) {
                                    Icon(Icons.Filled.Preview, contentDescription = "Preview")
                                }
                                IconButton(onClick = {
                                    renameTarget = wf
                                    renameText = wf.name
                                }) {
                                    Icon(Icons.Filled.DriveFileRenameOutline, contentDescription = "Rename")
                                }
                                IconButton(onClick = {
                                    pendingSave = wf.localFile
                                    saveDocLauncher.launch(wf.name)
                                }) {
                                    Icon(Icons.Filled.Download, contentDescription = "Save")
                                }
                                IconButton(onClick = { FileStorageHelper.shareFile(context, wf.localFile, wf.mimeType) }) {
                                    Icon(Icons.Filled.Share, contentDescription = "Share")
                                }
                                IconButton(onClick = {
                                    selectedIds = selectedIds - wf.id
                                    onDeleteFile(wf.id)
                                }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Delete")
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (historyItems.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onClearHistory) {
                        Text(AppStrings.clearHistory.get(language))
                    }
                }
            }
            if (historyItems.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.History, contentDescription = null, modifier = Modifier.size(44.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.height(8.dp))
                        Text(AppStrings.emptyHistory.get(language), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                val fmt = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()) }
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(historyItems, key = { it.id }) { item ->
                        val toolTitle = runCatching { ToolId.valueOf(item.toolIdName).title.get(language) }
                            .getOrDefault(item.toolIdName)
                        val outFile = File(item.outputPath)
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surface,
                            tonalElevation = 1.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(toolTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text(
                                        "${item.inputNames} → ${item.outputName}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        "${FileStorageHelper.formatSize(item.originalBytes)} → ${FileStorageHelper.formatSize(item.outputBytes)} • ${fmt.format(Date(item.timestamp))}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (outFile.exists()) {
                                    IconButton(onClick = { previewFile = outFile to item.outputMimeType }) {
                                        Icon(Icons.Filled.Preview, contentDescription = "Preview")
                                    }
                                    IconButton(onClick = { FileStorageHelper.shareFile(context, outFile, item.outputMimeType) }) {
                                        Icon(Icons.Filled.Share, contentDescription = "Share")
                                    }
                                }
                                IconButton(onClick = { onDeleteHistory(item.id) }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Delete history")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    previewFile?.let { (file, mime) ->
        FilePreviewDialog(file = file, mimeType = mime, onDismiss = { previewFile = null })
    }

    renameTarget?.let { wf ->
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text(AppStrings.rename.get(language)) },
            text = {
                OutlinedTextField(
                    value = renameText,
                    onValueChange = { renameText = it },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    onRenameFile(wf.id, renameText)
                    renameTarget = null
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("Cancel") } }
        )
    }

    if (showBatchDialog) {
        val batchTools = listOf(
            ToolId.IMAGES_TO_PDF,
            ToolId.MERGE_PDF,
            ToolId.PDF_TO_JPG,
            ToolId.PDF_TO_TXT,
            ToolId.COMPRESS_JPG,
            ToolId.WORD_MERGE
        )
        AlertDialog(
            onDismissRequest = { showBatchDialog = false },
            title = { Text(AppStrings.batchConvert.get(language)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    batchTools.forEach { bt ->
                        OutlinedButton(
                            onClick = {
                                showBatchDialog = false
                                onBatchConvert(selectedIds, bt) { res ->
                                    val msg = if (res != null) {
                                        "Batch complete: ${res.outputFiles.size} output(s)"
                                    } else {
                                        "Batch conversion failed — check selected file formats"
                                    }
                                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(bt.title.get(language))
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showBatchDialog = false }) { Text("Close") } }
        )
    }
}
