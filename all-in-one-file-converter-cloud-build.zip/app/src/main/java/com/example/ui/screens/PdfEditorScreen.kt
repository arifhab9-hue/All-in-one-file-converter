package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Color as AndroidColor
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.NavigateBefore
import androidx.compose.material.icons.automirrored.filled.NavigateNext
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.BorderColor
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.FormatStrikethrough
import androidx.compose.material.icons.filled.FormatUnderlined
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.i18n.AppLanguage
import com.example.core.model.EditorToolMode
import com.example.core.model.MarkupKind
import com.example.core.model.PdfAnnotationItem
import com.example.core.model.WorkspaceFile
import com.example.engine.FileStorageHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@Composable
fun PdfEditorScreen(
    language: AppLanguage,
    pdfFile: WorkspaceFile?,
    annotations: List<PdfAnnotationItem>,
    onPickPdfUri: (Uri) -> Unit,
    onAddAnnotation: (PdfAnnotationItem) -> Unit,
    onUndoPage: (Int) -> Unit,
    onExportPdf: (watermark: String?, addPageNumbers: Boolean, onDone: (Result<File>) -> Unit) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var mode by remember { mutableStateOf(EditorToolMode.DRAW) }
    var selectedColor by remember { mutableStateOf(Color(0xFF156EFC)) }
    var pageIndex by remember { mutableIntStateOf(0) }
    var pageCount by remember { mutableIntStateOf(1) }
    var pageBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var pageAspect by remember { mutableFloatStateOf(0.707f) }

    var pendingTapNorm by remember { mutableStateOf<Pair<Float, Float>?>(null) }
    var showTextDialog by remember { mutableStateOf(false) }
    var textDialogInput by remember { mutableStateOf("") }
    var textFontSize by remember { mutableFloatStateOf(14f) }

    var showDigitalSealDialog by remember { mutableStateOf(false) }
    var signerName by remember { mutableStateOf("Authorized Signer") }
    var signReason by remember { mutableStateOf("Document Approved") }

    var showWatermarkDialog by remember { mutableStateOf(false) }
    var watermarkEnabled by remember { mutableStateOf(false) }
    var watermarkText by remember { mutableStateOf("CONFIDENTIAL") }
    var addPageNumbers by remember { mutableStateOf(false) }

    var showCropDialog by remember { mutableStateOf(false) }
    var cropMargin by remember { mutableFloatStateOf(0.06f) }

    var pendingImageFile by remember { mutableStateOf<File?>(null) }
    var exportedFile by remember { mutableStateOf<File?>(null) }

    val activeStroke = remember { mutableStateListOf<Pair<Float, Float>>() }
    var dragStartNorm by remember { mutableStateOf<Pair<Float, Float>?>(null) }
    var dragEndNorm by remember { mutableStateOf<Pair<Float, Float>?>(null) }

    val pdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            pageIndex = 0
            exportedFile = null
            onPickPdfUri(uri)
        }
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            runCatching { FileStorageHelper.copyUriToWorkspace(context, uri).localFile }
                .onSuccess {
                    pendingImageFile = it
                    mode = EditorToolMode.ADD_IMAGE
                    Toast.makeText(context, "Tap on the PDF page to place image", Toast.LENGTH_SHORT).show()
                }
        }
    }

    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val src = exportedFile
        if (uri != null && src != null && src.exists()) {
            runCatching { FileStorageHelper.copyFileToUri(context, src, uri) }
                .onSuccess { Toast.makeText(context, "Edited PDF saved!", Toast.LENGTH_SHORT).show() }
        }
    }

    LaunchedEffect(pdfFile, pageIndex) {
        if (pdfFile == null) return@LaunchedEffect
        val loaded = withContext(Dispatchers.IO) {
            runCatching {
                val pfd = ParcelFileDescriptor.open(pdfFile.localFile, ParcelFileDescriptor.MODE_READ_ONLY)
                val renderer = PdfRenderer(pfd)
                try {
                    val count = renderer.pageCount
                    val safeIdx = pageIndex.coerceIn(0, (count - 1).coerceAtLeast(0))
                    val bmp = renderer.openPage(safeIdx).use { p ->
                        val w = 1100
                        val h = (1100f * p.height / p.width).toInt().coerceIn(300, 1800)
                        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        AndroidCanvas(b).drawColor(AndroidColor.WHITE)
                        p.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        b
                    }
                    Triple(count, bmp, bmp.width.toFloat() / bmp.height.toFloat())
                } finally {
                    renderer.close()
                    pfd.close()
                }
            }.getOrNull()
        }
        if (loaded != null) {
            pageCount = loaded.first
            pageBitmap?.recycle()
            pageBitmap = loaded.second
            pageAspect = loaded.third
        }
    }

    DisposableEffect(Unit) {
        onDispose { pageBitmap?.recycle() }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Header bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (language == AppLanguage.BN) "ইন্টারেক্টিভ PDF এডিটর" else "Interactive PDF Editor",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = pdfFile?.name ?: if (language == AppLanguage.BN) "এডিট করতে একটি PDF খুলুন" else "Open a PDF to annotate, sign & edit",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(
                    onClick = { pdfPicker.launch(arrayOf("application/pdf")) },
                    modifier = Modifier.testTag("editor_open_pdf_button")
                ) {
                    Icon(Icons.Filled.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(if (language == AppLanguage.BN) "PDF খুলুন" else "Open")
                }
                Button(
                    onClick = {
                        onExportPdf(if (watermarkEnabled) watermarkText else null, addPageNumbers) { res ->
                            res.onSuccess { file ->
                                exportedFile = file
                                Toast.makeText(context, "Exported: ${file.name}", Toast.LENGTH_SHORT).show()
                            }.onFailure {
                                Toast.makeText(context, it.message ?: "Export error", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    enabled = pdfFile != null,
                    modifier = Modifier.testTag("editor_export_button")
                ) {
                    Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(if (language == AppLanguage.BN) "এক্সপোর্ট" else "Export")
                }
            }
        }

        // Exported Quick Actions
        exportedFile?.let { file ->
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${file.name} (${FileStorageHelper.formatSize(file.length())})",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { saveLauncher.launch(file.name) }) {
                        Icon(Icons.Filled.Download, contentDescription = "Save PDF")
                    }
                    IconButton(onClick = { FileStorageHelper.shareFile(context, file, "application/pdf") }) {
                        Icon(Icons.Filled.Share, contentDescription = "Share PDF")
                    }
                }
            }
        }

        // Editor Tools Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val tools = listOf(
                Triple(EditorToolMode.VIEW, Icons.Filled.PanTool, "View"),
                Triple(EditorToolMode.ADD_TEXT, Icons.Filled.TextFields, "Text"),
                Triple(EditorToolMode.TEXT_BOX, Icons.Filled.EditNote, "Text Box"),
                Triple(EditorToolMode.HIGHLIGHT, Icons.Filled.Highlight, "Highlight"),
                Triple(EditorToolMode.UNDERLINE, Icons.Filled.FormatUnderlined, "Underline"),
                Triple(EditorToolMode.STRIKE_THROUGH, Icons.Filled.FormatStrikethrough, "Strike"),
                Triple(EditorToolMode.DRAW, Icons.Filled.Draw, "Draw"),
                Triple(EditorToolMode.SIGNATURE, Icons.Filled.BorderColor, "Sign"),
                Triple(EditorToolMode.ADD_IMAGE, Icons.Filled.AddPhotoAlternate, "Image"),
                Triple(EditorToolMode.CROP_PAGE, Icons.Filled.Crop, "Crop"),
                Triple(EditorToolMode.WATERMARK, Icons.Filled.WaterDrop, "Watermark"),
                Triple(EditorToolMode.PAGE_NUMBER, Icons.Filled.FormatListNumbered, "Page #"),
                Triple(EditorToolMode.DIGITAL_SIGNATURE, Icons.Filled.VerifiedUser, "Seal")
            )
            tools.forEach { (m, icon, label) ->
                val active = (m == EditorToolMode.WATERMARK && watermarkEnabled) ||
                    (m == EditorToolMode.PAGE_NUMBER && addPageNumbers) ||
                    mode == m
                FilterChip(
                    selected = active,
                    onClick = {
                        when (m) {
                            EditorToolMode.ADD_IMAGE -> imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            EditorToolMode.CROP_PAGE -> showCropDialog = true
                            EditorToolMode.WATERMARK -> showWatermarkDialog = true
                            EditorToolMode.PAGE_NUMBER -> addPageNumbers = !addPageNumbers
                            else -> mode = m
                        }
                    },
                    leadingIcon = { Icon(icon, contentDescription = label, modifier = Modifier.size(16.dp)) },
                    label = { Text(label) }
                )
            }
        }

        // Color & Undo Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                listOf(
                    Color(0xFF156EFC),
                    Color(0xFFE11D48),
                    Color(0xFFFACC15),
                    Color(0xFF059669),
                    Color(0xFF0F172A)
                ).forEach { c ->
                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .clip(CircleShape)
                            .background(c)
                            .border(
                                width = if (selectedColor == c) 3.dp else 1.dp,
                                color = if (selectedColor == c) MaterialTheme.colorScheme.onSurface else Color.LightGray,
                                shape = CircleShape
                            )
                            .clickable { selectedColor = c }
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { onUndoPage(pageIndex) }, enabled = pdfFile != null) {
                    Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "Undo")
                }
                IconButton(onClick = { if (pageIndex > 0) pageIndex-- }, enabled = pageIndex > 0) {
                    Icon(Icons.AutoMirrored.Filled.NavigateBefore, contentDescription = "Prev")
                }
                Text("${pageIndex + 1}/$pageCount", style = MaterialTheme.typography.labelLarge)
                IconButton(onClick = { if (pageIndex < pageCount - 1) pageIndex++ }, enabled = pageIndex < pageCount - 1) {
                    Icon(Icons.AutoMirrored.Filled.NavigateNext, contentDescription = "Next")
                }
            }
        }

        // Interactive PDF Page Canvas
        BoxWithConstraints(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            val bmp = pageBitmap
            if (pdfFile == null || bmp == null) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                    Icon(
                        Icons.Filled.UploadFile,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = if (language == AppLanguage.BN) {
                            "উপরের 'PDF খুলুন' বাটনে চাপ দিয়ে যেকোনো PDF এডিট করা শুরু করুন"
                        } else {
                            "Tap 'Open' above to load a PDF and draw, highlight, add text, images, crop, or sign."
                        },
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            } else {
                Box(
                    modifier = Modifier
                        .aspectRatio(pageAspect)
                        .background(Color.White)
                        .pointerInput(mode, pageIndex, selectedColor, pendingImageFile) {
                            detectTapGestures { offset ->
                                val nx = (offset.x / size.width).coerceIn(0f, 1f)
                                val ny = (offset.y / size.height).coerceIn(0f, 1f)
                                when (mode) {
                                    EditorToolMode.ADD_TEXT, EditorToolMode.TEXT_BOX -> {
                                        pendingTapNorm = nx to ny
                                        textDialogInput = ""
                                        showTextDialog = true
                                    }
                                    EditorToolMode.DIGITAL_SIGNATURE -> {
                                        pendingTapNorm = nx to ny
                                        showDigitalSealDialog = true
                                    }
                                    EditorToolMode.ADD_IMAGE -> {
                                        val img = pendingImageFile
                                        if (img != null) {
                                            onAddAnnotation(
                                                PdfAnnotationItem.ImageAnnotation(
                                                    id = UUID.randomUUID().toString(),
                                                    pageIndex = pageIndex,
                                                    imageFile = img,
                                                    normLeft = nx.coerceAtMost(0.72f),
                                                    normTop = ny.coerceAtMost(0.75f),
                                                    normWidth = 0.25f,
                                                    normHeight = 0.18f
                                                )
                                            )
                                        }
                                    }
                                    else -> Unit
                                }
                            }
                        }
                        .pointerInput(mode, pageIndex, selectedColor) {
                            detectDragGestures(
                                onDragStart = { offset ->
                                    val nx = (offset.x / size.width).coerceIn(0f, 1f)
                                    val ny = (offset.y / size.height).coerceIn(0f, 1f)
                                    if (mode == EditorToolMode.DRAW || mode == EditorToolMode.SIGNATURE) {
                                        activeStroke.clear()
                                        activeStroke.add(nx to ny)
                                    } else if (mode == EditorToolMode.HIGHLIGHT || mode == EditorToolMode.UNDERLINE || mode == EditorToolMode.STRIKE_THROUGH) {
                                        dragStartNorm = nx to ny
                                        dragEndNorm = nx to ny
                                    }
                                },
                                onDrag = { change, _ ->
                                    change.consume()
                                    val nx = (change.position.x / size.width).coerceIn(0f, 1f)
                                    val ny = (change.position.y / size.height).coerceIn(0f, 1f)
                                    if (mode == EditorToolMode.DRAW || mode == EditorToolMode.SIGNATURE) {
                                        activeStroke.add(nx to ny)
                                    } else if (mode == EditorToolMode.HIGHLIGHT || mode == EditorToolMode.UNDERLINE || mode == EditorToolMode.STRIKE_THROUGH) {
                                        dragEndNorm = nx to ny
                                    }
                                },
                                onDragEnd = {
                                    if ((mode == EditorToolMode.DRAW || mode == EditorToolMode.SIGNATURE) && activeStroke.size >= 2) {
                                        onAddAnnotation(
                                            PdfAnnotationItem.FreehandAnnotation(
                                                id = UUID.randomUUID().toString(),
                                                pageIndex = pageIndex,
                                                pointsNorm = activeStroke.toList(),
                                                strokeWidthDp = if (mode == EditorToolMode.SIGNATURE) 2.5f else 3.5f,
                                                colorArgb = selectedColor.toArgb(),
                                                isSignature = mode == EditorToolMode.SIGNATURE
                                            )
                                        )
                                        activeStroke.clear()
                                    } else if (dragStartNorm != null && dragEndNorm != null) {
                                        val s = dragStartNorm!!
                                        val e = dragEndNorm!!
                                        val kind = when (mode) {
                                            EditorToolMode.HIGHLIGHT -> MarkupKind.HIGHLIGHT
                                            EditorToolMode.UNDERLINE -> MarkupKind.UNDERLINE
                                            else -> MarkupKind.STRIKE_THROUGH
                                        }
                                        onAddAnnotation(
                                            PdfAnnotationItem.MarkupAnnotation(
                                                id = UUID.randomUUID().toString(),
                                                pageIndex = pageIndex,
                                                kind = kind,
                                                normLeft = minOf(s.first, e.first),
                                                normTop = minOf(s.second, e.second),
                                                normRight = maxOf(s.first, e.first),
                                                normBottom = maxOf(s.second, e.second).coerceAtLeast(minOf(s.second, e.second) + 0.025f),
                                                colorArgb = if (kind == MarkupKind.HIGHLIGHT) Color(0xFFFACC15).toArgb() else selectedColor.toArgb()
                                            )
                                        )
                                        dragStartNorm = null
                                        dragEndNorm = null
                                    }
                                }
                            )
                        }
                ) {
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = "PDF Page",
                        contentScale = ContentScale.FillBounds,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Overlay annotations
                    val pageItems = annotations.filter { it.pageIndex == pageIndex }
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        for (item in pageItems) {
                            when (item) {
                                is PdfAnnotationItem.FreehandAnnotation -> {
                                    if (item.pointsNorm.size >= 2) {
                                        val path = Path().apply {
                                            moveTo(item.pointsNorm.first().first * size.width, item.pointsNorm.first().second * size.height)
                                            for (pt in item.pointsNorm.drop(1)) {
                                                lineTo(pt.first * size.width, pt.second * size.height)
                                            }
                                        }
                                        drawPath(path, Color(item.colorArgb), style = Stroke(width = item.strokeWidthDp * 2f, cap = StrokeCap.Round))
                                    }
                                }
                                is PdfAnnotationItem.MarkupAnnotation -> {
                                    val l = item.normLeft * size.width
                                    val r = item.normRight * size.width
                                    val t = item.normTop * size.height
                                    val b = item.normBottom * size.height
                                    when (item.kind) {
                                        MarkupKind.HIGHLIGHT -> drawRect(
                                            color = Color(item.colorArgb).copy(alpha = 0.35f),
                                            topLeft = Offset(l, t),
                                            size = Size((r - l).coerceAtLeast(16f), (b - t).coerceAtLeast(14f))
                                        )
                                        MarkupKind.UNDERLINE -> drawLine(
                                            color = Color(item.colorArgb),
                                            start = Offset(l, b),
                                            end = Offset(r, b),
                                            strokeWidth = 3f
                                        )
                                        MarkupKind.STRIKE_THROUGH -> drawLine(
                                            color = Color(item.colorArgb),
                                            start = Offset(l, (t + b) / 2f),
                                            end = Offset(r, (t + b) / 2f),
                                            strokeWidth = 3f
                                        )
                                    }
                                }
                                is PdfAnnotationItem.TextAnnotation -> {
                                    val x = item.normX * size.width
                                    val y = item.normY * size.height
                                    drawRect(
                                        color = if (item.isBoxed) Color(0xFFFFFBEB) else Color(item.colorArgb).copy(alpha = 0.14f),
                                        topLeft = Offset(x - 4f, y - 16f),
                                        size = Size((item.text.length * 10f + 18f).coerceAtLeast(60f), 26f)
                                    )
                                    if (item.isBoxed) {
                                        drawRect(
                                            color = Color(item.colorArgb),
                                            topLeft = Offset(x - 4f, y - 16f),
                                            size = Size((item.text.length * 10f + 18f).coerceAtLeast(60f), 26f),
                                            style = Stroke(2f)
                                        )
                                    }
                                }
                                is PdfAnnotationItem.ImageAnnotation -> {
                                    drawRect(
                                        color = Color(0xFF156EFC).copy(alpha = 0.2f),
                                        topLeft = Offset(item.normLeft * size.width, item.normTop * size.height),
                                        size = Size(item.normWidth * size.width, item.normHeight * size.height)
                                    )
                                }
                                is PdfAnnotationItem.CropAnnotation -> {
                                    drawRect(
                                        color = Color.Red,
                                        topLeft = Offset(item.marginLeftFrac * size.width, item.marginTopFrac * size.height),
                                        size = Size(
                                            size.width * (1f - item.marginLeftFrac - item.marginRightFrac),
                                            size.height * (1f - item.marginTopFrac - item.marginBottomFrac)
                                        ),
                                        style = Stroke(3f)
                                    )
                                }
                                is PdfAnnotationItem.DigitalSealAnnotation -> {
                                    drawRect(
                                        color = Color(0xFF156EFC).copy(alpha = 0.25f),
                                        topLeft = Offset(item.normX * size.width, item.normY * size.height),
                                        size = Size(160f, 48f)
                                    )
                                }
                            }
                        }
                        if (activeStroke.size >= 2) {
                            val p = Path().apply {
                                moveTo(activeStroke.first().first * size.width, activeStroke.first().second * size.height)
                                activeStroke.drop(1).forEach { lineTo(it.first * size.width, it.second * size.height) }
                            }
                            drawPath(p, selectedColor, style = Stroke(width = 6f, cap = StrokeCap.Round))
                        }
                        if (dragStartNorm != null && dragEndNorm != null) {
                            val s = dragStartNorm!!
                            val e = dragEndNorm!!
                            drawRect(
                                color = Color(0xFFFACC15).copy(alpha = 0.35f),
                                topLeft = Offset(minOf(s.first, e.first) * size.width, minOf(s.second, e.second) * size.height),
                                size = Size(
                                    kotlin.math.abs(e.first - s.first) * size.width,
                                    (kotlin.math.abs(e.second - s.second) * size.height).coerceAtLeast(16f)
                                )
                            )
                        }
                    }
                }
            }
        }
    }

    if (showTextDialog) {
        AlertDialog(
            onDismissRequest = { showTextDialog = false },
            title = { Text(if (mode == EditorToolMode.TEXT_BOX) "Add Text Box" else "Add Text") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = textDialogInput,
                        onValueChange = { textDialogInput = it },
                        label = { Text("Text content") },
                        singleLine = true
                    )
                    Text("Font size: ${textFontSize.toInt()} pt")
                    Slider(value = textFontSize, onValueChange = { textFontSize = it }, valueRange = 10f..32f)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val pos = pendingTapNorm
                    if (pos != null && textDialogInput.isNotBlank()) {
                        onAddAnnotation(
                            PdfAnnotationItem.TextAnnotation(
                                id = UUID.randomUUID().toString(),
                                pageIndex = pageIndex,
                                normX = pos.first,
                                normY = pos.second,
                                text = textDialogInput,
                                fontSizePt = textFontSize,
                                colorArgb = selectedColor.toArgb(),
                                isBoxed = mode == EditorToolMode.TEXT_BOX
                            )
                        )
                    }
                    showTextDialog = false
                }) { Text("Place") }
            },
            dismissButton = { TextButton(onClick = { showTextDialog = false }) { Text("Cancel") } }
        )
    }

    if (showDigitalSealDialog) {
        AlertDialog(
            onDismissRequest = { showDigitalSealDialog = false },
            title = { Text("Digital Signature Stamp") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = signerName, onValueChange = { signerName = it }, label = { Text("Signer Name") })
                    OutlinedTextField(value = signReason, onValueChange = { signReason = it }, label = { Text("Reason") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val pos = pendingTapNorm
                    if (pos != null) {
                        val ts = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
                        onAddAnnotation(
                            PdfAnnotationItem.DigitalSealAnnotation(
                                id = UUID.randomUUID().toString(),
                                pageIndex = pageIndex,
                                signerName = signerName.ifBlank { "Authorized User" },
                                reason = signReason.ifBlank { "Verified" },
                                timestampText = ts,
                                normX = pos.first.coerceAtMost(0.65f),
                                normY = pos.second.coerceAtMost(0.85f)
                            )
                        )
                    }
                    showDigitalSealDialog = false
                }) { Text("Stamp") }
            },
            dismissButton = { TextButton(onClick = { showDigitalSealDialog = false }) { Text("Cancel") } }
        )
    }

    if (showWatermarkDialog) {
        AlertDialog(
            onDismissRequest = { showWatermarkDialog = false },
            title = { Text("Watermark Overlay") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = watermarkEnabled, onCheckedChange = { watermarkEnabled = it })
                        Text("Enable watermark on all pages")
                    }
                    OutlinedTextField(value = watermarkText, onValueChange = { watermarkText = it }, label = { Text("Watermark Text") })
                }
            },
            confirmButton = { TextButton(onClick = { showWatermarkDialog = false }) { Text("Apply") } }
        )
    }

    if (showCropDialog) {
        AlertDialog(
            onDismissRequest = { showCropDialog = false },
            title = { Text("Crop Current Page Margins") },
            text = {
                Column {
                    Text("Trim Margin: ${(cropMargin * 100).toInt()}% on all edges")
                    Slider(value = cropMargin, onValueChange = { cropMargin = it }, valueRange = 0f..0.25f)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    onAddAnnotation(
                        PdfAnnotationItem.CropAnnotation(
                            id = UUID.randomUUID().toString(),
                            pageIndex = pageIndex,
                            marginLeftFrac = cropMargin,
                            marginTopFrac = cropMargin,
                            marginRightFrac = cropMargin,
                            marginBottomFrac = cropMargin
                        )
                    )
                    showCropDialog = false
                }) { Text("Set Crop") }
            },
            dismissButton = { TextButton(onClick = { showCropDialog = false }) { Text("Cancel") } }
        )
    }
}
