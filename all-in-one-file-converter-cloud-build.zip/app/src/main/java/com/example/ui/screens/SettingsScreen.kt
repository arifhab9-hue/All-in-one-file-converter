package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.AppStrings
import com.example.data.local.UserSettings
import com.example.ui.theme.ThemePreference

@Composable
fun SettingsScreen(
    settings: UserSettings,
    backendTestStatus: String?,
    onLanguageChange: (AppLanguage) -> Unit,
    onThemeChange: (ThemePreference) -> Unit,
    onAutoOcrChange: (Boolean) -> Unit,
    onDefaultDpiChange: (Int) -> Unit,
    onSaveBackendUrl: (String) -> Unit,
    onTestBackend: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = settings.language
    var serverInput by remember(settings.optionalBackendUrl) { mutableStateOf(settings.optionalBackendUrl) }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(
            modifier = Modifier
                .widthIn(max = 700.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = AppStrings.navSettings.get(lang),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )

            // Language & Theme Card
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(AppStrings.languageLabel.get(lang), style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AppLanguage.entries.forEach { l ->
                            FilterChip(
                                selected = settings.language == l,
                                onClick = { onLanguageChange(l) },
                                label = { Text(l.displayName) },
                                modifier = Modifier.testTag("settings_lang_${l.code}")
                            )
                        }
                    }

                    Text(AppStrings.themeLabel.get(lang), style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            ThemePreference.SYSTEM to AppStrings.themeSystem.get(lang),
                            ThemePreference.LIGHT to AppStrings.themeLight.get(lang),
                            ThemePreference.DARK to AppStrings.themeDark.get(lang)
                        ).forEach { (pref, label) ->
                            FilterChip(
                                selected = settings.theme == pref,
                                onClick = { onThemeChange(pref) },
                                label = { Text(label) },
                                modifier = Modifier.testTag("settings_theme_${pref.name.lowercase()}")
                            )
                        }
                    }
                }
            }

            // Processing Defaults Card
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(AppStrings.ocrToggle.get(lang), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                        Switch(checked = settings.autoOcr, onCheckedChange = onAutoOcrChange)
                    }

                    Text(AppStrings.resolutionDpi.get(lang), style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(72, 150, 220, 300).forEach { dpi ->
                            FilterChip(
                                selected = settings.defaultDpi == dpi,
                                onClick = { onDefaultDpiChange(dpi) },
                                label = { Text("$dpi DPI") }
                            )
                        }
                    }
                }
            }

            // Optional Self-Hosted Server Backend Support
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(AppStrings.serverSectionTitle.get(lang), style = MaterialTheme.typography.titleMedium)
                    Text(
                        AppStrings.serverSectionDesc.get(lang),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = serverInput,
                        onValueChange = { serverInput = it },
                        label = { Text(AppStrings.serverUrlLabel.get(lang)) },
                        placeholder = { Text("https://your-gotenberg-server/forms/libreoffice/convert") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { onSaveBackendUrl(serverInput) }) {
                            Text(AppStrings.saveSettings.get(lang))
                        }
                        OutlinedButton(onClick = { onTestBackend(serverInput) }) {
                            Text(AppStrings.testConnection.get(lang))
                        }
                    }
                    if (!backendTestStatus.isNullOrBlank()) {
                        Text(backendTestStatus, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }

            // Transparency & Processing Limits Info
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = if (lang == AppLanguage.BN) "ফাইল সাইজ ও প্রসেসিং তথ্য" else "Processing Limits & Format Transparency",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (lang == AppLanguage.BN) {
                            "• সর্বোচ্চ প্রস্তাবিত ফাইল সাইজ: ৮০ MB (মূল ফাইল কখনো পরিবর্তন করা হয় না)।\n" +
                            "• ইমেজ, PDF, DOCX, XLSX, PPTX, ODT/ODS/ODP, RTF, CSV, HTML, TXT ও স্ক্যান করা PDF OCR ১০০% ডিভাইসে লোকালি কাজ করে।\n" +
                            "• লিগ্যাসি বাইনারি .doc/.xls/.ppt তৈরি করলে Microsoft Word/Excel-সাপোর্টেড RTF/SpreadsheetML/OOXML ফরম্যাট ব্যবহৃত হয়, এবং চাইলে Settings থেকে নিজস্ব LibreOffice সার্ভার যুক্ত করা যায়।"
                        } else {
                            "• Recommended max file size: 80 MB per file (original files are never overwritten).\n" +
                            "• Images (JPG/PNG/WEBP/BMP/TIFF), PDF tools, PDF Editor, ML Kit OCR, DOCX, XLSX, PPTX, ODT/ODS/ODP, RTF, CSV, HTML, and TXT run 100% locally on-device with zero paid APIs.\n" +
                            "• Exporting legacy binary .doc/.xls uses Office-compatible RTF/SpreadsheetML containers locally, or optional self-hosted LibreOffice backend if configured."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
