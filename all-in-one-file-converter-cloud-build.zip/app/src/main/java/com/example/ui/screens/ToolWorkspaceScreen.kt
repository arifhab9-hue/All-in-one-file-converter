package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Preview
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.AppStrings
import com.example.core.model.ConversionOptions
import com.example.core.model.ConversionOutputFile
import com.example.core.model.InputPickerMode
import com.example.core.model.MarginPreset
import com.example.core.model.PageOrientation
import com.example.core.model.PageSize
import com.example.core.model.PdfMetadataInfo
import com.example.core.model.ToolCategory
import com.example.core.model.ToolId
import com.example.core.model.WorkspaceFile
import com.example.engine.FileStorageHelper
import com.example.ui.ProcessingUiState
import com.example.ui.components.FilePreviewDialog
import java.io.File

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ToolWorkspaceScreen(
    toolId: ToolId,
    language: AppLanguage,
    selectedFiles: List<WorkspaceFile>,
    options: ConversionOptions,
    detectedExcelSheets: List<String>,
    inspectedMetadata: PdfMetadataInfo?,
    processingState: ProcessingUiState,
    optionalBackendUrl: String,
    useBackendServer: Boolean,
    onAddUris: (List<Uri>) -> Unit,
    onRemoveFile: (String) -> Unit,
    onMoveFile: (Int, Int) -> Unit,
    onUpdateOptions: ((ConversionOptions) -> ConversionOptions) -> Unit,
    onToggleBackendServer: (Boolean) -> Unit,
    onRun: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val context = LocalContext.current
    var previewTarget by remember { mutableStateOf<Triple<File, String, String?>?>(null) }
    var pendingSaveFile by remember { mutableStateOf<Pair<File, String>?>(null) }

    val saveFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("*/*")
    ) { destUri ->
        val src = pendingSaveFile?.first
        if (destUri != null && src != null && src.exists()) {
            runCatching { FileStorageHelper.copyFileToUri(context, src, destUri) }
                .onSuccess { Toast.makeText(context, "Saved successfully", Toast.LENGTH_SHORT).show() }
                .onFailure { Toast.makeText(context, "Save failed: ${it.message}", Toast.LENGTH_LONG).show() }
        }
        pendingSaveFile = null
    }

    val multiPhotoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        if (uris.isNotEmpty()) onAddUris(uris)
    }

    val singlePhotoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) onAddUris(listOf(uri))
    }

    val singleDocLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) onAddUris(listOf(uri))
    }

    val multiDocLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) onAddUris(uris)
    }

    fun triggerFilePicker() {
        when (toolId.pickerMode) {
            InputPickerMode.MULTIPLE_IMAGES -> {
                if (toolId == ToolId.TIFF_TO_PDF || toolId == ToolId.BMP_TO_PDF) {
                    multiDocLauncher.launch(arrayOf("image/*", "application/octet-stream"))
                } else {
                    multiPhotoLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
            }
            InputPickerMode.SINGLE_IMAGE -> {
                singlePhotoLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }
            InputPickerMode.SINGLE_PDF -> singleDocLauncher.launch(arrayOf("application/pdf"))
            InputPickerMode.MULTIPLE_PDFS -> multiDocLauncher.launch(arrayOf("application/pdf"))
            InputPickerMode.SINGLE_DOC -> singleDocLauncher.launch(arrayOf("*/*"))
            InputPickerMode.MULTIPLE_DOCS,
            InputPickerMode.ANY_DOCUMENT -> multiDocLauncher.launch(arrayOf("*/*"))
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(toolId.title.get(language), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            toolId.category.title.get(language),
                            style = MaterialTheme.typography.labelSmall,
                            color = toolId.category.color
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("tool_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 760.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Tool description & accepted formats
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = toolId.category.color.copy(alpha = 0.1f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = toolId.subtitle.get(language),
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "Supported: ${toolId.acceptedExtensions.joinToString(", ") { ".$it" }} • ${AppStrings.originalPreservedNote.get(language)}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Upload / Selected Files Card
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (selectedFiles.isEmpty()) AppStrings.noFilesSelected.get(language)
                                else "${selectedFiles.size} file(s) ready",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Button(
                                onClick = { triggerFilePicker() },
                                modifier = Modifier.testTag("pick_files_button")
                            ) {
                                Icon(
                                    imageVector = if (selectedFiles.isEmpty()) Icons.Filled.UploadFile else Icons.Filled.Add,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    if (selectedFiles.isEmpty()) AppStrings.quickUpload.get(language)
                                    else AppStrings.addMoreFiles.get(language)
                                )
                            }
                        }

                        if (selectedFiles.isNotEmpty()) {
                            Spacer(Modifier.height(10.dp))
                            val canReorder = toolId.pickerMode == InputPickerMode.MULTIPLE_IMAGES ||
                                toolId == ToolId.MERGE_PDF || toolId == ToolId.WORD_MERGE
                            selectedFiles.forEachIndexed { idx, wf ->
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${idx + 1}.",
                                            style = MaterialTheme.typography.labelLarge,
                                            color = toolId.category.color
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = wf.name,
                                                style = MaterialTheme.typography.bodyLarge,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = FileStorageHelper.formatSize(wf.sizeBytes),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        IconButton(onClick = {
                                            previewTarget = Triple(wf.localFile, wf.mimeType, null)
                                        }) {
                                            Icon(Icons.Filled.Preview, contentDescription = "Preview")
                                        }
                                        if (canReorder && selectedFiles.size > 1) {
                                            IconButton(
                                                onClick = { onMoveFile(idx, -1) },
                                                enabled = idx > 0
                                            ) {
                                                Icon(Icons.Filled.ArrowUpward, contentDescription = "Move up")
                                            }
                                            IconButton(
                                                onClick = { onMoveFile(idx, 1) },
                                                enabled = idx < selectedFiles.lastIndex
                                            ) {
                                                Icon(Icons.Filled.ArrowDownward, contentDescription = "Move down")
                                            }
                                        }
                                        IconButton(onClick = { onRemoveFile(wf.id) }) {
                                            Icon(Icons.Filled.Delete, contentDescription = "Remove")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Tool-Specific Configuration Controls
                ToolOptionsSection(
                    toolId = toolId,
                    language = language,
                    options = options,
                    detectedExcelSheets = detectedExcelSheets,
                    inspectedMetadata = inspectedMetadata,
                    optionalBackendUrl = optionalBackendUrl,
                    useBackendServer = useBackendServer,
                    onUpdateOptions = onUpdateOptions,
                    onToggleBackendServer = onToggleBackendServer
                )

                // Primary Action Button
                Button(
                    onClick = onRun,
                    enabled = selectedFiles.isNotEmpty() && processingState !is ProcessingUiState.Running,
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = toolId.category.color),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("run_conversion_button")
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = if (processingState is ProcessingUiState.Running) {
                            "${AppStrings.processing.get(language)} ${processingState.message}"
                        } else {
                            AppStrings.startProcess.get(language)
                        },
                        style = MaterialTheme.typography.titleMedium
                    )
                }

                // Live Progress & Result / Error States
                when (processingState) {
                    is ProcessingUiState.Running -> {
                        LinearProgressIndicator(
                            progress = { processingState.progress.coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                        )
                    }
                    is ProcessingUiState.Error -> {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.errorContainer,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = processingState.message,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(14.dp)
                            )
                        }
                    }
                    is ProcessingUiState.Success -> {
                        val res = processingState.result
                        ConversionResultCard(
                            language = language,
                            originalBytes = res.originalTotalBytes,
                            outputBytes = res.outputTotalBytes,
                            pageCount = res.pageCount,
                            note = res.note,
                            previewText = res.previewText,
                            outputs = res.outputFiles,
                            zipFile = res.zipFile,
                            onPreview = { file, mime -> previewTarget = Triple(file, mime, null) },
                            onSave = { file, mime ->
                                pendingSaveFile = file to mime
                                saveFileLauncher.launch(file.name)
                            },
                            onShare = { file, mime -> FileStorageHelper.shareFile(context, file, mime) }
                        )
                    }
                    ProcessingUiState.Idle -> Unit
                }

                Spacer(Modifier.height(24.dp))
            }
        }
    }

    previewTarget?.let { (file, mime, overrideText) ->
        FilePreviewDialog(
            file = file,
            mimeType = mime,
            textOverride = overrideText,
            onDismiss = { previewTarget = null }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ToolOptionsSection(
    toolId: ToolId,
    language: AppLanguage,
    options: ConversionOptions,
    detectedExcelSheets: List<String>,
    inspectedMetadata: PdfMetadataInfo?,
    optionalBackendUrl: String,
    useBackendServer: Boolean,
    onUpdateOptions: ((ConversionOptions) -> ConversionOptions) -> Unit,
    onToggleBackendServer: (Boolean) -> Unit
) {
    val needsLayoutOptions = toolId.category == ToolCategory.IMAGE_TO_PDF
    val needsImageOutputOptions = toolId.category == ToolCategory.PDF_TO_IMAGE ||
        toolId == ToolId.PPT_TO_JPG || toolId == ToolId.PPT_TO_PNG
    val needsCompressionOptions = toolId.category == ToolCategory.FILE_COMPRESSOR ||
        toolId == ToolId.COMPRESS_PDF || toolId == ToolId.WORD_COMPRESS
    val needsPageRange = toolId in setOf(
        ToolId.SPLIT_PDF, ToolId.ROTATE_PDF, ToolId.DELETE_PDF_PAGES,
        ToolId.EXTRACT_PDF_PAGES, ToolId.REARRANGE_PDF_PAGES
    )
    val needsOcr = toolId in setOf(
        ToolId.PDF_TO_TXT, ToolId.PDF_TO_DOC, ToolId.PDF_TO_DOCX,
        ToolId.PDF_TO_XLS, ToolId.PDF_TO_XLSX, ToolId.PDF_TO_PPT, ToolId.PDF_TO_PPTX
    )
    val isExcelSource = toolId in setOf(
        ToolId.XLS_TO_PDF, ToolId.XLSX_TO_PDF, ToolId.ODS_TO_PDF, ToolId.EXCEL_DATA_EXTRACT
    )

    if (!needsLayoutOptions && !needsImageOutputOptions && !needsCompressionOptions &&
        !needsPageRange && !needsOcr && !isExcelSource &&
        toolId != ToolId.UNLOCK_PDF && toolId != ToolId.PROTECT_PDF &&
        toolId != ToolId.ADD_WATERMARK && toolId != ToolId.ADD_PAGE_NUMBER &&
        toolId != ToolId.PDF_METADATA && optionalBackendUrl.isBlank()
    ) return

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (needsLayoutOptions) {
                Text(AppStrings.pageSize.get(language), style = MaterialTheme.typography.titleMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PageSize.entries.forEach { ps ->
                        FilterChip(
                            selected = options.pageSize == ps,
                            onClick = { onUpdateOptions { it.copy(pageSize = ps) } },
                            label = { Text(ps.label) }
                        )
                    }
                }
                Text(AppStrings.orientation.get(language), style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = options.orientation == PageOrientation.PORTRAIT,
                        onClick = { onUpdateOptions { it.copy(orientation = PageOrientation.PORTRAIT) } },
                        label = { Text(AppStrings.portrait.get(language)) }
                    )
                    FilterChip(
                        selected = options.orientation == PageOrientation.LANDSCAPE,
                        onClick = { onUpdateOptions { it.copy(orientation = PageOrientation.LANDSCAPE) } },
                        label = { Text(AppStrings.landscape.get(language)) }
                    )
                }
                Text(AppStrings.margins.get(language), style = MaterialTheme.typography.titleMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MarginPreset.entries.forEach { mp ->
                        FilterChip(
                            selected = options.margin == mp,
                            onClick = { onUpdateOptions { it.copy(margin = mp) } },
                            label = { Text(if (language == AppLanguage.BN) mp.labelBn else mp.labelEn) }
                        )
                    }
                }
            }

            if (needsImageOutputOptions) {
                Text(
                    "${AppStrings.quality.get(language)}: ${options.quality}%",
                    style = MaterialTheme.typography.titleMedium
                )
                Slider(
                    value = options.quality.toFloat(),
                    onValueChange = { q -> onUpdateOptions { it.copy(quality = q.toInt()) } },
                    valueRange = 20f..100f
                )
                if (toolId.category == ToolCategory.PDF_TO_IMAGE) {
                    Text(AppStrings.resolutionDpi.get(language), style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(72, 150, 220, 300).forEach { dpi ->
                            FilterChip(
                                selected = options.dpi == dpi,
                                onClick = { onUpdateOptions { it.copy(dpi = dpi) } },
                                label = { Text("$dpi DPI") }
                            )
                        }
                    }
                }
            }

            if (needsCompressionOptions) {
                Text(
                    "${AppStrings.quality.get(language)}: ${options.quality}%",
                    style = MaterialTheme.typography.titleMedium
                )
                Slider(
                    value = options.quality.toFloat(),
                    onValueChange = { q -> onUpdateOptions { it.copy(quality = q.toInt()) } },
                    valueRange = 15f..95f
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(AppStrings.useTargetSize.get(language), style = MaterialTheme.typography.bodyLarge)
                    Switch(
                        checked = options.useTargetSize,
                        onCheckedChange = { checked -> onUpdateOptions { it.copy(useTargetSize = checked) } }
                    )
                }
                if (options.useTargetSize) {
                    OutlinedTextField(
                        value = options.targetSizeKb.toString(),
                        onValueChange = { txt ->
                            val kb = txt.filter { it.isDigit() }.toIntOrNull() ?: 0
                            onUpdateOptions { it.copy(targetSizeKb = kb) }
                        },
                        label = { Text(AppStrings.targetSizeKb.get(language)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(100 to "100 KB", 250 to "250 KB", 500 to "500 KB", 1024 to "1 MB", 2048 to "2 MB").forEach { (kb, label) ->
                            FilterChip(
                                selected = options.targetSizeKb == kb,
                                onClick = { onUpdateOptions { it.copy(targetSizeKb = kb) } },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }

            if (needsPageRange) {
                OutlinedTextField(
                    value = options.pageRange,
                    onValueChange = { v -> onUpdateOptions { it.copy(pageRange = v) } },
                    label = { Text(AppStrings.pageRangeHint.get(language)) },
                    placeholder = { Text("1-3, 5") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (toolId == ToolId.ROTATE_PDF) {
                    Text(AppStrings.rotationAngle.get(language), style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(90, 180, 270).forEach { deg ->
                            FilterChip(
                                selected = options.rotationDegrees == deg,
                                onClick = { onUpdateOptions { it.copy(rotationDegrees = deg) } },
                                label = { Text("$deg°") }
                            )
                        }
                    }
                }
            }

            if (toolId == ToolId.PROTECT_PDF || toolId == ToolId.UNLOCK_PDF) {
                OutlinedTextField(
                    value = options.password,
                    onValueChange = { pw -> onUpdateOptions { it.copy(password = pw) } },
                    label = { Text(AppStrings.passwordLabel.get(language)) },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (toolId == ToolId.UNLOCK_PDF) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = options.authorizedToUnlock,
                            onCheckedChange = { ok -> onUpdateOptions { it.copy(authorizedToUnlock = ok) } }
                        )
                        Text(AppStrings.authorizedConfirm.get(language), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            if (toolId == ToolId.ADD_WATERMARK) {
                OutlinedTextField(
                    value = options.watermarkText,
                    onValueChange = { wm -> onUpdateOptions { it.copy(watermarkText = wm) } },
                    label = { Text(AppStrings.watermarkText.get(language)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (toolId == ToolId.ADD_PAGE_NUMBER) {
                OutlinedTextField(
                    value = options.pageNumberPrefix,
                    onValueChange = { pre -> onUpdateOptions { it.copy(pageNumberPrefix = pre) } },
                    label = { Text("Prefix (e.g. Page )") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (needsOcr) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(AppStrings.ocrToggle.get(language), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                    Switch(
                        checked = options.enableOcr,
                        onCheckedChange = { en -> onUpdateOptions { it.copy(enableOcr = en) } }
                    )
                }
            }

            if (isExcelSource) {
                if (detectedExcelSheets.isNotEmpty()) {
                    Text(AppStrings.selectSheets.get(language), style = MaterialTheme.typography.titleMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        detectedExcelSheets.forEach { sheet ->
                            val selected = sheet in options.selectedExcelSheets
                            FilterChip(
                                selected = selected,
                                onClick = {
                                    onUpdateOptions { opt ->
                                        val next = if (selected && opt.selectedExcelSheets.size > 1) {
                                            opt.selectedExcelSheets - sheet
                                        } else {
                                            opt.selectedExcelSheets + sheet
                                        }
                                        opt.copy(selectedExcelSheets = next)
                                    }
                                },
                                label = { Text(sheet) }
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = options.printArea,
                    onValueChange = { area -> onUpdateOptions { it.copy(printArea = area) } },
                    label = { Text(AppStrings.printAreaHint.get(language)) },
                    placeholder = { Text("A1:F25") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (toolId == ToolId.EXCEL_DATA_EXTRACT) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("CSV", "JSON").forEach { fmt ->
                            FilterChip(
                                selected = options.excelExtractFormat == fmt,
                                onClick = { onUpdateOptions { it.copy(excelExtractFormat = fmt) } },
                                label = { Text("Export $fmt") }
                            )
                        }
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = options.orientation == PageOrientation.PORTRAIT,
                            onClick = { onUpdateOptions { it.copy(orientation = PageOrientation.PORTRAIT) } },
                            label = { Text(AppStrings.portrait.get(language)) }
                        )
                        FilterChip(
                            selected = options.orientation == PageOrientation.LANDSCAPE,
                            onClick = { onUpdateOptions { it.copy(orientation = PageOrientation.LANDSCAPE) } },
                            label = { Text(AppStrings.landscape.get(language)) }
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(AppStrings.fitToPage.get(language), style = MaterialTheme.typography.bodyLarge)
                        Switch(
                            checked = options.fitToPage,
                            onCheckedChange = { fit -> onUpdateOptions { it.copy(fitToPage = fit) } }
                        )
                    }
                }
            }

            if (toolId == ToolId.PDF_METADATA && inspectedMetadata != null) {
                Text(
                    "Pages: ${inspectedMetadata.pageCount} • Encrypted: ${inspectedMetadata.isEncrypted} • Creator: ${inspectedMetadata.creator.ifBlank { "-" }}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = options.customMetadataTitle,
                    onValueChange = { v -> onUpdateOptions { it.copy(customMetadataTitle = v) } },
                    label = { Text("Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = options.customMetadataAuthor,
                    onValueChange = { v -> onUpdateOptions { it.copy(customMetadataAuthor = v) } },
                    label = { Text("Author") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = options.customMetadataSubject,
                    onValueChange = { v -> onUpdateOptions { it.copy(customMetadataSubject = v) } },
                    label = { Text("Subject") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = options.customMetadataKeywords,
                    onValueChange = { v -> onUpdateOptions { it.copy(customMetadataKeywords = v) } },
                    label = { Text("Keywords") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (optionalBackendUrl.isNotBlank()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Use Self-Hosted Server Backend", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = useBackendServer, onCheckedChange = onToggleBackendServer)
                }
            }
        }
    }
}

@Composable
private fun ConversionResultCard(
    language: AppLanguage,
    originalBytes: Long,
    outputBytes: Long,
    pageCount: Int,
    note: String?,
    previewText: String?,
    outputs: List<ConversionOutputFile>,
    zipFile: File?,
    onPreview: (File, String) -> Unit,
    onSave: (File, String) -> Unit,
    onShare: (File, String) -> Unit
) {
    val savedPct = if (originalBytes > 0) {
        (((originalBytes - outputBytes).toDouble() / originalBytes) * 100.0).toInt()
    } else 0

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = Color(0xFF059669))
                Spacer(Modifier.width(8.dp))
                Text(
                    AppStrings.resultReady.get(language),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            // Original vs Output Comparison Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricBox(AppStrings.originalSize.get(language), FileStorageHelper.formatSize(originalBytes), Modifier.weight(1f))
                MetricBox(AppStrings.outputSize.get(language), FileStorageHelper.formatSize(outputBytes), Modifier.weight(1f))
                MetricBox(
                    if (savedPct >= 0) AppStrings.savedPercent.get(language) else AppStrings.pagesLabel.get(language),
                    if (savedPct >= 0) "$savedPct%" else "$pageCount",
                    Modifier.weight(1f)
                )
            }

            if (!note.isNullOrBlank()) {
                Text(
                    text = note,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (!previewText.isNullOrBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(12.dp)
                ) {
                    Text(
                        text = previewText.take(2500),
                        style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace)
                    )
                }
            }

            if (zipFile != null) {
                Button(
                    onClick = { onSave(zipFile, "application/zip") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("download_zip_button")
                ) {
                    Icon(Icons.Filled.FolderZip, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("${AppStrings.downloadZip.get(language)} (${FileStorageHelper.formatSize(zipFile.length())})")
                }
            }

            outputs.forEach { item ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(FileStorageHelper.formatSize(item.sizeBytes), style = MaterialTheme.typography.labelSmall)
                        }
                        IconButton(onClick = { onPreview(item.file, item.mimeType) }) {
                            Icon(Icons.Filled.Preview, contentDescription = AppStrings.previewResult.get(language))
                        }
                        IconButton(onClick = { onSave(item.file, item.mimeType) }) {
                            Icon(Icons.Filled.Download, contentDescription = AppStrings.saveToDevice.get(language))
                        }
                        IconButton(onClick = { onShare(item.file, item.mimeType) }) {
                            Icon(Icons.Filled.Share, contentDescription = AppStrings.shareFile.get(language))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricBox(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
    }
}
