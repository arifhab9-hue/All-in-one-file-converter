package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand & Accent Palette — crisp studio workspace aesthetic (Electric Cobalt + Coral PDF + Emerald Excel + Amber PPT)
val BrandBlue = Color(0xFF156EFC)
val BrandBlueDark = Color(0xFF4D94FF)
val BrandBlueContainer = Color(0xFFDCE9FF)
val BrandBlueContainerDark = Color(0xFF0E3A80)

val PdfRed = Color(0xFFE11D48)
val WordBlue = Color(0xFF2563EB)
val ExcelGreen = Color(0xFF059669)
val PptOrange = Color(0xFFEA580C)
val ImageViolet = Color(0xFF7C3AED)
val EditorTeal = Color(0xFF0D9488)
val CompressAmber = Color(0xFFD97706)
val OtherSlate = Color(0xFF475569)

// Light Surfaces
val LightBackground = Color(0xFFF6F8FC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEDF1F7)
val LightOnSurface = Color(0xFF0F172A)
val LightOnSurfaceVariant = Color(0xFF475569)
val LightOutline = Color(0xFFCBD5E1)

// Dark Surfaces
val DarkBackground = Color(0xFF0B1120)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
val DarkOutline = Color(0xFF334155)
