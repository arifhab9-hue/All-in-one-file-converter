package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.model.ConversionOptions
import com.example.core.model.ToolId
import com.example.core.model.WorkspaceFile
import com.example.engine.OfficeExcelEngine
import com.example.engine.PdfToolsEngine
import com.example.engine.TextFormatEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ConverterEnginesUnitTest {

    @Test
    fun `page range parser handles ranges and preserves order`() {
        val ordered = PdfToolsEngine.parsePageSelection("5, 1-3, 2", totalPages = 6, preserveOrder = true)
        assertEquals(listOf(5, 1, 2, 3, 2), ordered)

        val sortedUnique = PdfToolsEngine.parsePageSelection("4, 2-3, 99", totalPages = 5, preserveOrder = false)
        assertEquals(listOf(2, 3, 4), sortedUnique)
    }

    @Test
    fun `csv to xlsx and xlsx to csv round trip`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val csvFile = File(context.cacheDir, "sample.csv")
        csvFile.writeText("Name,Score,City\n\"Rahman, Ali\",95,Dhaka\nNadia,88,Chattogram", Charsets.UTF_8)

        val wsCsv = WorkspaceFile("1", csvFile.name, csvFile, "text/csv", csvFile.length())
        val xlsxRes = OfficeExcelEngine.csvToXlsx(context, wsCsv) {}
        assertEquals(1, xlsxRes.outputFiles.size)
        val xlsxFile = xlsxRes.outputFiles.first().file
        assertTrue(xlsxFile.exists() && xlsxFile.length() > 100)

        val wsXlsx = WorkspaceFile("2", xlsxFile.name, xlsxFile, xlsxRes.outputFiles.first().mimeType, xlsxFile.length())
        val sheets = OfficeExcelEngine.parseWorkbook(wsXlsx.localFile)
        assertEquals(1, sheets.size)
        assertEquals(3, sheets.first().rows.size)
        assertEquals("Rahman, Ali", sheets.first().rows[1][0])
        assertEquals("95", sheets.first().rows[1][1])

        val csvBack = OfficeExcelEngine.xlsxToCsv(context, wsXlsx) {}
        assertTrue(csvBack.outputFiles.first().file.readText(Charsets.UTF_8).contains("Dhaka"))
    }

    @Test
    fun `rtf parser strips control words and preserves paragraphs`() {
        val rtf = "{\\rtf1\\ansi{\\fonttbl{\\f0 Arial;}}\\b Hello World\\b0\\par Second Line\\par}"
        val paras = TextFormatEngine.parseRtfParagraphs(rtf)
        assertEquals(listOf("Hello World", "Second Line"), paras)
    }

    @Test
    fun `excel print area slicing works via extractExcelData`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val csvFile = File(context.cacheDir, "grid.csv")
        csvFile.writeText("A1,B1,C1\nA2,B2,C2\nA3,B3,C3", Charsets.UTF_8)
        val ws = WorkspaceFile("3", csvFile.name, csvFile, "text/csv", csvFile.length())
        val res = OfficeExcelEngine.extractExcelData(
            context,
            ws,
            ConversionOptions(printArea = "B2:C3", excelExtractFormat = "JSON")
        ) {}
        val json = res.outputFiles.first().file.readText(Charsets.UTF_8)
        assertTrue(json.contains("B2") && json.contains("C3"))
        assertTrue(!json.contains("A1"))
        assertEquals(ToolId.EXCEL_DATA_EXTRACT, res.toolId)
    }
}
